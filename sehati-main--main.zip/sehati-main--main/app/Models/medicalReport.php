<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MedicalReport extends Model
{
    protected $fillable = [
        'doctor_id','patient_id','title','content'
    ];

    public function patient(){
        return $this->belongsTo(Patient::class);
    }
}
