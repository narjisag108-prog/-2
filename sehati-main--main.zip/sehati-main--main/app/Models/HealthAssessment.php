<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HealthAssessment extends Model
{
    protected $fillable = [
        'user_id','age','gender','family_history',
        'bmi','activity','blood_pressure',
        'score','risk_level'
    ];
}
