<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;


class ConsultationReply extends Model
{
    use HasFactory;

    protected $fillable = [
        'consultation_id','doctor_id','reply',
    ];



    public function doctor()
    {
        return $this->belongsTo(User::class, 'doctor_id');
    }

public function consultation()
{
    return $this->belongsTo(Consultation::class);
}
}
