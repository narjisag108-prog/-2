<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Consultation extends Model
{
    protected $fillable = [
        'user_id',
        'doctor_id',
        'title',
        'message',
        'status',
      'disease_id',
        'appointment_id',

    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function doctor()
    {
        return $this->belongsTo(User::class, 'doctor_id');
    }
    public function replies()
{
    return $this->hasMany(ConsultationReply::class);
}
  public function patient(){
        return $this->belongsTo(Patient::class);
    }
    public function disease(){
        return $this->belongsTo(Disease::class);
    }

    public function appointment(){
        return $this->belongsTo(Appointment::class);
    }
}

