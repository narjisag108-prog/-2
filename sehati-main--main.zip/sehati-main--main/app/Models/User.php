<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class User extends Authenticatable
{
    use HasFactory, Notifiable;

    protected $fillable = [
        'first_name','last_name','email','phone','password','role', 'status',
    ];

    protected $hidden = [
        'password',
    ];

    // 🔗 العلاقات
    public function articles()
    {
        return $this->hasMany(Article::class, 'author_id');
    }

    public function results()
    {
        return $this->hasMany(Result::class);
    }

    public function comments()
    {
        return $this->hasMany(Comment::class);
    }
    // علاقة المستخدم بالاستشارات كـ patient
    public function consultations()
    {
        return $this->hasMany(Consultation::class, 'user_id');
    }

    // علاقة المستخدم بالطبيب المعيّن (لو هو طبيب)
    public function assignedConsultations()
    {
        return $this->hasMany(Consultation::class, 'doctor_id');
    }
    public function reviews()
{
    return $this->hasMany(Review::class);
}
}
