<?php


namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Setting extends Model
{
    protected $fillable = [
        'site_name','site_logo','maintenance_mode','analytics_code',
        'admin_first_name','admin_last_name','admin_email','admin_phone','admin_bio','admin_avatar',
        'notify_email_enabled','notify_on_new_user','notify_on_new_consultation','notify_system_updates',
        'push_notify_enabled','push_notify_sound'
    ];

    // return the single settings row (singleton)
    public static function instance(): Setting
    {
        return static::first() ?? static::create();
    }
}
