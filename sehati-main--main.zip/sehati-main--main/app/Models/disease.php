<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Disease extends Model
{
    use HasFactory;
     public $timestamps = true;

    protected $fillable = [
        'name',
        'slug',
        'image',
        'short_description',
        'description',
        'causes',
        'symptoms',
        'prevention',
        'treatment',
        'status',
        'category_id',
        'content',
    ];

    public function articles()
    {
        return $this->hasMany(Article::class);
    }

    public function videos()
    {
        return $this->hasMany(Video::class);
    }

    public function tests()
    {
        return $this->hasMany(Test::class);
    }

    public function category()
    {
        return $this->belongsTo(DiseaseCategory::class, 'category_id');
    }
   public function reviews() {
    return $this->hasMany(Review::class);
}

public function avgRating(): ?float
{
    return $this->reviews()->avg('rating');
}
 public function getRouteKeyName()
    {
        return 'slug';
    }
}
