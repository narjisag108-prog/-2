<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class Medicine extends Model
{
    protected $fillable = [
        'user_id', 'name', 'dose', 'times_per_day', 'end_date'
    ];

    protected $casts = [
        'end_date' => 'date'
    ];

    public function is_active()
    {
        return !$this->end_date || $this->end_date->isFuture();
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
