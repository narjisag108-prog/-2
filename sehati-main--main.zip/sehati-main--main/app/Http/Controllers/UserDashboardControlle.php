<?php

namespace App\Http\Controllers;

use App\Models\Appointment;
use App\Models\Medicine;
use App\Models\SugarReading;
use App\Models\BloodPressureReading;
use App\Models\HeartReading;
use Illuminate\Support\Facades\Auth;

class UserDashboardControlle extends Controller
{
    public function index()
    {
        $user = Auth::user();

        // تقدم صحي (قيم مؤقتة)
        $weightProgress   = 65;
        $activityProgress = 70;
        $medsProgress     = 85;

        // =========================
        // آخر القراءات
        // =========================
        $latestSugar = SugarReading::where('user_id', $user->id)
            ->latest()
            ->first();

        $latestPressure = BloodPressureReading::where('user_id', $user->id)
            ->latest()
            ->first();

        $latestHeart = HeartReading::where('user_id', $user->id)
            ->latest()
            ->first();

        // =========================
        // الأنشطة الأخيرة (دمج)
        // =========================
        $activities = collect()
            ->merge(
                SugarReading::where('user_id', $user->id)
                    ->latest()->take(2)->get()
                    ->map(fn ($r) => [
                        'type' => 'sugar',
                        'value' => $r->value,
                        'date' => $r->created_at,
                    ])
            )
            ->merge(
                BloodPressureReading::where('user_id', $user->id)
                    ->latest()->take(2)->get()
                    ->map(fn ($r) => [
                        'type' => 'pressure',
                        'value' => $r->value_upper.'/'.$r->value_lower,
                        'date' => $r->created_at,
                    ])
            )
            ->merge(
                HeartReading::where('user_id', $user->id)
                    ->latest()->take(1)->get()
                    ->map(fn ($r) => [
                        'type' => 'heart',
                        'value' => $r->value,
                        'date' => $r->created_at,
                    ])
            )
            ->sortByDesc('date')
            ->take(5);

        // =========================
        // المواعيد القادمة
        // =========================
        $appointments = Appointment::where('user_id', $user->id)
            ->where('date', '>=', now())
            ->orderBy('date')
            ->take(3)
            ->get();

        // =========================
        // الأدوية
        // =========================
        $medicines = Medicine::where('user_id', $user->id)

            ->take(3)
            ->get();

        return view('user.dashboard', compact(
            'user',
            'appointments',
            'medicines',
            'latestSugar',
            'latestPressure',
            'latestHeart',
            'activities',
            'weightProgress',
            'activityProgress',
            'medsProgress'
        ));
    }
}
