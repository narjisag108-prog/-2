<?php

namespace App\Http\Controllers;

use App\Models\HealthReading;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class HealthController extends Controller
{
    public function index()
    {
        $readings = HealthReading::where('user_id', Auth::id())
                    ->latest()
                    ->take(10)
                    ->get();

        return view('health.index', compact('readings'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'blood_pressure' => 'nullable|string',
            'sugar' => 'nullable|numeric',
            'weight' => 'nullable|numeric',
            'notes' => 'nullable|string',
        ]);

        HealthReading::create([
            'user_id' => Auth::id(),
            'blood_pressure' => $request->blood_pressure,
            'sugar' => $request->sugar,
            'weight' => $request->weight,
            'notes' => $request->notes,
        ]);

        return back()->with('success', 'تم حفظ القراءة بنجاح');
    }
}
