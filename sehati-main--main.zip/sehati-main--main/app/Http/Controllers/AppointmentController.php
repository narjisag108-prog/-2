<?php

namespace App\Http\Controllers;

use App\Models\Appointment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AppointmentController extends Controller
{
    public function index()
    {
        $appointments = Appointment::where('user_id', Auth::id())
            ->orderBy('date', 'asc')
            ->get();

        return view('appointments.index', compact('appointments'));
    }

    public function create()
    {
        return view('appointments.create');
    }

    public function store(Request $request)
    {
       $request->validate([
    'title'       => 'required|string|max:191',
    'doctor_name' => 'required|string|max:191',
    'date'        => 'required|date',
    'time'        => 'required',
]);

Appointment::create([
    'user_id'     => Auth::id(),
    'title'       => $request->title,
    'doctor_name' => $request->doctor_name,
    'date'        => $request->date,
    'time'        => $request->time,
]);


        return redirect()
            ->route('appointments.index')
            ->with('success', 'تم حفظ الموعد بنجاح');
    }


    public function edit(Appointment $appointment)
    {
        // حماية: المستخدم يعدّل بس مواعيده
        if ($appointment->user_id !== Auth::id()) {
            abort(403);
        }

        return view('appointments.edit', compact('appointment'));
    }


    public function update(Request $request, Appointment $appointment)
    {
        if ($appointment->user_id !== Auth::id()) {
            abort(403);
        }

       $appointment->update([
    'title'       => $request->title,
    'doctor_name' => $request->doctor_name,
    'date'        => $request->date,
    'time'        => $request->time,
]);

        $appointment->update([
            'title' => $request->title,
            'doctor_name' => $request->doctor_name,
            'date'  => $request->date,
            'time'  => $request->time,
        ]);

        return redirect()
            ->route('appointments.index')
            ->with('success', 'تم تعديل الموعد بنجاح');
    }


    public function destroy(Appointment $appointment)
    {
        if ($appointment->user_id !== Auth::id()) {
            abort(403);
        }

        $appointment->delete();

        return redirect()
            ->route('appointments.index')
            ->with('success', 'تم حذف الموعد بنجاح');
    }
}
