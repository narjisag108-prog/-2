<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;

class AuthController extends Controller
{
    public function loginView()
    {
        return view('login');
    }

public function login(Request $request)
{
    $credentials = $request->validate([
        'email' => 'required|email',
        'password' => 'required',
    ]);

    if (!Auth::attempt($credentials)) {
        return back()->withErrors([
            'email' => 'بيانات الدخول غير صحيحة'
        ]);
    }

    $request->session()->regenerate();
    $user = Auth::user();

    // 🔴 تحقق من الحظر أولاً
    if ($user->status === 'banned') {
        Auth::logout();
        return back()->withErrors([
            'email' => 'تم حظر حسابك، يرجى التواصل مع الإدارة'
        ]);
    }

    // 🔁 التوجيه حسب الدور
    return match ($user->role) {
        'admin'  => redirect()->route('admin.dashboard'),
        'doctor' => redirect()->route('doctor.dashboard'),
        default  => redirect()->route('user.dashboard'),
    };
}



    public function registerView()
    {
        return view('register');
    }

    public function register(Request $request)
    {
        $data = $request->validate([
            'first_name' => 'required',
            'last_name'  => 'required',
            'email'      => 'required|email|unique:users',
            'password'   => 'required|confirmed|min:6',
        ]);

        $user = User::create([
            'first_name' => $data['first_name'],
             'last_name' => $data['last_name'],
            'email' => $data['email'],
            'password' => bcrypt($data['password']),
            'role'=> 'user',
        ]);

        Auth::login($user);

        return redirect()->route('home')->with('success', 'تم إنشاء الحساب بنجاح 🎉');
    }

   public function logout()
{
    Auth::logout();
    return redirect()->route('login')->with('success','تم تسجيل الخروج بنجاح 👋');
}

}
