<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class ContactController extends Controller
{
    public function show()
    {
        return view('contact');
    }

    public function send(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:191',
            'email' => 'required|email',
            'subject' => 'required|string|max:191',
            'message' => 'required|string',
        ]);

        // هنا يمكنك إرسال رسالة عبر البريد أو تخزينها في قاعدة البيانات
        // مثال: Mail::to('admin@site.com')->send(new ContactMail($request->all()));

        return redirect()->route('contact.show')->with('success', 'تم إرسال رسالتك بنجاح!');
    }
}
