<?php

namespace App\Http\Controllers;

use App\Models\SugarReading;
use App\Models\BloodPressureReading;
use App\Models\HeartReading;
use App\Models\Activity;

use Illuminate\Support\Facades\Auth;

class HealthDashboardController extends Controller
{
    public function index()
    {
        $userId = Auth::id();

        // 🟦 سكر الدم
        $sugarAvg = SugarReading::where('user_id', $userId)->avg('value') ?? 0;
        $latestSugar = SugarReading::where('user_id', $userId)
            ->latest()
            ->first();

        // 🟥 ضغط الدم
        $pressureUpperAvg = BloodPressureReading::where('user_id', $userId)
            ->avg('value_upper') ?? 0;

        $pressureLowerAvg = BloodPressureReading::where('user_id', $userId)
            ->avg('value_lower') ?? 0;

        $latestPressure = BloodPressureReading::where('user_id', $userId)
            ->latest()
            ->first();

        // 🟧 نبض القلب
        $heartAvg = HeartReading::where('user_id', $userId)->avg('value') ?? 0;
        $latestHeart = HeartReading::where('user_id', $userId)
            ->latest()
            ->first();

$activities = Activity::where('user_id', auth::id())
    ->latest()
    ->take(5)
    ->get();
       return view('readings.dashboard', compact(
    'sugarAvg',
    'pressureUpperAvg',
    'pressureLowerAvg',
    'heartAvg',
    'latestSugar',
    'latestPressure',
    'latestHeart',
    'activities'
));

    }
}
