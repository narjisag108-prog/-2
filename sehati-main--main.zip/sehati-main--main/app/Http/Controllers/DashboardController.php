<?php

namespace App\Http\Controllers;

use App\Models\BloodPressureReading;
use App\Models\SugarReading;
use App\Models\HeartReading;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    public function index()
    {
        $uid = Auth::id();

        $pressureAvg = BloodPressureReading::where('user_id', $uid)->avg('value_upper');
        $sugarAvg    = SugarReading::where('user_id', $uid)->avg('value');
        $heartAvg    = HeartReading::where('user_id', $uid)->avg('value');

        $latestPressure = BloodPressureReading::where('user_id', $uid)->latest()->first();
        $latestSugar    = SugarReading::where('user_id', $uid)->latest()->first();
        $latestHeart    = HeartReading::where('user_id', $uid)->latest()->first();

        return view('readings.dashboard', compact(
            'pressureAvg','sugarAvg','heartAvg',
            'latestPressure','latestSugar','latestHeart'
        ));
    }
}
