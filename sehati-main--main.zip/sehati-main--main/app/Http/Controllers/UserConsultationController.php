<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Consultation;
use App\Models\Disease;
use App\Models\Appointment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class UserConsultationController extends Controller
{
    public function index()
    {
        $consultations = Consultation::where('user_id', Auth::id())
  ->orderByRaw("status = 'pending' DESC")
        ->latest()
            ->get();

        return view('user.consultations.index', compact('consultations'));
    }

    public function create()
    {
        return view('user.consultations.create', [
            'diseases' => Disease::all(),
            'appointments' => Appointment::where('user_id', Auth::id())->get()
        ]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required',
            'message' => 'required',
        ]);

        Consultation::create([
            'user_id' => Auth::id(),
            'doctor_id' => $request->doctor_id, // اختياري
            'disease_id' => $request->disease_id,
            'appointment_id' => $request->appointment_id,
            'title' => $request->title,
            'message' => $request->message,
            'status' => 'pending',
        ]);

        return redirect()
            ->route('user.consultations.index')
            ->with('success','تم إرسال الاستشارة');
    }

    public function show(Consultation $consultation)
    {
        abort_if($consultation->user_id !== Auth::id(), 403);

        return view('user.consultations.show', compact('consultation'));
    }
}
