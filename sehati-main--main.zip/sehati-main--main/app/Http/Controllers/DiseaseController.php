<?php
// app/Http/Controllers/DiseaseController.php

namespace App\Http\Controllers;

use App\Models\Disease;
use Illuminate\Http\Request;

class DiseaseController extends Controller
{
    public function index()
    {
        $diseases = Disease::all();
        return view('diseases.index', compact('diseases'));
    }

    public function show(Disease $disease)
    {
        return view('diseases.show', compact('disease'));
    }
}


