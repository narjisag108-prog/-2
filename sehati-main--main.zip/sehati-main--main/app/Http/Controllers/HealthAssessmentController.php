<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\AssessmentResult;

class AssessmentController extends Controller
{
    public function create()
    {
        return view('assessment.form');
    }

    public function store(Request $request)
    {
        $request->validate([
            'age' => 'required',
            'gender' => 'required',
            'family_history' => 'required',
            'bmi' => 'required',
            'activity' => 'required',
            'blood_pressure' => 'required',
        ]);

        // حساب مجموع النقاط
        $score =
            (int)$request->age +
            (int)$request->family_history +
            (int)$request->bmi +
            (int)$request->activity +
            (int)$request->blood_pressure;

        // تحديد مستوى الخطر
        if ($score <= 6) {
            $level = 'منخفض';
            $color = 'green';
            $advice = 'صحتك ممتازة، استمر على أسلوب حياة صحي ورياضة.';
        } elseif ($score <= 12) {
            $level = 'متوسط';
            $color = 'orange';
            $advice = 'اهتم بالرياضة أكثر وحاول تحسين نظامك الغذائي.';
        } else {
            $level = 'مرتفع';
            $color = 'red';
            $advice = 'ننصحك بمتابعة المؤشرات الصحية وزيارة طبيب مختص.';
        }

        // تخزين النتيجة في الداتابيز
        AssessmentResult::create([
            'user_id' => Auth::id(),
            'score' => $score,
            'level' => $level,
        ]);

        return view('assessment.result', compact('score', 'level', 'color', 'advice'));
    }
}
