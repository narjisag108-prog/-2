<?php

namespace App\Http\Controllers;

use App\Models\SugarReading;
use Illuminate\Http\Request;
use App\Models\Activity;

use Illuminate\Support\Facades\Auth;

class SugarController extends Controller
{
    public function index()
    {
        $readings = SugarReading::where('user_id', Auth::id())
                    ->latest()
                    ->take(10)
                    ->get();

        return view('readings.sugar', compact('readings'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'value' => 'required|numeric|min:20|max:600',
            'note' => 'nullable|string'
        ]);

        SugarReading::create([
            'user_id' => Auth::id(),
            'value' => $request->value,
            'note' => $request->note
        ]);
        Activity::create([
    'user_id' => Auth::id(),
    'type' => 'sugar',
    'title' => 'تم تسجيل قراءة سكر الدم',
]);


        return back()->with('success', 'تم إضافة قراءة السكر بنجاح');
    }
}
