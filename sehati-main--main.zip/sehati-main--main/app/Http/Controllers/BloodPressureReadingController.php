<?php

namespace App\Http\Controllers;

use App\Models\BloodPressureReading;
use Illuminate\Http\Request;
use App\Models\Activity;
use Illuminate\Support\Facades\Auth;




class BloodPressureReadingController extends Controller
{
    public function index()
    {
        $readings = BloodPressureReading::where('user_id', Auth::id())
                    ->latest()
                    ->take(10)
                    ->get();

        return view('readings.blood-pressure', compact('readings'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'value_upper' => 'required|integer',
            'value_lower' => 'required|integer',
        ]);

        BloodPressureReading::create([
            'user_id' => Auth::id(),
            'value_upper' => $request->value_upper,
            'value_lower' => $request->value_lower,
        ]);



Activity::create([
    'user_id' => Auth::id(),
    'type' => 'blood_pressure',
    'title' => 'تم تسجيل قراءة ضغط الدم',
]);


        return back()->with('success', 'تم إضافة قراءة ضغط الدم بنجاح');
    }
}
