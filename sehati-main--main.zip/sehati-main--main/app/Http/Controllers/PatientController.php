<?php

namespace App\Http\Controllers;

use App\Models\Patient;
use App\Models\Appointment;
use App\Models\Consultation;
use Illuminate\Http\Request;

class PatientController extends Controller
{
    public function index()
    {
        $patients = Patient::latest()->get();
        return view('doctor.patients.index', compact('patients'));
    }

    public function create()
    {
        return view('doctor.patients.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name'  => 'required|string|max:191',
            'phone' => 'nullable|string|max:20',
            'age'   => 'nullable|integer',
        ]);

        Patient::create($request->only('name','phone','age'));

        return redirect()
            ->route('doctor.patients.index')
            ->with('success','تم تسجيل المريض بنجاح');
    }

    public function show(Patient $patient)
    {
        $appointments = $patient->appointments()->latest()->limit(5)->get();
        $consultations = $patient->consultations()->latest()->limit(5)->get();

        return view('doctor.patients.show', compact(
            'patient','appointments','consultations'
        ));
    }
}
