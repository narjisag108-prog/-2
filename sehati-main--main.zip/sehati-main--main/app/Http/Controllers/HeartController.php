<?php

namespace App\Http\Controllers;

use App\Models\HeartReading;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class HeartController extends Controller
{
    public function index()
    {
        $readings = HeartReading::where('user_id', Auth::id())
                    ->latest()
                    ->take(10)
                    ->get();

        return view('readings.heart', compact('readings'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'value' => 'required|numeric|min:30|max:220',
        ]);

        HeartReading::create([
            'user_id' => Auth::id(),
            'value' => $request->value,
        ]);

        return back()->with('success', 'تم إضافة قراءة نبض القلب بنجاح');
    }
}
