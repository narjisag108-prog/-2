<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Disease;
use App\Models\DiseaseCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class DiseaseAdminController extends Controller
{
    public function index()
    {
        $q = request('q');
        $category_id = request('category_id');
        $status = request('status');

        $categories = DiseaseCategory::all();

        $diseases = Disease::with(['category', 'articles', 'tests'])
            ->when($q, fn($query)=> $query->where('name', 'like', "%{$q}%"))
            ->when($category_id, fn($query)=> $query->where('category_id', $category_id))
            ->when($status, fn($query)=> $query->where('status', $status))
            ->latest()
            ->paginate(12)
            ->withQueryString();

        return view('admin.diseases.index', compact('diseases','categories'));
    }

    public function create()
    {
        $categories = DiseaseCategory::all();
        return view('admin.diseases.create', compact('categories'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name'=>'required|string|max:191',
            'category_id' => 'nullable|exists:disease_categories,id',
            'description'=>'nullable|string',
            'causes'=>'nullable|string',
            'symptoms'=>'nullable|string',
            'prevention'=>'nullable|string',
            'treatment'=>'nullable|string',
            'status'=>'nullable|in:active,inactive',
            'slug'=>'nullable',
            'short_description'=>'nullable',
            
        ]);

        $data['status'] = $data['status'] ?? 'active';

 if (empty($data['slug']) && !empty($data['description'])) {
    $data['slug'] = Str::slug($data['description']);
}
if (empty($data['short_description']) && !empty($data['description'])) {
    $data['short_description'] = Str::slug($data['description']);
}

        Disease::create($data);

        return redirect()->route('admin.diseases.index')->with('success','تمت إضافة المرض بنجاح.');
    }

    public function show(Disease $disease)
    {
        $disease->load(['category', 'articles', 'tests']);
        return view('admin.diseases.show', compact('disease'));
    }

    public function edit(Disease $disease)
    {
        $categories = DiseaseCategory::all();
        return view('admin.diseases.edit', compact('disease','categories'));
    }

    public function update(Request $request, Disease $disease)
    {
        $data = $request->validate([
            'name'=>'required|string|max:191',
            'category_id' => 'nullable|exists:disease_categories,id',
            'description'=>'nullable|string',
            'causes'=>'nullable|string',
            'symptoms'=>'nullable|string',
            'prevention'=>'nullable|string',
            'treatment'=>'nullable|string',
            'status'=>'nullable|in:active,inactive',
        ]);

        $data['status'] = $data['status'] ?? 'active';

        $disease->update($data);

        return redirect()->route('admin.diseases.index')->with('success', 'تم تحديث بيانات المرض بنجاح.');
    }

    public function destroy(Disease $disease)
    {
        $disease->delete();
        return redirect()->route('admin.diseases.index')->with('success','تم حذف المرض.');
    }
}
