<?php

  namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Consultation;
use App\Models\User;
use App\Models\Disease;
use App\Models\ConsultationReply;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ConsultationAdminController extends Controller
{
    public function index(Request $request)
    {
        $search    = $request->q;
        $diseaseId = $request->disease_id;
        $doctorId  = $request->doctor_id;
        $status    = $request->status;

        $query = Consultation::with(['user','doctor','disease']);

        if ($search) {
            $query->where(function ($sub) use ($search) {
                $sub->where('subject', 'like', "%$search%")
                    ->orWhereHas('user', function ($u) use ($search) {
                        $u->where('name', 'like', "%$search%")
                          ->orWhere('email', 'like', "%$search%");
                    });
            });
        }

        if ($diseaseId) {
            $query->where('disease_id', $diseaseId);
        }

        if ($doctorId) {
            $query->where('doctor_id', $doctorId);
        }

        if ($status) {
            $query->where('status', $status); // new/review/completed/canceled
        }

        $consultations = $query->latest()->paginate(10)->withQueryString();

        $newCount       = Consultation::where('status','new')->count();
        $newWeekCount   = Consultation::where('status','new')
                            ->where('created_at','>=',now()->subWeek())
                            ->count();
        $reviewCount    = Consultation::where('status','review')->count();
        $completedCount = Consultation::where('status','completed')->count();
        $canceledCount  = Consultation::where('status','canceled')->count();

        $diseases = Disease::all();
        // $doctors  = User::where('role','doctor')->get();

        return view('admin.consultations.index', compact(
            'consultations',
            'newCount','newWeekCount',
            'reviewCount','completedCount','canceledCount',
            'diseases',
        ));
    }

    public function show($id)
    {
        $consultation = Consultation::with(['user','doctor','disease','replies.admin'])->findOrFail($id);
        return view('admin.consultations.show', compact('consultation'));
    }

    public function edit($id)
    {
        $consultation = Consultation::findOrFail($id);
        $doctors      = User::where('role','doctor')->get();
        return view('admin.consultations.edit', compact('consultation','doctors'));
    }

   public function update(Request $request, $id)
{
    $request->validate([
        'doctor_id' => 'nullable|exists:users,id',
        'status'    => 'required|in:pending,answered,closed',
    ]);

    $consultation = Consultation::findOrFail($id);

    $consultation->update([
        'doctor_id' => $request->doctor_id,
        'status'    => $request->status,
    ]);

    return redirect()
        ->route('admin.consultations.index')
        ->with('success','تم تحديث الاستشارة');
}


    public function destroy($id)
    {
        Consultation::destroy($id);
        return back()->with('success', 'تم حذف الاستشارة');
    }


//     public function create()
// {
//     // $users    = User::where('role', 'user')->get();    // المرضى
//     // $doctors  = User::where('role', 'doctor')->get();  // الأطباء
//     $diseases = Disease::all();

//     return view('admin.consultations.create', compact(
//         // 'users',
//         // 'doctors',
//         'diseases'
//     ));
// }
// public function store(Request $request)
// {
//     $request->validate([
//         'user_id'    => 'required|exists:users,id',
//         'subject'    => 'required|string|max:255',
//         'message'    => 'required|string',
//         'disease_id' => 'nullable|exists:diseases,id',
//         'doctor_id'  => 'nullable|exists:users,id',
//         'status'     => 'required|in:new,review,completed,canceled',
//     ]);

//     Consultation::create([
//         'user_id'    => $request->user_id,
//         'subject'    => $request->subject,
//         'message'    => $request->message,
//         'disease_id' => $request->disease_id,
//         'doctor_id'  => $request->doctor_id,
//         'status'     => $request->status,
//     ]);

//     return redirect()
//         ->route('admin.consultations.index')
//         ->with('success', 'تمت إضافة الاستشارة بنجاح');
// }

}
