<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Test;
use App\Models\Disease;
use Illuminate\Http\Request;

class TestAdminController extends Controller
{
    // عرض صفحة جميع الاختبارات + الإحصائيات + البحث
   public function index(Request $request)
{
    // الإحصائيات
    $totalTests = Test::count();
    $completedTests = Test::where('status','completed')->count();

    $completionRate = $totalTests > 0
        ? round(($completedTests / $totalTests) * 100, 1)
        : 0;

    $averageRating = Test::avg('rating');

    // البحث + الفلاتر
    $q = $request->q;
    $status = $request->status;
    $disease_id = $request->disease_id;

    $tests = Test::with('disease')
        ->when($q, function ($query) use ($q) {
            return $query->where('title', 'like', "%{$q}%");
        })
        ->when($status, function ($query) use ($status) {
            return $query->where('status', $status);
        })
        ->when($disease_id, function ($query) use ($disease_id) {
            return $query->where('disease_id', $disease_id);
        })
        ->latest()
        ->paginate(12)
        ->withQueryString();

    // نرسل الأمراض للواجهة
    $diseases = Disease::all();

    return view('admin.tests.index', compact(
        'tests',
        'totalTests',
        'completedTests',
        'completionRate',
        'averageRating',
        'diseases'
    ));
}


    // صفحة إنشاء اختبار جديد
    public function create()
    {
        $diseases = Disease::all();
        return view('admin.tests.create', compact('diseases'));
    }

    // تخزين اختبار جديد
    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'disease_id' => 'nullable|exists:diseases,id',
            'description' => 'nullable|string',
            'status'=>'nullable|in:active,inactive'

        ]);

        // إنشاء اختبار
        Test::create($validated);
        return redirect()->route('admin.tests.index')
                         ->with('success', 'تم إضافة الاختبار بنجاح');
    }

    // عرض التفاصيل
    public function show($id)
    {
        $test = Test::with('questions', 'disease')->findOrFail($id);
        return view('admin.tests.show', compact('test'));
    }

    // صفحة تعديل اختبار
    public function edit($id)
    {
        $test = Test::findOrFail($id);
        $diseases = Disease::all();
        return view('admin.tests.edit', compact('test', 'diseases'));
    }

    // تحديث اختبار
    public function update(Request $request, $id)
    {
        $test = Test::findOrFail($id);

        $data = $request->validate([
            'title' => 'required|string|max:255',
            'disease_id' => 'nullable|exists:diseases,id',
            'description' => 'nullable|string',
            'status'=>'nullable|in:active,inactive'

        ]);

        $test->update($data);

        return redirect()->route('admin.tests.index')
                         ->with('success', 'تم تحديث الاختبار بنجاح');
    }

    // حذف اختبار
    public function destroy($id)
    {
        $test = Test::findOrFail($id);
        $test->delete();

        return redirect()->route('admin.tests.index')
                         ->with('success', 'تم حذف الاختبار بنجاح');
    }
}
