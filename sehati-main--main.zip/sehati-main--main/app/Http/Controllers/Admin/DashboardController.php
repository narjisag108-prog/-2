<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Article;
// use App\Models\TestResult;
use App\Models\Consultation;
// use App\Models\Activity;

use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
{
    return view('admin.dashboard',[
        'usersCount' => User::count(),
        'usersThisWeek' => User::whereBetween('created_at',[now()->subWeek(),now()])->count(),

        'articlesCount' => Article::count(),
        'articlesThisWeek' => Article::whereBetween('created_at',[now()->subWeek(),now()])->count(),

        // 'testsCompleted' => TestResult::count(),
        // 'testsThisWeek' => TestResult::whereBetween('created_at',[now()->subWeek(),now()])->count(),

        'newConsultations' => Consultation::where('status','new')->count(),
        'consultationsThisWeek' => Consultation::whereBetween('created_at',[now()->subWeek(),now()])->count(),

        // 'activities' => Activity::latest()->take(5)->get(),
        'latestArticles' => Article::latest()->paginate(5),
    ]);
}

}
