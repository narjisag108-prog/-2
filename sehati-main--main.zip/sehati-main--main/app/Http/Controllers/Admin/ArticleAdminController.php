<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Article;
use App\Models\Disease;
use Illuminate\Http\Request;

class ArticleAdminController extends Controller
{
    public function index()
    {
        $q = request('q');

        $articlesQuery = Article::with('disease')
            ->when($q, function ($query) use ($q) {
                $query->where('title', 'like', "%$q%")
                      ->orWhere('author_name', 'like', "%$q%");
            });

        $latestArticles = $articlesQuery->latest()->paginate(10);

        $newArticles    = Article::where('created_at', '>=', now()->subDays(7))->count();
        $totalArticles  = Article::count();
        $activeArticles = Article::where('status', 'published')->count();
        $writersCount   = Article::distinct('author_name')->count('author_name');

        $activities = Article::orderBy('created_at', 'desc')
            ->limit(5)
            ->get()
            ->map(function ($a) {
                return (object)[
                    'text' => "تم نشر مقال جديد: " . $a->title,
                    'created_at' => $a->created_at,
                ];
            });

        return view('admin.articles.index', compact(
            'newArticles',
            'totalArticles',
            'activeArticles',
            'writersCount',
            'activities',
            'latestArticles'
        ));
    }

    public function create()
    {
        $diseases = Disease::all();
        return view('admin.articles.create', compact('diseases'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'title'       => 'required|string|max:255',
            'content'     => 'required|string',
            'disease_id'  => 'nullable|exists:diseases,id',
            'author_name' => 'required|string|max:100',
            'status'      => 'required|in:published,draft',
        ]);

        Article::create($data);

        return redirect()->route('admin.articles.index')
                         ->with('success', 'تمت إضافة المقال بنجاح');
    }

    public function edit($id)
    {
        $article  = Article::findOrFail($id);
        $diseases = Disease::all();

        return view('admin.articles.edit', compact('article', 'diseases'));
    }

    public function update(Request $request, $id)
    {
        $article = Article::findOrFail($id);

        $data = $request->validate([
            'title'       => 'required|string|max:255',
            'content'     => 'required|string',
            'disease_id'  => 'nullable|exists:diseases,id',
            'author_name' => 'required|string|max:100',
            'status'      => 'required|in:published,draft',
        ]);

        $article->update($data);

        return redirect()->route('admin.articles.index')
                         ->with('success', 'تم تحديث المقال بنجاح');
    }

    public function show($id)
    {
        $article = Article::with('disease')->findOrFail($id);
        return view('admin.articles.show', compact('article'));
    }

    public function destroy($id)
    {
        Article::findOrFail($id)->delete();
        return redirect()->route('admin.articles.index')
                         ->with('success', 'تم حذف المقال بنجاح');
    }
}
