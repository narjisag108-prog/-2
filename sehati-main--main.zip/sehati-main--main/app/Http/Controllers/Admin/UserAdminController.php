<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;

class UserAdminController extends Controller
{
    // عرض المستخدمين
    public function index(Request $request)
    {
        $query = User::query();

        if ($request->q) {
            $query->where(function($q) use ($request){
                $q->where('name', 'like', "%{$request->q}%")
                  ->orWhere('email', 'like', "%{$request->q}%");
            });
        }

        if ($request->role) {
            $query->where('role', $request->role);
        }

        if ($request->status) {
            $query->where('status', $request->status);
        }

        $users = $query->orderBy('id','DESC')->paginate(10);

        return view('admin.users.index', compact('users'));

    }

    // صفحة الإضافة
    public function create()
    {
        return view('admin.users.create');
    }

    // حفظ مستخدم جديد
    public function store(Request $request)
    {
        $request->validate([
            'name'=>'required',
            'email'=>'required|email|unique:users',
            'password'=>'required|min:6',
            'role'=>'required',
            'status'=>'required'
        ]);

        $data = $request->except('password');
        $data['password'] = bcrypt($request->password);

        if ($request->hasFile('avatar')) {
            $data['avatar'] = $request->file('avatar')->store('avatars','public');
        }

        User::create($data);

        return redirect()->route('admin.users.index')->with('success','تم إضافة مستخدم');
    }

    // صفحة التعديل
    public function edit(User $user)
    {
        return view('admin.users.edit', compact('user'));
    }

    // تحديث
    public function update(Request $request, User $user)
    {
        $request->validate([
            'name'=>'required',
            'email'=>"required|email|unique:users,email,$user->id",
            'role'=>'required',
            'status'=>'required'
        ]);

        $data = $request->except('password');

        if ($request->password) {
            $data['password'] = bcrypt($request->password);
        }

        if ($request->hasFile('avatar')) {
            $data['avatar'] = $request->file('avatar')->store('avatars','public');
        }

        $user->update($data);

        return redirect()->route('admin.users.index')->with('success','تم تحديث المستخدم');
    }

    // حذف
    public function destroy(User $user)
    {
        $user->delete();
        return back()->with('success','تم الحذف بنجاح');
    }

    // عرض التفاصيل
    public function show(User $user)
    {
        return view('admin.users.show', compact('user'));
    }


public function toggleStatus(User $user)
{
    // لو عندك status = active / banned
    $user->status = $user->status === 'banned' ? 'active' : 'banned';
    $user->save();

    return back()->with('success', 'تم تغيير حالة المستخدم بنجاح');
}

}
