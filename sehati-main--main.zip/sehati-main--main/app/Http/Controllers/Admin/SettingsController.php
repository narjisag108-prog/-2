<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Setting;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;

class SettingsController extends Controller
{
    // عرض صفحة الإعدادات
    public function index()
    {
        $settings = Setting::instance();
        return view('admin.settings.index', compact('settings'));
    }

    // تحديث الإعدادات
    public function update(Request $request)
    {
        $settings = Setting::instance();
        $tab = $request->input('tab', 'profile');

        switch ($tab) {

            /* ================= PROFILE ================= */
            case 'profile':
                $data = $request->validate([
                    'admin_first_name' => 'nullable|string|max:191',
                    'admin_last_name'  => 'nullable|string|max:191',
                    'admin_email'      => 'nullable|email|max:191',
                    'admin_phone'      => 'nullable|string|max:40',
                    'admin_bio'        => 'nullable|string',
                    'admin_avatar'     => 'nullable|image|max:2048',
                ]);

                if ($request->hasFile('admin_avatar')) {
                    if ($settings->admin_avatar) {
                        Storage::disk('public')->delete($settings->admin_avatar);
                    }
                    $data['admin_avatar'] = $request->file('admin_avatar')
                                                     ->store('avatars', 'public');
                }

                $settings->update($data);
                break;

            /* ================= SECURITY ================= */
            case 'security':
                $request->validate([
                    'current_password' => 'required',
                    'new_password'     => 'required|min:8|confirmed',
                ]);

                $user = $request->user();

                if (!Hash::check($request->current_password, $user->password)) {
                    return back()->withErrors([
                        'current_password' => 'كلمة المرور الحالية غير صحيحة'
                    ]);
                }

                $user->update([
                    'password' => Hash::make($request->new_password)
                ]);
                break;

            /* ================= NOTIFICATIONS ================= */
            case 'notifications':
                $settings->update([
                    'notify_email_enabled'       => $request->has('notify_email_enabled'),
                    'notify_on_new_user'         => $request->has('notify_on_new_user'),
                    'notify_on_new_consultation' => $request->has('notify_on_new_consultation'),
                    'notify_system_updates'      => $request->has('notify_system_updates'),
                    'push_notify_enabled'        => $request->has('push_notify_enabled'),
                    'push_notify_sound'          => $request->has('push_notify_sound'),
                ]);
                break;

            /* ================= SYSTEM ================= */
            case 'system':
                $data = $request->validate([
                    'site_name'        => 'nullable|string|max:191',
                    'site_logo'        => 'nullable|image|max:2048',
                    'analytics_code'   => 'nullable|string',
                ]);

                if ($request->hasFile('site_logo')) {
                    if ($settings->site_logo) {
                        Storage::disk('public')->delete($settings->site_logo);
                    }
                    $data['site_logo'] = $request->file('site_logo')
                                                  ->store('logos', 'public');
                }

                $data['maintenance_mode'] = $request->has('maintenance_mode');
                $settings->update($data);
                break;
        }

        return redirect()
            ->route('admin.settings.index')
            ->with('success', 'تم حفظ التغييرات بنجاح');
    }
}
