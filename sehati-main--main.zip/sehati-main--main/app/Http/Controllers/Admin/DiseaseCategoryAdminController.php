<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\DiseaseCategory;

use Illuminate\Http\Request;

class DiseaseCategoryAdminController extends Controller
{
    public function index()
    {
        $categories = DiseaseCategory::latest()->paginate(20);
        return view('admin.categories.index', compact('categories'));
    }

    public function create()
    {
        return view('admin.categories.create');
    }

    public function store(Request $request)
    {
        $data = $request->validate(['name' => 'required|string|max:191']);
        DiseaseCategory::create($data);

        return redirect()->route('admin.categories.index')->with('success','تمت إضافة التصنيف');
    }

    public function edit($category)
{
    $category = DiseaseCategory::findOrFail($category);
    return view('admin.categories.edit', compact('category'));
}
public function update(Request $request, DiseaseCategory $category)
{
    $data = $request->validate([
        'name' => 'required|string|max:191'
    ]);

    $category->update($data);

    return redirect()->route('admin.categories.index')->with('success','تم تعديل التصنيف');
}

    public function destroy(DiseaseCategory $category)
    {
        $category->delete();
        return back()->with('success','تم حذف التصنيف');
    }
}

