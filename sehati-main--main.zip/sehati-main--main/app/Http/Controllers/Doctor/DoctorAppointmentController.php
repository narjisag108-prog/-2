<?php

namespace App\Http\Controllers\Doctor;

use App\Http\Controllers\Controller;
use App\Models\Appointment;
use App\Models\Patient;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DoctorAppointmentController extends Controller
{
    public function index()
    {
         $appointments = Appointment::with('patient')
        ->orderBy('date')
        ->orderBy('time')
        ->get();


        return view('doctor.appointments.index', compact('appointments'));
    }

    public function create()
    {
        $patients = Patient::all();
        return view('doctor.appointments.create', compact('patients'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'patient_id' => 'required|exists:patients,id',
            'date'       => 'required|date',
            'time'       => 'required',
            'notes'      => 'nullable|string',
        ]);

        Appointment::create([
            'doctor_id'  => Auth::id(),
            'patient_id' => $request->patient_id,
            'date'       => $request->date,
            'time'       => $request->time,
            'status'     => 'confirmed',
            'notes'      => $request->notes,
        ]);

        return redirect()
            ->route('doctor.appointments.index')
            ->with('success','تم إضافة الموعد بنجاح');
    }

    public function edit(Appointment $appointment)
    {
        $this->authorizeDoctor($appointment);
        return view('doctor.appointments.edit', compact('appointment'));
    }

    public function update(Request $request, Appointment $appointment)
    {
        $this->authorizeDoctor($appointment);

        $appointment->update([
            'date'   => $request->date,
            'time'   => $request->time,
            'status' => $request->status,
            'notes'  => $request->notes,
        ]);

        return redirect()
            ->route('doctor.appointments.index')
            ->with('success','تم تحديث الموعد');
    }

    public function destroy(Appointment $appointment)
    {
        $this->authorizeDoctor($appointment);
        $appointment->delete();

        return back()->with('success','تم حذف الموعد');
    }

    private function authorizeDoctor(Appointment $appointment)
    {
        if ($appointment->doctor_id !== Auth::id()) {
            abort(403);
        }
    }
}
