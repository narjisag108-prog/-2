<?php

namespace App\Http\Controllers\Doctor;

use App\Http\Controllers\Controller;
use App\Models\MedicalReport;
use App\Models\Patient;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class MedicalReportController extends Controller
{
    public function create(Patient $patient)
    {
        return view('doctor.reports.create', compact('patient'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'patient_id'=>'required',
            'title'=>'required',
            'content'=>'required',
        ]);

        MedicalReport::create([
            'doctor_id'=>Auth::id(),
            'patient_id'=>$request->patient_id,
            'title'=>$request->title,
            'content'=>$request->content,
        ]);

        return redirect()->route('doctor.dashboard')
            ->with('success','تم حفظ التقرير الطبي');
    }
}
