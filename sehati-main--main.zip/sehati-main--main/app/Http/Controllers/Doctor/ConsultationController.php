<?php

namespace App\Http\Controllers\Doctor;

use App\Http\Controllers\Controller;
use App\Models\Consultation;
use App\Models\ConsultationReply;
use App\Models\Appointment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ConsultationController extends Controller
{
    // قائمة الاستشارات
    public function index()
{
    $consultations = Consultation::with(['user','appointment','disease'])
        ->whereIn('status',['new','pending'])
        ->latest()
        ->get();

    return view('doctor.consultations.index', compact('consultations'));
}



    // عرض استشارة
    public function show(Consultation $consultation)
    {
        abort_if($consultation->doctor_id !== Auth::id(), 403);

        $replies = $consultation->replies;

        return view('doctor.consultations.show', compact('consultation','replies'));
    }

    // حفظ الرد
    public function reply(Request $request, Consultation $consultation)
    {
        abort_if($consultation->doctor_id !== Auth::id(), 403);

        $request->validate([
            'reply' => 'required|string'
        ]);

        ConsultationReply::create([
            'consultation_id' => $consultation->id,
            'doctor_id'       => Auth::id(),
            'reply'           => $request->reply,
        ]);

        $consultation->update([
            'status' => 'answered'
        ]);

        return back()->with('success','تم الرد على الاستشارة');
    }
}
