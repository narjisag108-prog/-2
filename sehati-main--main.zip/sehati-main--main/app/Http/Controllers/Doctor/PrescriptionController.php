<?php

namespace App\Http\Controllers\Doctor;

use App\Http\Controllers\Controller;
use App\Models\Prescription;
use App\Models\Patient;
use App\Models\Appointment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PrescriptionController extends Controller
{
    public function index()
    {
        $prescriptions = Prescription::where('doctor_id', Auth::id())
            ->latest()
            ->get();

        return view('doctor.prescriptions.index', compact('prescriptions'));
    }

    public function create()
    {
        $patients = Patient::all();
        $appointments = Appointment::latest()->get();

        return view('doctor.prescriptions.create', compact('patients','appointments'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'patient_id' => 'required|exists:patients,id',
            'medicines'  => 'required',
        ]);

        Prescription::create([
            'doctor_id'      => Auth::id(),
            'patient_id'     => $request->patient_id,
            'appointment_id' => $request->appointment_id,
            'diagnosis'      => $request->diagnosis,
            'medicines'      => $request->medicines,
            'notes'          => $request->notes,
        ]);

        return redirect()
            ->route('doctor.prescriptions.index')
            ->with('success','تم إنشاء الوصفة الطبية');
    }
}

