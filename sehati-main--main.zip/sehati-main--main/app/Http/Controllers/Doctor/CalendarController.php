<?php

namespace App\Http\Controllers\Doctor;

use App\Http\Controllers\Controller;
use App\Models\Appointment;

class CalendarController extends Controller
{
    public function events()
    {
        return Appointment::with('patient')
            ->get()
            ->map(function ($a) {
                return [
                    'title' => $a->patient->name . ' - ' . $a->title,
                    'start' => $a->date->format('Y-m-d') . 'T' . $a->time,
                ];
            });
    }
}
