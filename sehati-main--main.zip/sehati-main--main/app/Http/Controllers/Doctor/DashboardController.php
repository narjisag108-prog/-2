<?php
namespace App\Http\Controllers\Doctor;

use App\Http\Controllers\Controller;
use Carbon\Carbon;
use App\Models\Patient;
use App\Models\Appointment;
use App\Models\Consultation;

use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
public function index()
{
    // ===== مواعيد اليوم (عرض)
    $todayAppointmentsList = Appointment::with('patient')
        ->whereDate('date', today())
        ->orderBy('time')
        ->take(3)
        ->get();

    // ===== استشارات جديدة (عرض)
    $newConsultations = Consultation::with('user')
        ->where('status', 'pending')
        ->latest()
        ->take(3)
        ->get();

    // ===== مرضى جدد
    $recentPatients = Patient::latest()->take(2)->get();

    // ===== إحصائيات العيادة
    $totalConsultations = Consultation::count();
    $answeredConsultations = Consultation::where('status', 'answered')->count();

    $stats = [
        // اليوم
        'todayAppointments' => Appointment::whereDate('date', today())->count(),
        'newConsults'       => Consultation::where('status','pending')->count(),

        // عام
        'patientsCount'     => Patient::count(),
        'appointmentsCount' => Appointment::count(),
        'consultationsCount'=> $totalConsultations,

        // نسبة الرد
        'rate' => $totalConsultations > 0
            ? round(($answeredConsultations / $totalConsultations) * 100)
            : 0,
    ];

    return view('doctor.dashboard', compact(
        'todayAppointmentsList',
        'newConsultations',
        'recentPatients',
        'stats'
    ));
}
}
// namespace App\Http\Controllers\Doctor;

// use App\Http\Controllers\Controller;
// use App\Models\Appointment;
// use App\Models\Consultation;
// use App\Models\Patient;

// class DashboardController extends Controller
// {
//     public function index()
//     {
//         $patientsCount = Patient::count();
// $todayAppointments = Appointment::whereDate('date', today())->count();
// $newConsults = Consultation::where('status','pending')->count();
// $alerts = Patient::where('status','critical')->count();

//         return view('doctor.dashboard', [
//             'patientsCount' => Patient::count(),
//             // 'appointmentsToday' => Appointment::today()->count(),
//             // 'newConsults' => Consultation::pending()->count(),
//             'rate' => 92, // مؤقتاً لحين ربطه بتقييمات المرضى
//             // 'appointments' => Appointment::today()->limit(3)->get(),
//             'consults' => Consultation::latest()->limit(3)->get(),
//             'recentPatients' => Patient::latest()->limit(5)->get(),
//             'todayAppointments',
//         ]);
//     }
// }
