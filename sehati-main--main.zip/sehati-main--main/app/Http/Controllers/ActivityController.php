<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;

use App\Models\Activity;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ActivityController extends Controller
{


public function dashboard()
{
    $user = Auth::user();

    $activities = Activity::where('user_id', auth::id())
    ->latest()
    ->take(5)
    ->get(); // ❗ مهم: get فقط


    return view('user.dashboard', compact('activities','user'));
}

}
