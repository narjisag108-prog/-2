<?php

namespace App\Http\Controllers;

use App\Models\Disease;
use App\Models\Review;
use Illuminate\Http\Request;

class ReviewController extends Controller
{
    public function store(Request $request, Disease $disease)
    {
        $request->validate([
            'rating' => 'required|integer|min:1|max:5',
            'comment' => 'nullable|string'
        ]);

        Review::create([
            'user_id' => null,
            'disease_id' => $disease->id,
            'rating' => $request->rating,
            'comment' => $request->comment
        ]);

        return back()->with('success','تم إرسال تقييمك بنجاح 🎉');
    }

    public function update(Request $request, Disease $disease, Review $review)
    {
        $request->validate([
            'rating' => 'required|integer|min:1|max:5',
            'comment' => 'nullable|string'
        ]);

        $review->update([
            'rating' => $request->rating,
            'comment' => $request->comment
        ]);

        return back()->with('success','تم تعديل تقييمك ✨');
    }
}
