<?php

namespace App\Http\Controllers;

use App\Models\Medicine;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class MedicineController extends Controller
{
    public function index()
    {
        $medicines = Medicine::where('user_id', Auth::id())->get();
        return view('medicines.index', compact('medicines'));
    }

    public function create()
    {
        return view('medicines.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name'          => 'required|string|max:191',
            'dose'          => 'required|string|max:191',
            'times_per_day' => 'required|integer|min:1|max:6',
            'end_date'      => 'nullable|date',
        ]);

        Medicine::create([
            'user_id'       => Auth::id(),
            'name'          => $request->name,
            'dose'          => $request->dose,
            'times_per_day' => $request->times_per_day,
            'end_date'      => $request->end_date,
        ]);

        return redirect()->route('medicines.index')
            ->with('success', 'تم إضافة الدواء بنجاح');
    }

    /* ========= EDIT ========= */
    public function edit(Medicine $medicine)
    {
        $this->authorizeMedicine($medicine);
        return view('medicines.edit', compact('medicine'));
    }

    /* ========= UPDATE ========= */
    public function update(Request $request, Medicine $medicine)
    {
        $this->authorizeMedicine($medicine);

        $request->validate([
            'name'          => 'required|string|max:191',
            'dose'          => 'required|string|max:191',
            'times_per_day' => 'required|integer|min:1|max:6',
            'end_date'      => 'nullable|date',
        ]);

        $medicine->update($request->all());

        return redirect()->route('medicines.index')
            ->with('success', 'تم تعديل الدواء بنجاح');
    }

    /* ========= DELETE ========= */
    public function destroy(Medicine $medicine)
    {
        $this->authorizeMedicine($medicine);

        $medicine->delete();

        return redirect()->route('medicines.index')
            ->with('success', 'تم حذف الدواء');
    }

    /* ========= SECURITY ========= */
    private function authorizeMedicine(Medicine $medicine)
    {
        if ($medicine->user_id !== Auth::id()) {
            abort(403);
        }
    }
}
