<?php

namespace App\Http\Controllers;

use App\Models\BloodPressureReading;
use App\Models\SugarReading;
use App\Models\HeartReading;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class ReadingsController extends Controller
{
    public function dashboard()
    {
        $user = Auth::id();

        return view('readings.dashboard', [
            'pressureAvg'    => BloodPressureReading::where('user_id',$user)->avg('value_upper'),
            'sugarAvg'       => SugarReading::where('user_id',$user)->avg('value'),
            'heartAvg'       => HeartReading::where('user_id',$user)->avg('value'),

            'latestPressure' => BloodPressureReading::where('user_id',$user)->latest()->first(),
            'latestSugar'    => SugarReading::where('user_id',$user)->latest()->first(),
            'latestHeart'    => HeartReading::where('user_id',$user)->latest()->first(),
        ]);
    }

    /* ضغط الدم */
    public function blood()
    {
        $readings = BloodPressureReading::where('user_id',Auth::id())->latest()->get();
        return view('readings.blood-pressure', compact('readings'));
    }
    public function storeBlood(Request $request)
    {
        $request->validate([
            'value_upper'=>'required|integer|min:60|max:250',
            'value_lower'=>'required|integer|min:40|max:200'
        ]);

        BloodPressureReading::create([
            'user_id'=>Auth::id(),
            'value_upper'=>$request->value_upper,
            'value_lower'=>$request->value_lower,
        ]);

        return back()->with('success','تم إضافة القراءة بنجاح');
    }

  public function sugar()
{
    $userId = Auth::id();


    $readings = SugarReading::where('user_id', $userId)
        ->orderBy('created_at', 'asc')
        ->get();

    $latest = $readings->last();


    $sugarAvg = $readings->count() ? $readings->avg('value') : null;


    $chartDates = $readings->pluck('created_at')->map(fn($d) => $d->format('d/m'))->toArray();
    $chartValues = $readings->pluck('value')->toArray();

    return view('readings.sugar', compact(
        'readings', 'latest', 'sugarAvg', 'chartDates', 'chartValues'
    ));
}
    public function storeSugar(Request $request)
    {
        $request->validate(['value'=>'required|numeric']);
        SugarReading::create([
            'user_id'=>Auth::id(),
            'value'=>$request->value,
            'note'=>$request->note
        ]);
        return back()->with('success','تم إضافة قراءة السكر');
    }

    /* القلب */
    public function heart()
    {
        $readings = HeartReading::where('user_id',Auth::id())->latest()->get();
        return view('readings.heart', compact('readings'));
    }
    public function storeHeart(Request $request)
    {
        $request->validate(['value'=>'required|numeric|min:30|max:200']);
        HeartReading::create([
            'user_id'=>Auth::id(),
            'value'=>$request->value,
        ]);
        return back()->with('success','تم إضافة قراءة نبض القلب');
    }
}
