<?php
namespace App\Http\Controllers;

use App\Models\Assessment;
use Illuminate\Http\Request;
use App\Models\AssessmentResult;

use Illuminate\Support\Facades\Auth;

class AssessmentController extends Controller
{
    public function show()
    {
        return view('assessment.form');
    }

    public function store(Request $request)
    {
        $request->validate([
            'age' => 'required|integer',
            'gender' => 'required',
            'family_history' => 'required|integer',
            'bmi' => 'required|integer',
            'activity' => 'required|integer',
            'blood_pressure' => 'required|integer',
            'rating'=> 'nullable',
        ]);
        session([
            'score_data' => [
                'age' => $request->age,
                'family_history' => $request->family_history,
                'bmi' => $request->bmi,
                'activity' => $request->activity,
                'blood_pressure' => $request->blood_pressure,
              
          
            ]
        ]);
        // حساب النتيجة
        $score = $request->age + $request->family_history + $request->bmi +
                 $request->activity + $request->blood_pressure;

        if ($score <= 10) {
            $risk = 'low';
        } elseif ($score <= 18) {
            $risk = 'medium';
        } else {
            $risk = 'high';
        }

        Assessment::create([
            'user_id' => Auth::id(),
            'age' => $request->age,
            'gender' => $request->gender,
            'family_history' => $request->family_history,
            'bmi' => $request->bmi,
            'activity' => $request->activity,
            'blood_pressure' => $request->blood_pressure,
            'score' => $score,
            'risk_level' => $risk,
        ]);

        return redirect()
            ->route('assessment.result')
            ->with(['score'=>$score,'risk'=>$risk]);
    }

    public function result()
    {
        if (!session()->has('score')) {
            return redirect()->route('assessment.show');
        }

        $data = session('score_data');

        $age = $data['age'] ?? 0;
        $family_history = $data['family_history'] ?? 0;
        $bmi = $data['bmi'] ?? 0;
        $activity = $data['activity'] ?? 0;
        $blood_pressure = $data['blood_pressure'] ?? 0;


    $score = $age + $family_history + $bmi + $activity + $blood_pressure;

    
    if ($score <= 5) {
        $level = 'منخفض';
        $color = 'green';
        $advice = 'مستوى الخطر منخفض، حافظ على أسلوب حياتك الصحي وممارسة النشاط البدني بانتظام.';
    } elseif ($score <= 12) {
        $level = 'متوسط';
        $color = 'orange';
        $advice = 'مستوى الخطر متوسط، حاول تحسين نظامك الغذائي وزيادة النشاط البدني وتقليل عوامل الخطر.';
    } else {
        $level = 'مرتفع';
        $color = 'red';
        $advice = 'مستوى الخطر مرتفع، يُنصح بمراجعة طبيب وإجراء الفحوصات اللازمة ومتابعة دقيقة.';
    }

    return view('assessment.result', compact(
        'score', 
        'level', 
        'color', 
        'advice',
        'age',
        'family_history',
        'bmi',
        'activity',
        'blood_pressure'
    ));
}
}
