<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class ChatController extends Controller
{
//      public function send(Request $request)
//      {
//          $request->validate([
//             'message' => 'required|string'
//      ]);

//         try {
//         $response = Http::withoutVerifying() // 👈 الحل السحري
//  ->withHeaders([
//          'Authorization' => 'Bearer ' . config('services.openai.key'),
//          'Content-Type'  => 'application/json',
//      ])->post('https://api.openai.com/v1/chat/completions', [

//                 'model' => 'gpt-4o-mini',
//                 'messages' => [
//                     [
//                         'role' => 'system',
//                         'content' => 'أنت مساعد صحي يقدّم معلومات عامة فقط بدون تشخيص.'
//                 ],
//                     [
//                         'role' => 'user',
//                        'content' => $request->message
//                      ],
//                ],
//                 'temperature' => 0.6
//              ]);

//             if ($response->failed()) {
//                  return response()->json([
//                      'reply' => '❌ فشل الاتصال بـ OpenAI'
//                  ]);
//              }

//             return response()->json([
//                  'reply' => $response->json('choices.0.message.content')
//             ]);

//         } catch (\Exception $e) {
//             return response()->json([
//                 'reply' => '⚠️ خطأ: '.$e->getMessage()
//             ]);
//         }
//      }








// class ChatController extends Controller
// {

    public function send(Request $request)
    {
        $message = mb_strtolower(trim($request->message), 'UTF-8');

        return response()->json([
            'reply' => $this->smartReply($message)
        ]);
    }

    private function smartReply($msg)
    {
        /* ======================
           ضغط الدم
        ====================== */

        if (str_contains($msg, 'ضغط') && str_contains($msg, 'شن هو')) {
            return "🩺 ضغط الدم هو القوة التي يضغط بها الدم على جدران الشرايين. الطبيعي تقريبًا 120/80.";
        }

        if (str_contains($msg, 'أسباب') && str_contains($msg, 'ضغط')) {
            return "⚠️ من أسباب ارتفاع ضغط الدم: التوتر، الملح الزائد، السمنة، قلة الحركة، التدخين، والعامل الوراثي.";
        }

        if (str_contains($msg, 'مضاعفات') && str_contains($msg, 'ضغط')) {
            return "❗ إهمال ضغط الدم قد يؤدي إلى: الجلطات، مشاكل القلب، الفشل الكلوي، وضعف النظر.";
        }

        if (str_contains($msg, 'دواء') && str_contains($msg, 'ضغط')) {
            return "💊 أدوية الضغط تختلف حسب الحالة، ويجب أخذها فقط بوصفة طبية. لا تتناول دواء بدون استشارة طبيب.";
        }

        if (str_contains($msg, 'نحافظ') && str_contains($msg, 'ضغط')) {
            return "✅ للمحافظة على ضغط طبيعي: قلل الملح، مارس الرياضة، تجنب التوتر، وحافظ على وزن صحي.";
        }

        /* ======================
           السكر
        ====================== */

        if (str_contains($msg, 'سكر') && str_contains($msg, 'شن هو')) {
            return "🩸 السكر في الدم هو مستوى الجلوكوز. الطبيعي صائم بين 70 و 100 mg/dL.";
        }

        if (str_contains($msg, 'أسباب') && str_contains($msg, 'سكر')) {
            return "⚠️ أسباب ارتفاع السكر: قلة الحركة، الأكل غير الصحي، الوراثة، والسمنة.";
        }

        if (str_contains($msg, 'مضاعفات') && str_contains($msg, 'سكر')) {
            return "❗ مضاعفات السكر تشمل: تلف الأعصاب، مشاكل الكلى، ضعف البصر، وأمراض القلب.";
        }

        if (str_contains($msg, 'دواء') && str_contains($msg, 'سكر')) {
            return "💊 علاج السكر يختلف حسب النوع (الأول أو الثاني). لا يُؤخذ أي دواء إلا تحت إشراف طبي.";
        }

        if (str_contains($msg, 'نحافظ') && str_contains($msg, 'سكر')) {
            return "🥗 للمحافظة على السكر: التزم بنظام غذائي صحي، مارس الرياضة، وراقب السكر بانتظام.";
        }

        /* ======================
           النبض
        ====================== */

        if (str_contains($msg, 'نبض') || str_contains($msg, 'bpm')) {
            return "❤️ النبض الطبيعي للبالغين بين 60 و 100 نبضة في الدقيقة أثناء الراحة.";
        }

        if (str_contains($msg, 'نبض') && str_contains($msg, 'سريع')) {
            return "⚠️ تسارع النبض قد يكون بسبب التوتر، القلق، الكافيين، أو الجهد الزائد.";
        }

        if (str_contains($msg, 'نبض') && str_contains($msg, 'بطيء')) {
            return "⚠️ بطء النبض قد يكون طبيعي عند الرياضيين، لكن إذا صاحبه دوخة يجب استشارة طبيب.";
        }

        /* ======================
           الحرارة
        ====================== */

        if (str_contains($msg, 'حرارة')) {
            return "🌡️ درجة الحرارة الطبيعية للجسم بين 36.5 و 37.5 درجة مئوية.";
        }

        if (str_contains($msg, 'حرارة') && str_contains($msg, 'مرتفعة')) {
            return "🤒 ارتفاع الحرارة قد يكون بسبب عدوى أو التهاب. الإكثار من السوائل مهم.";
        }

        /* ======================
           الصداع
        ====================== */

        if (str_contains($msg, 'صداع')) {
            return "🤕 الصداع قد يكون سببه التوتر، قلة النوم، الجفاف، أو مشاكل في النظر.";
        }

        /* ======================
           نمط الحياة
        ====================== */

        if (str_contains($msg, 'رياضة')) {
            return "🏃‍♂️ الرياضة المنتظمة تساعد في ضبط الضغط والسكر وتحسين صحة القلب.";
        }

        if (str_contains($msg, 'أكل') || str_contains($msg, 'غذاء')) {
            return "🥦 الغذاء الصحي يعتمد على الخضار، الفواكه، تقليل السكر والدهون.";
        }

        if (str_contains($msg, 'تدخين')) {
            return "🚭 التدخين يزيد خطر أمراض القلب والضغط والسكر. الإقلاع عنه يحسن صحتك.";
        }

        /* ======================
           رد افتراضي
        ====================== */

        return "🤖 أنا مساعد صحي. اسألني عن:\n- الضغط\n- السكر\n- النبض\n- الحرارة\n- الأسباب والمضاعفات\n- المحافظة على الصحة";
    }
}
