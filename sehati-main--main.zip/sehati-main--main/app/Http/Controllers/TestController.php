<?php

namespace App\Http\Controllers;

use App\Models\Test;
use Illuminate\Http\Request;

class TestController extends Controller
{
    public function index()
    {
        $tests = Test::with('disease')->paginate(12);
        return view('tests.index', compact('tests'));
    }

    public function show(Test $test)
    {
        $questions = $test->questions()->get();
        return view('tests.show', compact('test','questions'));
    }
}
