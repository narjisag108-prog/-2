<?php

namespace App\Http\Controllers;

use App\Models\Article;
use App\Models\Activity;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class ArticleController extends Controller
{
    public function index()
    {
        $articles = Article::with('disease')
            ->where('status', 'published')
            ->latest()
            ->paginate(12);

        return view('articles.index', compact('articles'));
    }

    public function show($id)
    {
        $article = Article::with('disease')->findOrFail($id);

Activity::create([
    'user_id' => Auth::id(),
    'type' => 'article',
    'title' => 'قرأت مقال: '.$article->title,
]);

        return view('articles.show', compact('article'));
    }
}
