<?php

namespace App\Http\Controllers;

use App\Models\Disease;
use App\Models\Review;
use Illuminate\Http\Request;
use App\Models\Newsletter;

class HomeController extends Controller
{
    public function index()
    {
        $diseases = Disease::latest()->take(6)->get(); // يجيب آخر الأمراض
        $reviews  = Review::latest()->take(6)->get();
        return view('home.index', compact('diseases','reviews'));
    }


    public function subscribe(Request $request)
    {
        $data = $request->validate(['email'=>'required|email|max:191']);
        Newsletter::firstOrCreate(['email'=>$data['email']]);
        return redirect()->back()->with('success','تم الاشتراك بنجاح — شكراً لك!');
    }
}
