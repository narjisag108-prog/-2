<?php $__env->startSection('title', 'صحتك أولاً - الرئيسية'); ?>

<?php $__env->startSection('content'); ?>

<!-- Hero -->
<section class="hero">
    <div class="container">
        <div class="hero-inner">
            <div class="hero-text">
                <h2>صحتك أولاً… واعي اليوم، مرتاح غداً</h2>
                <p>تعرف على أهم الأمراض المزمنة، أسبابها، أعراضها، وطرق الوقاية والعلاج، من مصدر موثوق وبأسلوب بسيط.</p>
                <a href="<?php echo e(route('diseases.index')); ?>" class="btn btn-primary">استكشف الأمراض</a>
            </div>
        </div>
    </div>
</section>

<!-- Diseases Section -->
<section class="section" id="diseases">
    <div class="container">
        <div class="section-title">
            <h2>الأمراض المزمنة</h2>
            <p>اكتشف تفاصيل الأمراض المزمنة وقم بتقييم حالتك الصحية</p>
        </div>

        <div class="diseases-grid">
            <?php $__currentLoopData = $diseases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disease): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="disease-card">
                    <div class="disease-img">
<img
  src="<?php echo e(asset('storage/'.$disease->image)); ?>"
  alt="<?php echo e($disease->name); ?>"
>

                    </div>
                    <div class="disease-content">
                        <h3><?php echo e($disease->name); ?></h3>
                        <p><?php echo e(Str::limit(strip_tags($disease->content), 120)); ?></p>

                        <a href="<?php echo e(route('diseases.show', $disease->slug)); ?>" class="btn btn-outline">
                            المزيد من المعلومات
                        </a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<!-- Services -->
<section id="features" class="section" style="background:#f8f9fa">
    <div class="container">
        <div class="section-title">
            <h2>خدماتنا</h2>
        </div>

        <div class="services-grid">
            <div class="service-card"><i class="fas fa-bell"></i><h4>منبهات وتذكيرات</h4><p>نظام تذكير للأدوية والمواعيد الطبية</p></div>
            <div class="service-card"><i class="fas fa-vials"></i><h4>اختبارات ذاتية</h4><p>تقييم تفاعلي للحالة الصحية</p></div>
            <div class="service-card"><i class="fas fa-file-medical"></i><h4>محتوى طبي موثوق</h4><p>معلومات دقيقة ومبسطة</p></div>
            <div class="service-card"><i class="fas fa-utensils"></i><h4>نظام غذائي</h4><p>خطط تغذية مناسبة لصحتك</p></div>
            <div class="service-card"><i class="fas fa-chart-line"></i><h4>متابعة المؤشرات</h4><p>سجل وتحليل لمؤشراتك الصحية</p></div>
            <div class="service-card"><i class="fas fa-user-md"></i><h4>استشارات طبية</h4><p>استشارة من أطباء مختصين</p></div>
        </div>
    </div>
</section>

<!-- Testimonials -->
<section id="testimonials" class="section">
    <div class="container">
        <div class="section-title">
            <h2>آراء المستخدمين</h2>
             <div class="service-card"><h4>محمد أحمد
مريض سكري</h4><p>موقع رائع ساعدني في فهم مرض السكري الذي أعاني منه، النصائح الغذائية كانت مفيدة جدًا وساعدتني في التحكم بمستوى السكر في الدم</p></div>
        </div>
                    <div class="service-card"><h4>سارة محمد
مريضة ضغط دم</h4><p>الاستشارة الطبية التي حصلت عليها من خلال الموقع كانت دقيقة وساعدتني في اتخاذ القرار الصحيح بخصوص علاج ضغط الدم المرتفع   </p></div>

                    <div class="service-card"><h4>نوار خالد
 مريض قلب
</h4><p>المقالات المبسطة ساعدتني في فهم حالة والدي الذي يعاني من أمراض القلب، وأصبحت أكثر قدرة على مساعدته في التعامل مع المرض      </p></div>

        <div class="testimonials-slider">
            <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="testimonial">
                <div class="testimonial-content">“<?php echo e($r->content); ?>”</div>
                <div class="testimonial-author">
                    <div class="author-img">
                        <img src="<?php echo e($r->avatar ? asset('storage/'.$r->avatar) : asset('images/avatar-placeholder.png')); ?>">
                    </div>
                    <div class="author-info">
                        <h4><?php echo e($r->name); ?></h4>
                        <small><?php echo e($r->type); ?></small>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<!-- Newsletter -->
<section id="newsletter" class="newsletter">
    <div class="container">
        <h2>اشترك في نشرتنا البريدية</h2>
        <p>احصل على أحدث المقالات والنصائح الصحية مباشرة إلى بريدك.</p>

        <form action="<?php echo e(route('newsletter.subscribe')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="email" name="email" placeholder="بريدك الإلكتروني" required>
            <button type="submit">اشترك</button>
        </form>
    </div>
</section>

<?php $__env->stopSection(); ?>











<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PIXEL-PC\Desktop\sehatimain\sehati-main\resources\views/home/index.blade.php ENDPATH**/ ?>