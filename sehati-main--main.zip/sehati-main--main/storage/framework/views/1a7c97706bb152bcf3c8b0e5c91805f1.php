<?php $__env->startSection('title','لوحة التحكم'); ?>

<?php $__env->startSection('content'); ?>

<div class="card">

    <!-- التاريخ والوقت -->
    <div class="date-time-box mb-3">
        <span id="current-day"></span>
        <span id="current-date"></span>
        <span id="current-time"></span>
    </div>

    <!-- عنوان الصفحة -->
    <div class="page-header">
        <h2><i class="fas fa-tachometer-alt"></i> لوحة التحكم</h2>
    </div>

    <!-- كروت الإحصائيات -->
    <div class="stats-cards">
        <div class="stat-card primary">
            <h3><?php echo e($usersCount); ?></h3>
            <p>المستخدمين المسجلين</p>
            <small>+<?php echo e($usersThisWeek); ?> هذا الأسبوع</small>
        </div>

        <div class="stat-card secondary">
            <h3><?php echo e($articlesCount); ?></h3>
            <p>المقالات المنشورة</p>
            <small>+<?php echo e($articlesThisWeek); ?> هذا الأسبوع</small>
        </div>

        <div class="stat-card accent">
            <h3><?php echo e($newConsultations); ?></h3>
            <p>الاستشارات الجديدة</p>
            <small>+<?php echo e($consultationsThisWeek); ?> هذا الأسبوع</small>
        </div>
    </div>
</div>

<!-- قسم المقالات -->
<div class="card mt-4 content-management">

    <div class="section-title">
    <h3><i class="fas fa-file-alt"></i> أحدث المقالات</h3>

    


    <div class="table-container">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>العنوان</th>
                    <th>المرض</th>
                    <th>المؤلف</th>
                    <th>الحالة</th>
                    <th>التاريخ</th>
                    <th>الإجراءات</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $latestArticles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($article->title?? '-'); ?></td>
                    <td><?php echo e($article->disease->name ?? '-'); ?></td>
                    <td><?php echo e($article->author->name?? '-'); ?></td>
                    <td>
                        <span class="status-badge <?php echo e($article->status == 'published' ? 'published' : 'draft'); ?>">
                            <?php echo e($article->status == 'published' ? 'منشور' : 'مسودة'); ?>

                        </span>
                    </td>
                    <td><?php echo e($article->created_at->format('Y-m-d')); ?></td>

                    <td class="actions">
                        <a href="<?php echo e(route('admin.articles.edit',$article)); ?>" class="btn-action edit">
                            <i class="fas fa-edit"></i>
                        </a>

                        <form action="<?php echo e(route('admin.articles.destroy',$article)); ?>" method="POST" style="display:inline-block">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button onclick="return confirm('هل تريد حذف المقال؟')" class="btn-action delete">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                    </td>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="text-center">لا توجد مقالات حالياً</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="pagination-container">
        <?php echo e($latestArticles->links('pagination::bootstrap-5')); ?>

    </div>

</div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('styles'); ?>
<style>
/* ======== General Card ======== */
.card{
    background:#fff;
    padding:20px;
    border-radius:12px;
    box-shadow:0 5px 15px rgba(0,0,0,.05);
    margin-bottom:25px;
}

/* ======== Page Header ======== */
.page-header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:25px;
}
.page-header h2{
    color:#2a7f62;
    display:flex;
    align-items:center;
    gap:10px;
}

/* ======== Stats Cards ======== */
.stats-cards{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
    gap:20px;
}
.stat-card{
    background:#fff;
    padding:20px;
    border-radius:10px;
    text-align:center;
    box-shadow:0 5px 15px rgba(0,0,0,.05);
}
.stat-card h3{font-size:1.8rem;color:#2a7f62;}
.stat-card p{color:#555;font-weight:500;}
.stat-card small{color:#777;}
.stat-card.primary{border-right:6px solid #2a7f62;}
.stat-card.secondary{border-right:6px solid #3ab795;}
.stat-card.accent{border-right:6px solid #ff7e5f;}
.stat-card.dark{border-right:6px solid #343a40;}

/* ======== Table ======== */
.table-container{overflow-x:auto;margin-top:10px;}
.admin-table{width:100%;border-collapse:collapse;}

.admin-table th{
    background:#2a7f62;
    color:#fff;
    padding:14px;
    text-align:center;
}
.admin-table td{
    padding:14px;
    border-bottom:1px solid #eee;
    text-align:center;
}

/* Status Badges */
.status-badge{
    padding:6px 14px;
    border-radius:6px;
    font-weight:600;
}
.status-badge.published{background:#e9f8f0;color:#2a7f62;}
.status-badge.draft{background:#fff4d6;color:#b38300;}

/* Action Buttons */
.actions{display:flex;gap:10px;justify-content:center;}
.btn-action{
    width:40px;height:40px;
    border:2px solid #2a7f62;
    border-radius:8px;
    display:flex;
    align-items:center;
    justify-content:center;
    background:none;
    cursor:pointer;
}
.btn-action.edit i{color:#2a7f62;}
.btn-action.delete i{color:#dc3545;}
.btn-action:hover{background:#2a7f62;}
.btn-action:hover i{color:white;}
.btn-primary {
    background:#2a7f62;
    color:#fff;
    padding:10px 18px;
    border:none;
    border-radius:6px;
    font-size:.95rem;
    font-weight:600;
    display:inline-flex;
    align-items:center;
    gap:8px;
}
.btn-primary:hover {
    background:#1e5f4a;
}

</style>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('scripts'); ?>
<script>
function updateDateTime(){
    const now = new Date();
    const days = ["الأحد","الإثنين","الثلاثاء","الأربعاء","الخميس","الجمعة","السبت"];
    document.getElementById("current-day").innerText = days[now.getDay()] + " -";
    document.getElementById("current-date").innerText = now.toLocaleDateString("ar-EG",{year:'numeric',month:'long',day:'numeric'})+" - ";
    document.getElementById("current-time").innerText = now.toLocaleTimeString('ar-EG');
}
setInterval(updateDateTime,1000); updateDateTime();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PIXEL-PC\Desktop\sehatimain\sehati-main\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>