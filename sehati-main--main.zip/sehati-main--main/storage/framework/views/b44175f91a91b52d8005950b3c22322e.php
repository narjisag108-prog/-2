<?php $__env->startSection('title','إدارة المستخدمين'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">

<!-- ========== التاريخ والوقت ========== -->
<div class="date-time-box mb-3">
    <span id="current-day"></span>
    <span id="current-date"></span>
    <span id="current-time"></span>
</div>

<div class="dashboard-header">
    <h2><i class="fas fa-users"></i> إدارة المستخدمين</h2>
</div>

 <div class="card mb-2">
<div class="search-filter section-box">
    <form method="GET" action="<?php echo e(route('admin.users.index')); ?>"style="display:flex;gap:18px;flex-wrap:wrap">
            <input type="text" name="q" class="form-control"
                   placeholder="ابحث بالاسم أو البريد..."
                   value="<?php echo e(request('q')); ?>">


            <select name="role" class="form-control">
            <option value="">الكل</option>
            <option value="admin" <?php if(request('role')=='admin'): echo 'selected'; endif; ?>>مسؤول</option>
            <option value="doctor" <?php if(request('role')=='doctor'): echo 'selected'; endif; ?>>طبيب</option>
            <option value="user" <?php if(request('role')=='user'): echo 'selected'; endif; ?>>مستخدم</option>
            </select>

            <select name="status" class="form-control">
                <option value="">الكل</option>
                <option value="active" <?php if(request('status')=='active'): echo 'selected'; endif; ?>>نشط</option>
                <option value="inactive" <?php if(request('status')=='inactive'): echo 'selected'; endif; ?>>غير نشط</option>
                <option value="banned" <?php if(request('status')=='banned'): echo 'selected'; endif; ?>>محظور</option>
            </select>

         <button class="btn btn-primary">بحث</button>
            <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-outline">إعادة تعيين</a>
        </div>
    </form>
</div>

<div class="section-box">
    <div class="section-header">
        <h4><i class="fas fa-users-cog"></i> قائمة المستخدمين</h4>

        <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus"></i> إضافة مستخدم
        </a>
    </div>

    <div class="table-container">
        <table class="admin-table">
            <thead>
            <tr>
                <th>#</th>
                <th>الصورة</th>
                <th>الاسم</th>
                <th>البريد</th>
                <th>الدور</th>
                <th>تاريخ التسجيل</th>
                <th>الحالة</th>
                <th>إجراءات</th>
            </tr>
            </thead>
            <tbody>
<?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<tr>
    <td><?php echo e($u->id); ?></td>

    <td>
        <img src="<?php echo e($u->avatar ? asset('storage/'.$u->avatar) : asset('images/default-avatar.png')); ?>"
             class="user-avatar">
    </td>

    <td><?php echo e($u->name); ?></td>
    <td><?php echo e($u->email); ?></td>
    <td><?php echo e($u->role); ?></td>
    <td><?php echo e($u->created_at->format('Y-m-d')); ?></td>

    <!-- ==== الحالة بالعربي + الألوان ==== -->
    <td>
        <?php
            $statusText = [
                'active' => 'نشط',
                'inactive' => 'غير نشط',
                'banned' => 'محظور'
            ];
        ?>

        <span class="badge
            <?php if($u->status == 'active'): ?> badge-success
            <?php elseif($u->status == 'banned'): ?> badge-danger
            <?php else: ?> badge-warning <?php endif; ?>">
            <?php echo e($statusText[$u->status] ?? 'غير معروف'); ?>

        </span>
    </td>

    <!-- ==== الإجراءات ==== -->
    <td class="action-buttons">

        <!-- زر التعديل -->
        <a href="<?php echo e(route('admin.users.edit', $u)); ?>" class="btn btn-outline">
            <i class="fas fa-edit"></i>
        </a>

        <!-- زر الحذف -->
        <form action="<?php echo e(route('admin.users.destroy', $u)); ?>" method="POST" style="display:inline-block">
            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
            <button class="btn btn-danger"
                    onclick="return confirm('هل تريد حذف المستخدم؟')">
                <i class="fas fa-trash"></i>
            </button>
        </form>

        <!-- زر الحظر / رفع الحظر -->
        <form action="<?php echo e(route('admin.users.toggleStatus', $u)); ?>" method="POST" style="display:inline-block">
            <?php echo csrf_field(); ?>
            <button class="btn btn-warning" onclick="return confirm('هل تريد تغيير حالة هذا المستخدم؟')">
                <?php if($u->status === 'banned'): ?>
                    رفع الحظر
                <?php else: ?>
                    حظر المستخدم
                <?php endif; ?>
            </button>
        </form>

    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<tr>
    <td colspan="8" class="text-center">لا توجد بيانات حالياً</td>
</tr>
<?php endif; ?>
</tbody>

    <div class="pagination-container">
        <?php echo e($users->links('pagination::bootstrap-5')); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>

/* ========== الصناديق العامة ========== */
.section-box {
    background: #fff;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    margin-bottom: 25px;
}

.section-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 15px;
}

.section-header h4 {
    color: #2a7f62;
    display: flex;
    align-items: center;
    gap: 10px;
}

/* ========== الجدول ========== */
.table-container {
    overflow-x: auto;
    margin-bottom: 40px;
}
.admin-table {
    width: 100%;
    border-collapse: collapse;
    min-width: 800px;
}
.admin-table th {
    background: #2a7f62;
    color: white;
    padding: 12px;
    font-weight: 600;
}
.admin-table td {
    padding: 12px 15px;
    border-bottom: 1px solid #eee;
    text-align: center;
}

/* ========== الصورة ========== */
.user-avatar {
    width: 45px;
    height: 45px;
    border-radius: 50%;
    object-fit: cover;
}

/* ========== البادجات ========== */
.badge {
    padding: 5px 10px;
    border-radius: 4px;
    font-size: .85rem;
    color: #fff;
}
.badge-success { background:#2a7f62; }
.badge-warning { background:#ffbf00; }
.badge-danger  { background:#dc3545; }

/* ========== الأزرار ========== */
.btn {
    padding: 10px 18px;
    border-radius: 8px;
    font-size: 1rem;
    cursor: pointer;
    transition: 0.3s;
    text-decoration: none;
    display: inline-block;
}

.btn-primary {
    background: #2a7f62;
    color: #fff;
}
.btn-primary:hover {
    background: #1e5f4a;
}

.btn-outline {
    background: transparent;
    color: #2a7f62;
    border: 1px solid #2a7f62;
}
.btn-outline:hover {
    background: #2a7f62;
    color: #fff;
}

.btn-danger {
    background: #dc3545;
    color: #fff;
}
.btn-danger:hover {
    background: #b52a35;
}

/* ========== الفلتر والبحث ========== */
.card form {
    display: flex;
    flex-wrap: wrap;
    gap: 15px;
    margin-bottom: 15px;
}

.form-control {
    flex: 1 1 300px;
    padding: 14px 18px;
    font-size: 1.1rem;
    border-radius: 8px;
}

/* ========== التاريخ والوقت ========== */
.date-time-box {
    background: #fff;
    padding: 12px 18px;
    border-radius: 8px;
    color: #2a7f62;
    font-weight: 600;
    display: inline-flex;
    gap: 15px;
    border-right: 4px solid #2a7f62;
    box-shadow: 0 5px 15px rgba(0,0,0,.05);
    font-size: 1rem;
}

/* ========== صفحة الإدارة ========== */
.dashboard-header h2 {
    color: #2a7f62;
    display: flex;
    align-items: center;
    gap: 10px;
}

.pagination-container {
    margin-top: 20px;
    text-align: center;
}

</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function updateDateTime(){
    const now = new Date();
    const days = ["الأحد","الإثنين","الثلاثاء","الأربعاء","الخميس","الجمعة","السبت"];
    document.getElementById("current-day").innerText = days[now.getDay()] + " -";
    document.getElementById("current-date").innerText = now.getFullYear()+"/"+(now.getMonth()+1)+"/"+now.getDate()+" -";
    document.getElementById("current-time").innerText =
        now.getHours().toString().padStart(2,'0') + ":" +
        now.getMinutes().toString().padStart(2,'0') + ":" +
        now.getSeconds().toString().padStart(2,'0');
}
setInterval(updateDateTime, 1000);
updateDateTime();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PIXEL-PC\Desktop\sehatimain\sehati-main\resources\views/admin/users/index.blade.php ENDPATH**/ ?>