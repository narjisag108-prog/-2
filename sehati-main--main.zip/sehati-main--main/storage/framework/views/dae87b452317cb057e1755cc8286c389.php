<?php $__env->startSection('title','إضافة استشارة'); ?>

<?php $__env->startPush('styles'); ?>
<style>
/* ====== PAGE ====== */
.page-header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:25px;
}
.page-header h3{
    font-weight:800;
    color:#333;
}
.page-header h3 span{
    color:#6f42c1;
    font-size:22px;
}

/* ====== FORM CARD ====== */
.form-card{
    background:#fff;
    padding:25px;
    border-radius:14px;
    box-shadow:0 6px 18px rgba(0,0,0,.06);
}

/* ====== GRID ====== */
.form-grid{
    display:grid;
    grid-template-columns:repeat(6,1fr);
    gap:15px;
    align-items:end;
}

.form-group{
    display:flex;
    flex-direction:column;
}

.form-group label{
    font-size:13px;
    font-weight:700;
    color:#444;
    margin-bottom:6px;
}

.form-group input,
.form-group select,
.form-group textarea{
    padding:8px 10px;
    border-radius:6px;
    border:1px solid #dcdcdc;
    font-size:13px;
}

.form-group textarea{
    resize:none;
    height:38px;
}

/* ====== BUTTON ====== */
.btn-save{
    background:#198754;
    color:#fff;
    border:none;
    padding:8px 18px;
    border-radius:6px;
    font-size:13px;
    font-weight:700;
    cursor:pointer;
}
.btn-save:hover{
    background:#157347;
}

/* ====== RESPONSIVE ====== */
@media(max-width:1100px){
    .form-grid{
        grid-template-columns:1fr 1fr;
    }
}
</style>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>

<div class="page-header">
    <h3><span>＋</span> إضافة استشارة جديدة</h3>
</div>

<div class="form-card">

<form method="POST" action="<?php echo e(route('admin.consultations.store')); ?>">
<?php echo csrf_field(); ?>

<div class="form-grid">

    
    <div class="form-group">
        <label>المريض</label>
                        <input type="name" name="name" required>

        
    </div>

    
    <div class="form-group">
        <label>العنوان</label>
        <input type="text" name="subject" required>
    </div>

    
    <div class="form-group" style="grid-column: span 2">
        <label>الرسالة</label>
        <textarea name="message" required></textarea>
    </div>

    
    <div class="form-group">
        <label>المرض</label>
        <select name="disease_id">
            <option value="">— اختياري —</option>
            <?php $__currentLoopData = $diseases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($d->id); ?>"><?php echo e($d->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    
    <div class="form-group">
<label>اختر الطبيب</label>
<select name="doctor_name" required>
    <option value="">-- اختر الطبيب --</option>
    <option value="د. أحمد سالم">د. أحمد سالم – باطنية</option>
    <option value="د. محمد علي">د. محمد علي – قلب</option>
    <option value="د. سارة حسن">د. سارة حسن – غدد وسكر</option>
    <option value="د. خالد عمر">د. خالد عمر – ضغط</option>
</select>
        </div>
    </div>

    
    <div class="form-group">
        <label>الحالة</label>
        <select name="status">
            <option value="new">جديدة</option>
            <option value="review">قيد المراجعة</option>
            <option value="completed">مكتملة</option>
            <option value="canceled">ملغاة</option>
        </select>
    </div>

    
    <div class="form-group">
        <button class="btn-save">حفظ</button>
    </div>

</div>
</form>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PIXEL-PC\Desktop\sehatimain\sehati-main\resources\views/admin/consultations/create.blade.php ENDPATH**/ ?>