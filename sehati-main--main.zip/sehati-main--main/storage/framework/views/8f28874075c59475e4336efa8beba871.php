<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'لوحة التحكم'); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Tajawal', sans-serif;
            background: #f6f7fb;
            margin: 0;
            color: #333;
        }
        header {
            background: #2a7f62;
            color: #fff;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        header h1 { font-size: 1.4rem; }
        .admin-wrapper { display: flex; min-height: 100vh; }
        aside {
            width: 230px;
            background: #1e5f4a;
            color: #fff;
            padding: 20px;
        }
        aside h3 { color: #ffb347; margin-bottom: 20px; }
        aside ul { list-style: none; padding: 0; }
        aside li { margin-bottom: 10px; }
        aside a { color: #fff; text-decoration: none; display: block; padding: 6px 10px; border-radius: 4px; }
        aside a:hover { background: #2a7f62; }
        main { flex: 1; padding: 30px; }
    </style>

    <?php echo $__env->yieldPushContent('styles'); ?>
<style>
    .admin-form {
        background: #fff;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 5px 15px rgba(0,0,0,.05);
        max-width: 700px;
        margin: auto;
    }
    .admin-form h2 {
        color: #2a7f62;
        margin-bottom: 25px;
        font-size: 1.4rem;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    .admin-form label {
        display: block;
        margin: 12px 0 5px;
        color: #333;
        font-weight: 500;
    }
    .admin-form input,
    .admin-form textarea,
    .admin-form select {
        width: 100%;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-family: 'Tajawal', sans-serif;
    }
    .admin-form textarea { resize: vertical; }
    .admin-form .btn {
        margin-top: 20px;
        margin-right: 10px;
    }
</style>
<style>
    .admin-show {
        background: #fff;
        padding: 30px;
        border-radius: 10px;
        box-shadow: 0 5px 15px rgba(0,0,0,.05);
        max-width: 800px;
        margin: auto;
    }


    .admin-show h2 {
        color: #2a7f62;
        margin-bottom: 25px;
        display: flex;
        align-items: center;
        gap: 10px;
        font-size: 1.4rem;
    }

    .admin-show .card {
        background: #f9f9f9;
        padding: 20px;
        border-radius: 8px;
        line-height: 1.8;
    }

    .admin-show p {
        margin-bottom: 10px;
    }

    .admin-show .question-box {
        background: #f1fdf7;
        border: 1px solid #c7f0da;
        padding: 10px;
        border-radius: 5px;
        margin-bottom: 10px;
    }

    .admin-show .article-content {
        background: #fff;
        padding: 15px;
        border-radius: 6px;
        border: 1px solid #eee;
        margin-top: 10px;
        line-height: 1.9;
    }
     body { font-family: 'Tajawal',sans-serif; background:#f5f5f5; margin:0; color:#333; }
    a{ text-decoration:none; }

</style>

</head>
<body>
    <header>
        <h1>لوحة التحكم - صحتك أولاً</h1>
        <div>
            <a href="<?php echo e(url('/home')); ?>" style="color:#fff; text-decoration:none;">العودة للموقع</a>



<div class="user-menu">
<div class="user-info">
<div class="user-avatar">
<small style="color:#66">مدير النظام</small>
</div>
<div>

<?php echo e(mb_substr(auth()->user()->first_name,0,1)); ?>

<strong><?php echo e(auth()->user()->first_name); ?></strong><br>
</div>
</div>

        </div>
    </header>

    <div class="admin-wrapper">
        <aside>
            <h3>القائمة</h3>
            <ul>
                 <li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fas fa-tags"></i> الأحصائيات</a></li>
                <li><a href="<?php echo e(route('admin.diseases.index')); ?>"><i class="fas fa-virus"></i> الأمراض</a></li>
                <li><a href="<?php echo e(route('admin.articles.index')); ?>"><i class="fas fa-newspaper"></i> المقالات</a></li>
                <li><a href="<?php echo e(route('admin.tests.index')); ?>"><i class="fas fa-vial"></i> الاختبارات</a></li>
                <li><a href="<?php echo e(route('admin.users.index')); ?>"><i class="fas fa-users"></i> إدارة المستخدمين</a></li>
               <li><a href="<?php echo e(route('admin.consultations.index')); ?>"><i class="fas fa-comments"></i> إدارة الاستشارات</a></li>
               <li><a href="<?php echo e(route('admin.categories.index')); ?>"><i class="fas fa-tags"></i> التصنيفات</a></li>
               <li><a href="<?php echo e(route('admin.settings.index')); ?>"><i class="fas fa-tags"></i> الاعدادات</a></li>
            </ul>
        </aside>

        <main>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>
</html>
<?php /**PATH C:\Users\PIXEL-PC\Desktop\sehatimain\sehati-main\resources\views/admin/layout.blade.php ENDPATH**/ ?>