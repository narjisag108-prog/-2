<?php $__env->startSection('title', 'لوحة تتبع المؤشرات الصحية'); ?>

<?php $__env->startPush('styles'); ?>
<style>
.page-title{
    font-size:2rem;
    font-weight:800;
    color:var(--primary);
    margin-bottom:30px;
    display:flex;
    align-items:center;
    gap:10px;
}
.page-title i{
    font-size:1.9rem;
}

/* ===== GRID ===== */
.metrics-grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(300px,1fr));
    gap:25px;
    margin-top:25px;
}

/* ===== CARD ===== */
.metric-card{
    background:#ffffff;
    padding:26px 22px;
    border-radius:20px;
    text-align:center;
    box-shadow:0 8px 25px rgba(0,0,0,.06);
    transition:.35s ease;
}
.metric-card:hover{
    transform:translateY(-6px);
    box-shadow:0 14px 32px rgba(0,0,0,.12);
}

/* ===== ICON ===== */
.metric-icon{
    width:75px;
    height:75px;
    border-radius:16px;
    display:flex;
    align-items:center;
    justify-content:center;
    margin:0 auto 15px;
    font-size:2rem;
    color:#fff;
}
.metric-card:hover .metric-icon{
    animation:shake .5s ease;
}

/* ===== TEXT ===== */
.metric-title{
    font-size:1.3rem;
    font-weight:700;
    color:#333;
    margin-bottom:8px;
}
.metric-num{
    font-size:2.1rem;
    font-weight:900;
    margin:12px 0;
}

/* ===== STATUS ===== */
.safe{color:#2a7f62;}
.warning{color:#e0a800;}
.danger{color:#dc3545;}

/* ===== BUTTON ===== */
.metric-btn a{
    display:inline-block;
    padding:10px 24px;
    border-radius:10px;
    margin-top:15px;
    font-size:.95rem;
    font-weight:700;
    border:2px solid var(--primary);
    color:var(--primary);
    transition:.3s ease;
}
.metric-btn a:hover{
    background:var(--primary);
    color:#fff;
}

/* ===== COLORS ===== */
.blood-icon { background:#ff6b6b; }
.sugar-icon { background:#4dabf7; }
.heart-icon { background:#ff922b; }

/* ===== ANIMATION ===== */
@keyframes shake{
    0%{transform:rotate(0)}
    25%{transform:rotate(6deg)}
    50%{transform:rotate(-6deg)}
    75%{transform:rotate(4deg)}
    100%{transform:rotate(0)}
}
</style>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>

<div class="page-container">

    <div class="page-title">
        <i class="fas fa-heartbeat"></i> لوحة تتبع المؤشرات الصحية
    </div>

    <div class="metrics-grid">

        
        <div class="metric-card">
            <div class="metric-icon blood-icon">
                <i class="fas fa-tint"></i>
            </div>

            <div class="metric-title">ضغط الدم</div>

            <?php
                $pressureDanger = $pressureUpperAvg > 140 || $pressureLowerAvg > 90;
            ?>

            <div class="metric-num <?php echo e($pressureDanger ? 'danger' : 'safe'); ?>">
                <?php echo e(round($pressureUpperAvg)); ?>/<?php echo e(round($pressureLowerAvg)); ?>

            </div>

            <p style="color:#6c757d">
                آخر قراءة:
                <strong>
                    <?php echo e($latestPressure?->value_upper ?? '-'); ?>/<?php echo e($latestPressure?->value_lower ?? '-'); ?>

                </strong>
            </p>

            <div class="metric-btn">
                <a href="<?php echo e(route('readings.blood-pressure.index')); ?>">عرض القراءات</a>
            </div>
        </div>


        
        <div class="metric-card">
            <div class="metric-icon sugar-icon">
                <i class="fas fa-syringe"></i>
            </div>

            <div class="metric-title">سكر الدم</div>

            <div class="metric-num <?php echo e($sugarAvg > 180 ? 'danger' : 'safe'); ?>">
                <?php echo e($sugarAvg ? number_format($sugarAvg,1) : '-'); ?>

                <small>mg/dL</small>
            </div>

            <p style="color:#6c757d">
                آخر قراءة:
                <strong><?php echo e($latestSugar?->value ?? '-'); ?></strong>
            </p>

            <div class="metric-btn">
                <a href="<?php echo e(route('readings.sugar.index')); ?>">عرض القراءات</a>
            </div>
        </div>


        
        <div class="metric-card">
            <div class="metric-icon heart-icon">
                <i class="fas fa-heartbeat"></i>
            </div>

            <div class="metric-title">نبض القلب</div>

            <div class="metric-num <?php echo e($heartAvg > 100 ? 'danger' : 'safe'); ?>">
                <?php echo e($heartAvg ? number_format($heartAvg,1) : '-'); ?>

                <small>BPM</small>
            </div>

            <p style="color:#6c757d">
                آخر قراءة:
                <strong><?php echo e($latestHeart?->value ?? '-'); ?></strong>
            </p>

            <div class="metric-btn">
                <a href="<?php echo e(route('readings.heart.index')); ?>">عرض القراءات</a>
            </div>
        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PIXEL-PC\Desktop\sehatimain\sehati-main\resources\views/readings/dashboard.blade.php ENDPATH**/ ?>