<?php $__env->startSection('title','تقرير طبي'); ?>

<?php $__env->startSection('content'); ?>

<h2 class="page-title">📄 إنشاء تقرير طبي</h2>

<div class="center-wrapper">
    <form method="POST" action="<?php echo e(route('doctor.reports.store')); ?>" class="form-card">
        <?php echo csrf_field(); ?>

        <input type="hidden" name="patient_id" value="<?php echo e($patient->id); ?>">

        
        <div class="form-group">
            <label>المريض</label>
            <input value="<?php echo e($patient->name); ?>" disabled class="readonly">
        </div>

        
        <div class="form-group">
            <label>عنوان التقرير</label>
            <input
                type="text"
                name="title"
                placeholder="مثال: تقرير متابعة حالة صحية"
                required
            >
        </div>

        
        <div class="form-group">
            <label>تفاصيل التقرير الطبي</label>
            <textarea
                name="content"
                rows="7"
                placeholder="اكتب تفاصيل الحالة، التشخيص، الخطة العلاجية..."
                required
            ></textarea>
        </div>

        
        <div class="form-actions">
            <a href="<?php echo e(url()->previous()); ?>" class="btn-outline">رجوع</a>
            <button type="submit" class="btn-primary-full">
                📄 حفظ التقرير
            </button>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>
<style>
:root{
    --green:#2a7f62;
    --bg:#f4f7f6;
}

/* ===== العنوان ===== */
.page-title{
    font-weight:900;
    color:var(--green);
    margin-bottom:30px;
}

/* ===== توسيط ===== */
.center-wrapper{
    display:flex;
    justify-content:center;
}

/* ===== الكارد ===== */
.form-card{
    width:480px;
    background:#fff;
    padding:30px;
    border-radius:22px;
    box-shadow:0 14px 35px rgba(0,0,0,.1);
    animation:fadeUp .5s ease;
}

/* ===== الحقول ===== */
.form-group{
    margin-bottom:20px;
}

.form-group label{
    font-weight:800;
    color:var(--green);
    margin-bottom:8px;
    display:block;
}

.form-group input,
.form-group textarea{
    width:100%;
    padding:14px 16px;
    border-radius:14px;
    border:2px solid #e1ece8;
    font-family:inherit;
    font-size:14px;
}

.form-group textarea{
    resize:none;
}

.form-group input:focus,
.form-group textarea:focus{
    outline:none;
    border-color:var(--green);
    box-shadow:0 0 0 4px rgba(42,127,98,.12);
}

/* ===== input للعرض فقط ===== */
.readonly{
    background:#f8fbfa;
    color:#6c8b84;
    cursor:not-allowed;
}

/* ===== أزرار ===== */
.form-actions{
    display:flex;
    gap:12px;
    margin-top:10px;
}

.btn-outline{
    flex:1;
    border:2px solid var(--green);
    color:var(--green);
    background:transparent;
    padding:12px;
    border-radius:14px;
    font-weight:800;
    text-align:center;
}

.btn-primary-full{
    flex:2;
    background:var(--green);
    color:#fff;
    border:none;
    padding:14px;
    border-radius:14px;
    font-weight:900;
    cursor:pointer;
    transition:.3s;
}

.btn-primary-full:hover{
    background:#246b54;
}

/* ===== أنيميشن ===== */
@keyframes fadeUp{
    from{opacity:0;transform:translateY(25px)}
    to{opacity:1;transform:translateY(0)}
}
</style>

<?php echo $__env->make('doctor.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PIXEL-PC\Desktop\sehatimain\sehati-main\resources\views/doctor/reports/create.blade.php ENDPATH**/ ?>