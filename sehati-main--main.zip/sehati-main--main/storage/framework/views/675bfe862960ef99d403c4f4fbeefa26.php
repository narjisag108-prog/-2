<?php $__env->startSection('title','استشارة طبية'); ?>

<?php $__env->startSection('content'); ?>

<h2 class="page-title">💬 استشارة طبية</h2>

<div class="center-wrapper">
<form method="POST" action="<?php echo e(route('user.consultations.store')); ?>" class="form-card">
<?php echo csrf_field(); ?>

<div class="form-group">
    <label>عنوان الاستشارة</label>
    <input name="title" required placeholder="مثال: ألم في الصدر">
</div>

<div class="form-group">
    <label>المرض (اختياري)</label>
    <select name="disease_id">
        <option value="">— اختر —</option>
        <?php $__currentLoopData = $diseases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($d->id); ?>"><?php echo e($d->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="form-group">
    <label>الموعد (اختياري)</label>
    <select name="appointment_id">
        <option value="">— بدون —</option>
        <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($a->id); ?>">
                <?php echo e($a->title); ?> - <?php echo e($a->date->format('d/m')); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="form-group">
    <label>نص الاستشارة</label>
    <textarea name="message" rows="5" required></textarea>
</div>

<button class="btn-primary-full">إرسال الاستشارة</button>

</form>
</div>
<?php $__env->stopSection(); ?>
<style>
.textarea{
    width:100%;
    padding:14px;
    border-radius:14px;
    border:1.8px solid #e1ece8;
    min-height:120px;
    margin-bottom:15px;
}

.reply-box{
    background:#f8fbfa;
    padding:16px;
    border-radius:14px;
    margin-bottom:12px;
}

.reply-box strong{
    color:#2a7f62;
}

.btn-primary-full{
    width:100%;
    background:#2a7f62;
    color:#fff;
    border:none;
    padding:14px;
    border-radius:14px;
    font-weight:800;
}
.page-title{
    font-weight:800;
    color:#2a7f62;
    margin-bottom:25px;
}
.center-wrapper{
    display:flex;
    justify-content:center;
}
.form-card{
    width:420px;
    background:#fff;
    padding:26px;
    border-radius:18px;
    box-shadow:0 12px 30px rgba(0,0,0,.08);
}
.form-group{margin-bottom:18px}
.form-group label{
    font-weight:700;
    color:#2a7f62;
    display:block;
    margin-bottom:6px;
}
.form-group input,
.form-group select,
.form-group textarea{
    width:100%;
    padding:12px;
    border-radius:10px;
    border:1.8px solid #e1ece8;
}
.form-group textarea{resize:none;height:90px}
.btn-primary-full{
    width:100%;
    background:#2a7f62;
    color:#fff;
    border:none;
    padding:12px;
    border-radius:12px;
    font-weight:800;
}
</style>

<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PIXEL-PC\Desktop\sehatimain\sehati-main\resources\views/user/consultations/create.blade.php ENDPATH**/ ?>