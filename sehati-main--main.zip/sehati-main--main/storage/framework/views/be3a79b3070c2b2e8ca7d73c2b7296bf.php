<?php $__env->startSection('title','إضافة دواء جديد'); ?>

<?php $__env->startPush('styles'); ?>
<style>
/* ===== Page ===== */
.page-wrapper{
    display:flex;
    justify-content:center;
    margin-top:40px;
}

.medicine-card{
    background:#fff;
    width:100%;
    max-width:520px;
    border-radius:18px;
    padding:30px;
    box-shadow:0 12px 35px rgba(0,0,0,.08);
    animation:fadeUp .4s ease;
}

.medicine-title{
    display:flex;
    align-items:center;
    gap:12px;
    color:#2a7f62;
    font-weight:900;
    font-size:22px;
    margin-bottom:25px;
}

.medicine-title i{
    font-size:26px;
    color:#2a7f62;
}

/* ===== Form ===== */
.form-group{
    margin-bottom:18px;
}

.form-group label{
    display:block;
    font-weight:700;
    color:#555;
    margin-bottom:6px;
    font-size:14px;
}

.form-group input{
    width:100%;
    padding:11px 14px;
    border-radius:10px;
    border:1.8px solid #e1e6e4;
    font-family:'Tajawal',sans-serif;
    transition:.25s ease;
}

.form-group input:focus{
    outline:none;
    border-color:#2a7f62;
    box-shadow:0 0 0 3px rgba(42,127,98,.15);
}

/* ===== Grid ===== */
.form-grid{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:15px;
}

@media(max-width:600px){
    .form-grid{grid-template-columns:1fr}
}

/* ===== Button ===== */
.submit-btn{
    margin-top:20px;
    width:100%;
    background:#2a7f62;
    color:#fff;
    border:none;
    padding:13px;
    border-radius:12px;
    font-weight:800;
    font-size:15px;
    cursor:pointer;
    transition:.3s ease;
}

.submit-btn:hover{
    background:#256f56;
    transform:translateY(-2px);
    box-shadow:0 10px 22px rgba(42,127,98,.35);
}

/* ===== Animation ===== */
@keyframes fadeUp{
    from{opacity:0;transform:translateY(20px)}
    to{opacity:1;transform:translateY(0)}
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<div class="page-wrapper">

    <div class="medicine-card">

        <div class="medicine-title">
            <i class="fas fa-plus-circle"></i>
            إضافة دواء جديد
        </div>

        <form method="POST" action="<?php echo e(route('medicines.store')); ?>">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label>اسم الدواء</label>
                <input type="text" name="name" required>
            </div>

            <div class="form-grid">
                <div class="form-group">
                    <label>الجرعة</label>
                    <input type="text" name="dose" required>
                </div>

                <div class="form-group">
                    <label>عدد الجرعات يومياً</label>
                    <input type="number" name="times_per_day" required>
                </div>
            </div>

            <div class="form-group">
                <label>تاريخ الانتهاء</label>
                <input type="date" name="end_date">
            </div>

            <button class="submit-btn">💾 حفظ</button>
        </form>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PIXEL-PC\Desktop\sehatimain\sehati-main\resources\views/medicines/create.blade.php ENDPATH**/ ?>