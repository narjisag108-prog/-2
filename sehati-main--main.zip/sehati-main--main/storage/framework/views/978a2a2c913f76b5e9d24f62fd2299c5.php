<?php $__env->startSection('title','لوحة التحكم'); ?>

<?php $__env->startSection('content'); ?>


<div class="banner">
    <h2>مرحباً د.
         
        </h2>
    <p>
        لديك <?php echo e($stats['todayAppointments']); ?> مواعيد اليوم و
        <?php echo e($stats['newConsults']); ?> استشارات جديدة
    </p>
</div>


<div class="quick-actions">

    <div class="quick-card">
        <i class="fas fa-calendar-plus"></i>
        <h4>إضافة موعد</h4>
        <a href="<?php echo e(route('doctor.appointments.create')); ?>" class="btn-primary">
            إضافة
        </a>
    </div>

    <div class="quick-card">
        <i class="fas fa-user-plus"></i>
        <h4>مريض جديد</h4>
        <a href="<?php echo e(route('doctor.patients.create')); ?>" class="btn-primary">
            تسجيل
        </a>
    </div>

    <div class="quick-card">
        <i class="fas fa-prescription"></i>
        <h4>وصفة طبية</h4>
<a href="<?php echo e(route('doctor.prescriptions.create')); ?>" class="btn-primary">
    إنشاء وصفة
</a>

    </div>

    <div class="quick-card">
        <i class="fas fa-file-medical"></i>
        <h4>تقرير طبي</h4>
        <a href="<?php echo e(route('doctor.reports.create')); ?>" class="btn-primary">
            إنشاء
        </a>
    </div>

</div>


<div class="grid-3">

    
    <div class="card">
        <div class="card-header">
            <h4>الاستشارات الجديدة</h4>
            <div class="icon"><i class="fas fa-comment-medical"></i></div>
        </div>

       <?php $__empty_1 = true; $__currentLoopData = $newConsultations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="row">
        <div class="avatar"><?php echo e(mb_substr($c->user->name,0,1)); ?></div>

        <div class="row-info">
            <strong><?php echo e($c->user->name); ?></strong>
            <span>استشارة طبية</span>
            <small><?php echo e($c->created_at->diffForHumans()); ?></small>
        </div>

        <a href="<?php echo e(route('doctor.consultations.show',$c->id)); ?>"
           class="btn-primary">
            الرد
        </a>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p class="empty">لا توجد استشارات</p>
<?php endif; ?>

        <div class="card-actions">
         <a href="<?php echo e(route('doctor.consultations.index')); ?>"class="btn-primary">عرض الكل</a>
        </div>
    </div>

    
    <div class="card">
        <div class="card-header">
            <h4>مواعيد اليوم</h4>
            <div class="icon"><i class="fas fa-calendar"></i></div>
        </div>

        <?php $__empty_1 = true; $__currentLoopData = $todayAppointmentsList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="row">
            <div class="avatar"><?php echo e(mb_substr($a->patient->name,0,1)); ?></div>
            <div class="row-info">
                <strong><?php echo e($a->patient->name); ?></strong>
                <span><?php echo e($a->time); ?></span>
            </div>
            <span class="badge success">مؤكد</span>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="empty">لا توجد مواعيد</p>
        <?php endif; ?>

       <div class="card-actions">
    <a href="<?php echo e(route('doctor.appointments.index')); ?>" class="btn-outline">
        عرض الكل
    </a>

    <a href="<?php echo e(route('doctor.appointments.index')); ?>" class="btn-primary">
        إدارة المواعيد
    </a>
</div>

    </div>

    
    <div class="card">
        <div class="card-header">
            <h4>إحصائيات العيادة</h4>
            <div class="icon"><i class="fas fa-chart-line"></i></div>
        </div>
<div class="stats-grid">
    <div class="stat">
        <strong><?php echo e($stats['todayAppointments']); ?></strong>
        <span>مواعيد اليوم</span>
    </div>

    <div class="stat">
        <strong><?php echo e($stats['patientsCount']); ?></strong>
        <span>عدد المرضى</span>
    </div>

    <div class="stat">
        <strong><?php echo e($stats['consultationsCount']); ?></strong>
        <span>إجمالي الاستشارات</span>
    </div>

    <div class="stat">
        <strong><?php echo e($stats['rate']); ?>%</strong>
        <span>نسبة الرد</span>
    </div>
</div>

    </div>
</div>


<div class="card calendar-card">
    <div class="card-header">
        <h4>تقويم المواعيد</h4>
        <div class="icon"><i class="fas fa-calendar-alt"></i></div>
    </div>
    <div id="calendar"></div>
</div>


<div class="card">
    <div class="card-header">
        <h4>المرضى الجدد</h4>
        <div class="icon"><i class="fas fa-user-injured"></i></div>
    </div>

    <?php $__currentLoopData = $recentPatients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
        <div class="avatar"><?php echo e(mb_substr($p->name,0,1)); ?></div>
        <div class="row-info">
            <strong><?php echo e($p->name); ?></strong>
            <small><?php echo e($p->created_at->diffForHumans()); ?></small>
        </div>
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>
<style>
    :root{
    --green:#2a7f62;
    --bg:#f4f7f6;
}

/* Banner */
.banner{
    background:linear-gradient(135deg,#2a7f62,#4fbf9f);
    padding:32px;
    border-radius:22px;
    color:#fff;
    margin-bottom:40px;
}

/* Quick Actions */
.quick-actions{
    display:grid;
    grid-template-columns:repeat(4,1fr);
    gap:24px;
    margin-bottom:40px;
}
.quick-card{
    background:#fff;
    border-radius:20px;
    padding:26px;
    text-align:center;
    box-shadow:0 10px 30px rgba(0,0,0,.06);
}
.quick-card i{
    font-size:28px;
    color:var(--green);
    margin-bottom:10px;
}
.btn-green{
    background:var(--green);
    color:#fff;
    border:none;
    padding:8px 16px;
    border-radius:10px;
    cursor:pointer;
}

/* Cards */
.grid-3{
    display:grid;
    grid-template-columns:repeat(3,1fr);
    gap:28px;
}
.card{
    background:#fff;
    border-radius:22px;
    padding:24px;
    box-shadow:0 12px 30px rgba(0,0,0,.06);
}
.card-header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:18px;
}
.icon{
    width:42px;
    height:42px;
    border-radius:14px;
    background:var(--green);
    color:#fff;
    display:flex;
    align-items:center;
    justify-content:center;
}

/* Rows */
.row{
    display:flex;
    align-items:center;
    gap:14px;
    padding:14px 0;
    border-bottom:1px solid #eef2f1;
}
.avatar{
    width:42px;
    height:42px;
    border-radius:50%;
    background:var(--green);
    color:#fff;
    display:flex;
    align-items:center;
    justify-content:center;
    font-weight:700;
}
.badge.success{background:#e4f6ee;color:#2a7f62}
.badge.danger{background:#fde2e2;color:#c0392b}

/* Stats */
.stats-grid{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:16px;
}
.stat{
    background:#f8fbfa;
    border-radius:16px;
    padding:20px;
    text-align:center;
}
.stat strong{
    font-size:24px;
    color:var(--green);
}

/* Buttons */
.card-actions{
    display:flex;
    gap:12px;
    margin-top:18px;
}
.btn-outline{
    border:2px solid var(--green);
    color:var(--green);
    padding:8px 16px;
    border-radius:12px;
}
.btn-primary{
    background:var(--green);
    color:#fff;
    padding:8px 16px;
    border-radius:12px;
}

/* Calendar */
.calendar-card{
    margin-top:45px;
}
</style>
<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    new FullCalendar.Calendar(document.getElementById('calendar'), {
        initialView: 'dayGridMonth',
        locale: 'ar',
        direction: 'rtl',
        height: 520,
        headerToolbar:{
            start:'prev,next',
            center:'title',
            end:''
        },
        events: '<?php echo e(route("doctor.calendar.events")); ?>'
    }).render();
});
</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('doctor.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PIXEL-PC\Desktop\sehatimain\sehati-main\resources\views/doctor/dashboard.blade.php ENDPATH**/ ?>