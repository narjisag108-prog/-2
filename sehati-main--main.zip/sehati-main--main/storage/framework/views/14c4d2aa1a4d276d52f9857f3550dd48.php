<?php $__env->startSection('title','إضافة موعد'); ?>

<?php $__env->startSection('content'); ?>

<h2 class="page-title">➕ إضافة موعد</h2>

<div class="center-wrapper">
<form class="form-card"
      action="<?php echo e(route('doctor.appointments.store')); ?>"
      method="POST">
<?php echo csrf_field(); ?>

<div class="form-group">
    <label>المريض</label>
    <select name="patient_id" required>
        <option value="">-- اختر المريض --</option>
        <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

<div class="form-group">
    <label>تاريخ الموعد</label>
    <input type="date" name="date" required>
</div>

<div class="form-group">
    <label>الوقت</label>
    <input type="time" name="time" required>
</div>

<div class="form-group">
    <label>نوع الموعد</label>
    <input type="text" name="type" placeholder="فحص – متابعة – استشارة">
</div>

<div class="form-group">
    <label>ملاحظات</label>
    <textarea name="notes"></textarea>
</div>

<button class="btn-primary-full">حفظ الموعد</button>

</form>
</div>


<?php $__env->stopSection(); ?>

    <style>
.page-title{
    font-weight:800;
    color:#2a7f62;
    margin-bottom:25px;
}
.center-wrapper{
    display:flex;
    justify-content:center;
}
.form-card{
    width:420px;
    background:#fff;
    padding:26px;
    border-radius:18px;
    box-shadow:0 12px 30px rgba(0,0,0,.08);
}
.form-group{margin-bottom:18px}
.form-group label{
    font-weight:700;
    color:#2a7f62;
    display:block;
    margin-bottom:6px;
}
.form-group input,
.form-group select,
.form-group textarea{
    width:100%;
    padding:12px;
    border-radius:10px;
    border:1.8px solid #e1ece8;
}
.form-group textarea{resize:none;height:90px}
.btn-primary-full{
    width:100%;
    background:#2a7f62;
    color:#fff;
    border:none;
    padding:12px;
    border-radius:12px;
    font-weight:800;
}
</style>


<?php echo $__env->make('doctor.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PIXEL-PC\Desktop\sehatimain\sehati-main\resources\views/doctor/appointments/create.blade.php ENDPATH**/ ?>