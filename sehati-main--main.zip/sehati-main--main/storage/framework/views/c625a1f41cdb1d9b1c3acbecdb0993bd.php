<?php $__env->startSection('title','إضافة مريض'); ?>

<?php $__env->startSection('content'); ?>

<h2 class="page-title">➕ تسجيل مريض جديد</h2>

<div class="form-card">
    <form method="POST" action="<?php echo e(route('doctor.patients.store')); ?>">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label>اسم المريض</label>
            <input type="text" name="name" required>
        </div>

        <div class="form-group">
            <label>رقم الهاتف</label>
            <input type="text" name="phone">
        </div>

        <div class="form-group">
            <label>العمر</label>
            <input type="number" name="age">
        </div>

        <button class="btn-primary-full">حفظ</button>
    </form>
</div>

<?php $__env->stopSection(); ?>
   <style>
.page-title{
    font-weight:800;
    color:#2a7f62;
    margin-bottom:25px;
}
.center-wrapper{
    display:flex;
    justify-content:center;
}
.form-card{
    width:420px;
    background:#fff;
    padding:26px;
    border-radius:18px;
    box-shadow:0 12px 30px rgba(0,0,0,.08);
}
.form-group{margin-bottom:18px}
.form-group label{
    font-weight:700;
    color:#2a7f62;
    display:block;
    margin-bottom:6px;
}
.form-group input,
.form-group select,
.form-group textarea{
    width:100%;
    padding:12px;
    border-radius:10px;
    border:1.8px solid #e1ece8;
}
.form-group textarea{resize:none;height:90px}
.btn-primary-full{
    width:100%;
    background:#2a7f62;
    color:#fff;
    border:none;
    padding:12px;
    border-radius:12px;
    font-weight:800;
}
</style>


<?php echo $__env->make('doctor.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PIXEL-PC\Desktop\sehatimain\sehati-main\resources\views/doctor/patients/create.blade.php ENDPATH**/ ?>