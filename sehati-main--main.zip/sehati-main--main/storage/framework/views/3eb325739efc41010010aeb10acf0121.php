<?php $__env->startSection('title','مواعيد الطبيب'); ?>

<?php $__env->startSection('content'); ?>

<h2 class="page-title">📅 مواعيد المرضى</h2>

<a href="<?php echo e(route('doctor.appointments.create')); ?>" class="btn-primary add-btn">
    ➕ إضافة موعد
</a>

<div class="card">

<?php $__empty_1 = true; $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="appointment-row">

        <div class="appointment-info">
            <div class="avatar">
                <?php echo e(mb_substr($a->patient->name,0,1)); ?>

            </div>

            <div>
                <strong><?php echo e($a->patient->name); ?></strong>
                <small>
                    <?php echo e($a->date->format('d/m/Y')); ?> — <?php echo e($a->time); ?>

                </small>
            </div>
        </div>

        <div class="appointment-actions">
            <a href="<?php echo e(route('doctor.appointments.edit',$a)); ?>" class="btn-outline">
                ✏️ تعديل
            </a>

            <form method="POST" action="<?php echo e(route('doctor.appointments.destroy',$a)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button class="btn-danger" onclick="return confirm('هل أنت متأكد من الحذف؟')">
                    🗑 حذف
                </button>
            </form>
        </div>

    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p class="empty-text">لا توجد مواعيد حالياً</p>
<?php endif; ?>

</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<style>
:root{
    --green:#2a7f62;
}

/* العنوان */
.page-title{
    font-weight:800;
    color:var(--green);
    margin-bottom:20px;
}

/* زر الإضافة */
.add-btn{
    display:inline-block;
    margin-bottom:20px;
}

/* الكارد */
.card{
    background:#fff;
    border-radius:20px;
    padding:20px;
    box-shadow:0 12px 30px rgba(0,0,0,.08);
}

/* الصف */
.appointment-row{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:14px 0;
    border-bottom:1px solid #eef2f1;
}

.appointment-row:last-child{
    border-bottom:none;
}

/* معلومات الموعد */
.appointment-info{
    display:flex;
    align-items:center;
    gap:14px;
}

.avatar{
    width:42px;
    height:42px;
    border-radius:50%;
    background:var(--green);
    color:#fff;
    display:flex;
    align-items:center;
    justify-content:center;
    font-weight:800;
}

/* أزرار */
.appointment-actions{
    display:flex;
    gap:8px;
}

.btn-primary{
    background:var(--green);
    color:#fff;
    padding:10px 18px;
    border-radius:12px;
    font-weight:800;
}

.btn-outline{
    border:2px solid var(--green);
    color:var(--green);
    padding:6px 14px;
    border-radius:10px;
    font-weight:700;
}

.btn-danger{
    background:#fde2e2;
    color:#c0392b;
    border:none;
    padding:6px 14px;
    border-radius:10px;
    font-weight:700;
    cursor:pointer;
}

/* لا يوجد بيانات */
.empty-text{
    text-align:center;
    color:#8a9a97;
    padding:20px 0;
}
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('doctor.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PIXEL-PC\Desktop\sehatimain\sehati-main\resources\views/doctor/appointments/index.blade.php ENDPATH**/ ?>