<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?php echo $__env->yieldContent('title','صحتك أولاً'); ?></title>

<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<!-- SweetAlert2 for toast -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<style>
:root{--primary:#2a7f62;--accent:#ff7e5f;--light:#f8f9fa;--dark:#343a40;--text:#333}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Tajawal',sans-serif;background:#f5f7f6;color:var(--text);line-height:1.7}
.container{width:90%;max-width:1200px;margin:0 auto}
header{background:#fff;box-shadow:0 2px 10px rgba(0,0,0,.06);position:sticky;top:0;z-index:50}
.header-container{display:flex;justify-content:space-between;align-items:center;padding:14px 0}
.logo{display:flex;align-items:center}
.logo img{height:46px;margin-left:10px}
.logo h1{color:var(--primary);font-size:1.4rem}
nav ul{display:flex;list-style:none}
nav ul li{margin-right:18px}
nav a{color:var(--primary);font-weight:500}
.btn{padding:8px 18px;border-radius:6px;cursor:pointer}
.btn-primary{background:var(--primary);color:#fff;border:2px solid var(--primary)}
.btn-outline{background:transparent;color:var(--primary);border:2px solid var(--primary)}
.hero{background:linear-gradient(135deg,rgba(42,127,98,0.9),rgba(58,183,149,0.9)), url('<?php echo e(asset("images/medical-bg.jpg")); ?>') center/cover no-repeat;color:#fff;padding:90px 0;text-align:center}
.hero h2{font-size:2.4rem;margin-bottom:10px}
.hero p{font-size:1.05rem;opacity:.95}
.section{padding:60px 0;background:#fff;margin-top:18px;border-radius:8px;box-shadow:0 6px 24px rgba(0,0,0,.03)}
.diseases-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:22px}
.disease-card{background:#fff;border-radius:12px;box-shadow:0 8px 24px rgba(0,0,0,.04);overflow:hidden;display:flex;flex-direction:column;min-height:320px}
.disease-img{height:170px;background:#f3f6f5;overflow:hidden}
.disease-img img{width:100%;height:100%;object-fit:cover}
.disease-content{padding:20px;flex:1;display:flex;flex-direction:column}
.disease-content h3{color:var(--primary);margin-bottom:8px}
.disease-content p{color:#6c757d;flex:1}
.disease-content .btn{align-self:flex-start;margin-top:14px}
.services-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:20px}
.service-card{background:#fff;padding:28px;border-radius:12px;box-shadow:0 6px 20px rgba(0,0,0,.03);text-align:center}
.service-card i{font-size:28px;color:var(--primary);margin-bottom:12px}
.testimonials-slider{display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:16px;margin-top:18px}
.testimonial{background:#fff;padding:18px;border-radius:12px;box-shadow:0 6px 20px rgba(0,0,0,.03)}
.testimonial-author{display:flex;gap:12px;align-items:center;margin-top:12px}
.author-img img{width:48px;height:48px;border-radius:50%;object-fit:cover}
.newsletter{background:linear-gradient(135deg,rgba(42,127,98,0.92),rgba(58,183,149,0.9));color:#fff;padding:50px;border-radius:8px;text-align:center;margin-top:18px}
.newsletter input{padding:12px 14px;border-radius:6px;border:none;width:320px;max-width:80%}
.newsletter button{padding:12px 16px;border-radius:6px;border:none;background:var(--accent);color:#fff;margin-left:8px}
footer{background:var(--dark);color:#fff;padding:60px 0;margin-top:30px}
.footer-container{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:25px}
.footer-bottom{text-align:center;color:#b9c2bf;padding-top:14px}
@media(max-width:900px){nav ul{display:none}}
</style>

<?php echo $__env->yieldPushContent('head'); ?>
</head>
<body>
    <header>
        <div class="container header-container">
            <div class="logo"><img src="<?php echo e(asset('storage/logo.png')); ?>" alt="logo">
<h1>صحتك أولاً</h1></div>
            <nav>
                <ul>
                    <li><a href="<?php echo e(route('home')); ?>">الرئيسية</a></li>
                    <li><a href="#diseases">الأمراض</a></li>
                    <li><a href="#features">الخدمات</a></li>
                    <li><a href="/articles">المقالات</a></li>
                    <li><a href="<?php echo e(route('contact.show')); ?>">اتصل بنا</a></li>

                </ul>
            </nav>
            <div class="auth-buttons">
                <a href="login" class="btn btn-outline">تسجيل الدخول</a>
                <a href="register" class="btn btn-primary">إنشاء حساب</a>
            </div>
        </div>
    </header>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer>
        <div class="container">
            <div class="footer-container">
                <div>
                    <h2>صحتك أولاً</h2>
                    <p>منصة تثقيفية تهدف إلى توعية المجتمع بالأمراض المزمنة وطرق الوقاية والعلاج.</p>
                </div>
                <div>
                    <h3>روابط سريعة</h3>
                    <ul style="list-style:none;padding:0">
                        <li><a href="<?php echo e(route('home')); ?>" style="color:#fff;opacity:.9">الرئيسية</a></li>
                        <li><a href="#diseases" style="color:#fff;opacity:.9">الأمراض المزمنة</a></li>
                        <li><a href="#features" style="color:#fff;opacity:.9">خدماتنا</a></li>
                    </ul>
                </div>

                <div>
                    <div>
                    <h3>اتصل بنا</h3>
                    <p><i class="fas fa-map-marker-alt"></i> 'طرابلس' ليبيا</p>
                    <p><i class="fas fa-phone"></i> +218 91 234 5678</p>
                    <p><i class="fas fa-envelope"></i> healthfirst@gmail.com</p>
                </div>
            </div>
            </div>
            <div class="footer-bottom">&copy; <?php echo e(date('Y')); ?> صحتك أولاً. جميع الحقوق محفوظة.</div>
        </div>
    </footer>

<script>
document.addEventListener('DOMContentLoaded', function(){
    <?php if(session('success')): ?>
        Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: <?php echo json_encode(session('success')); ?>, showConfirmButton:false, timer:2500 });
    <?php endif; ?>
});
</script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\PIXEL-PC\Desktop\sehatimain\sehati-main\resources\views/layouts/app.blade.php ENDPATH**/ ?>