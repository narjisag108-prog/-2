<?php $__env->startSection('title','استشاراتي'); ?>

<?php $__env->startSection('content'); ?>

<h2 class="page-title">💬 استشاراتي</h2>

<a href="<?php echo e(route('user.consultations.create')); ?>" class="btn-primary-full">
    ➕ استشارة جديدة
</a>

<?php $__empty_1 = true; $__currentLoopData = $consultations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<div class="card" style="margin-top:15px">
    <h4><?php echo e($c->title); ?></h4>

    <p><?php echo e(Str::limit($c->message,100)); ?></p>

    <small>
        الحالة:
        <strong><?php echo e($c->status); ?></strong>
    </small>

    <br><br>

    <a href="<?php echo e(route('user.consultations.show',$c->id)); ?>">
        عرض التفاصيل
    </a>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<p style="margin-top:20px">لا توجد استشارات</p>
<?php endif; ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PIXEL-PC\Desktop\sehatimain\sehati-main\resources\views/user/consultations/index.blade.php ENDPATH**/ ?>