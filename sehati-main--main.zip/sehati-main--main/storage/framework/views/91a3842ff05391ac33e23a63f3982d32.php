<?php $__env->startSection('title','الأدوية'); ?>

<?php $__env->startPush('styles'); ?>
<style>
/* ===== Page ===== */
.page-title{
    font-size:24px;
    font-weight:800;
    color:#2a7f62;
    margin-bottom:20px;
}

/* ===== Add Button ===== */
.add-btn{
    display:inline-block;
    background:#2a7f62;
    color:#fff;
    padding:10px 18px;
    border-radius:10px;
    font-weight:700;
    margin-bottom:20px;
    transition:.3s ease;
}
.add-btn:hover{
    background:#256f56;
    transform:translateY(-2px);
    box-shadow:0 8px 20px rgba(42,127,98,.35);
}

/* ===== Card ===== */
.medicine-card{
    background:#fff;
    border-radius:18px;
    box-shadow:0 10px 30px rgba(0,0,0,.06);
    overflow:hidden;
}

/* ===== Medicine Row ===== */
.medicine-row{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:18px 22px;
    border-bottom:1px solid #eef2f1;
    transition:.25s ease;
}
.medicine-row:hover{
    background:#f8fbfa;
}
.medicine-row:last-child{
    border-bottom:none;
}

/* ===== Info ===== */
.medicine-info strong{
    font-size:16px;
    color:#2a7f62;
}
.medicine-info div{
    font-size:13px;
    color:#6f7f7b;
    margin-top:2px;
}

/* ===== Date ===== */
.medicine-date{
    font-size:12px;
    color:#8a9a97;
    white-space:nowrap;
}

/* ===== Empty ===== */
.empty{
    padding:25px;
    text-align:center;
    color:#8a9a97;
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<h2 class="page-title">💊 أدويتك</h2>

<a href="<?php echo e(route('medicines.create')); ?>" class="add-btn">
    ➕ إضافة دواء
</a>

<div class="medicine-card">

    <?php $__empty_1 = true; $__currentLoopData = $medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="medicine-row">

            <div class="medicine-info">
                <strong><?php echo e($m->name); ?></strong>
                <div>الجرعة: <?php echo e($m->dose); ?></div>
                <div>مرات يومياً: <?php echo e($m->times_per_day); ?></div>
            </div>

            <div class="medicine-date">
                <?php echo e($m->end_date?->format('Y-m-d') ?? 'بدون انتهاء'); ?>

            </div>
<div style="display:flex;gap:10px">

    
    <a href="<?php echo e(route('medicines.edit', $m)); ?>"
       style="color:#2a7f62;font-weight:700">
        ✏️ تعديل
    </a>

    
    <form action="<?php echo e(route('medicines.destroy', $m)); ?>" method="POST"
          onsubmit="return confirm('هل أنت متأكد من الحذف؟')">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button style="
            background:none;
            border:none;
            color:#c0392b;
            font-weight:700;
            cursor:pointer">
            🗑 حذف
        </button>
    </form>

</div>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="empty">
            لا توجد أدوية مضافة بعد
        </div>
    <?php endif; ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PIXEL-PC\Desktop\sehatimain\sehati-main\resources\views/medicines/index.blade.php ENDPATH**/ ?>