<?php $__env->startSection('title', 'المقالات'); ?>

<?php $__env->startPush('styles'); ?>
<style>
.articles-container{
    max-width:1200px;
    margin:70px auto;
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(280px,1fr));
    gap:25px;
}

.article-card{
    background:#fff;
    border-radius:18px;
    box-shadow:0 12px 30px rgba(0,0,0,.08);
    overflow:hidden;
    display:flex;
    flex-direction:column;
    transition:.35s ease;
}

.article-card:hover{
    transform:translateY(-6px);
    box-shadow:0 20px 40px rgba(0,0,0,.14);
}

.article-card img{
    width:100%;
    height:180px;
    object-fit:cover;
}

.article-content{
    padding:22px;
    flex:1;
    display:flex;
    flex-direction:column;
}

.article-content h3{
    font-size:1.25rem;
    margin-bottom:10px;
    color:#2a7f62;
    font-weight:800;
}

.article-meta{
    font-size:.85rem;
    color:#8a9a97;
    margin-bottom:12px;
    display:flex;
    gap:10px;
    flex-wrap:wrap;
}

.article-excerpt{
    flex:1;
    color:#555;
    line-height:1.7;
    margin-bottom:16px;
}

.read-more{
    align-self:flex-start;
    padding:10px 18px;
    background:#2a7f62;
    color:#fff;
    border-radius:12px;
    font-weight:700;
    transition:.3s;
}

.read-more:hover{
    background:#246b54;
}

.pagination-box{
    max-width:1200px;
    margin:30px auto;
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<div class="articles-container">
<?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="article-card">
        <img src="<?php echo e($article->image
            ? asset('storage/'.$article->image)
            : 'https://via.placeholder.com/400x180?text=Article'); ?>">

        <div class="article-content">
            <h3><?php echo e($article->title); ?></h3>

            <div class="article-meta">
                <span>✍️ <?php echo e($article->author_name); ?></span>
                <?php if($article->disease): ?>
                    <span>🩺 <?php echo e($article->disease->name); ?></span>
                <?php endif; ?>
                <span>📅 <?php echo e($article->created_at->format('d M Y')); ?></span>
            </div>

            <p class="article-excerpt">
                <?php echo e(Str::limit(strip_tags($article->content),120)); ?>

            </p>

            <a href="<?php echo e(route('articles.show',$article->id)); ?>" class="read-more">
                اقرأ المزيد
            </a>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p>لا توجد مقالات حالياً.</p>
<?php endif; ?>
</div>

<div class="pagination-box">
    <?php echo e($articles->links()); ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.me', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PIXEL-PC\Desktop\sehatimain\sehati-main\resources\views/articles/index.blade.php ENDPATH**/ ?>