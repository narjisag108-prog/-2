<?php echo $__env->make('components.chatbot', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?php echo $__env->yieldContent('title','صحتك أولاً'); ?></title>

<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@300;400;500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
/* ========== VARIABLES ========== */
:root{
--primary:#2a7f62;
--primary-light:#3ab795;
--secondary:#ff7e5f;
--dark:#343a40;
--text:#333;
--light:#f8f9fa;
--radius:14px;
--shadow:0 8px 25px rgba(0,0,0,.08);
}

/* ========== BASE ========== */
*{box-sizing:border-box;margin:0;padding:0}
body{
font-family:'Tajawal',sans-serif;
background:linear-gradient(135deg,#f5f7fa,#e4e8ee);
color:var(--text);
line-height:1.7;
}
a{text-decoration:none;color:var(--primary)}
.container{width:90%;max-width:1400px;margin:auto}

/* ========== HEADER ========== */
header{
background:#fff;
position:sticky;
top:0;
z-index:100;
box-shadow:0 4px 20px rgba(0,0,0,.08)
}
.header-container{
display:flex;
justify-content:space-between;
align-items:center;
padding:14px 0;
gap:20px
}
.logo{display:flex;align-items:center;gap:10px}
.logo img{height:48px}
.logo h1{
font-size:1.7rem;
font-weight:700;
background:linear-gradient(135deg,var(--primary),var(--primary-light));
-webkit-background-clip:text;
-webkit-text-fill-color:transparent;
}

/* ========== NAV ========== */
nav ul{display:flex;gap:14px;list-style:none}
nav a{
padding:8px 14px;
border-radius:8px;
font-weight:500;
transition:.3s
}
nav a:hover{
background:rgba(42,127,98,.1)
}

/* ========== USER MENU ========== */
.user-menu{
display:flex;
align-items:center;
gap:12px
}
.user-info{
display:flex;
align-items:center;
gap:10px;
background:rgba(42,127,98,.08);
padding:6px 14px;
border-radius:50px
}
.user-avatar{
width:42px;height:42px;
border-radius:50%;
background:linear-gradient(135deg,var(--primary),var(--primary-light));
display:flex;
align-items:center;
justify-content:center;
color:#fff;
font-weight:700;
font-size:1.1rem
}
.btn{
padding:8px 18px;
border-radius:8px;
border:none;
cursor:pointer;
font-weight:600
}
.btn-outline{
border:2px solid var(--primary);
color:var(--primary);
background:transparent
}
.btn-outline:hover{
background:var(--primary);
color:#fff
}

/* ========== MAIN ========== */
main{
padding:35px 0;
min-height:70vh
}

/* ========== FOOTER ========== */
footer{
background:var(--dark);
color:#fff;
margin-top:50px;
padding:40px 0
}
footer a{color:#fff;opacity:.9}
.footer-bottom{
text-align:center;
color:#ccc;
font-size:.9rem;
margin-top:20px
}
</style>

<?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body>

<header>
<div class="container header-container">

<div class="logo">
<img src="<?php echo e(asset('storage/logo.png')); ?>" alt="logo">
<h1>صحتك أولاً</h1>
</div>

<nav>
<ul>
<li><a href="<?php echo e(route('user.dashboard')); ?>">لوحة التحكم</a></li>
<li><a href="<?php echo e(route('readings.dashboard')); ?>">المؤشرات</a></li>
<li><a href="<?php echo e(route('medicines.index')); ?>">الأدوية</a></li>
<li><a href="<?php echo e(route('appointments.index')); ?>">المواعيد</a></li>
<li><a href="<?php echo e(route('articles.index')); ?>">المقالات</a></li>
<li><a href="<?php echo e(route('user.consultations.index')); ?>">إستشاراتي</a></li>
</ul>
</nav>

<div class="user-menu">

<div class="user-info">
<div class="user-avatar">
<?php echo e(mb_substr(auth()->user()->first_name,0,1)); ?>

</div>
<div>
<strong><?php echo e(auth()->user()->first_name); ?></strong><br>
<small style="color:#666">مستخدم</small>
</div>
</div>

<form method="POST" action="<?php echo e(route('logout')); ?>">
<?php echo csrf_field(); ?>
<button class="btn btn-outline">خروج</button>
</form>

</div>

</div>
</header>

<main class="container">
<?php echo $__env->yieldContent('content'); ?>
</main>

<footer>
<div class="container">
<p>منصة ذكية لمتابعة صحتك اليومية</p>
<div class="footer-bottom">
&copy; <?php echo e(date('Y')); ?> صحتك أولاً
</div>
</div>
</footer>

<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\PIXEL-PC\Desktop\sehatimain\sehati-main\resources\views/layouts/user.blade.php ENDPATH**/ ?>