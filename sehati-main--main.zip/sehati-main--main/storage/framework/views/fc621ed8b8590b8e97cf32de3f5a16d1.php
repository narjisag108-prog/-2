<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>تسجيل الدخول</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php if(session('success')): ?>
<script>
Swal.fire({icon:'success',title:'<?php echo e(session("success")); ?>',showConfirmButton:false,timer:2000});
</script>
<?php endif; ?>

<?php if($errors->any()): ?>
<script>
Swal.fire({icon:'error',title:'خطأ!',text:'<?php echo e($errors->first()); ?>',timer:3000});
</script>
<?php endif; ?>

<style>
/* ====== الخلفية ====== */
body {
    font-family: "Tajawal", sans-serif;
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    background:
        linear-gradient(rgba(0,0,0,0.55), rgba(0,0,0,0.55)),
        url('<?php echo e(asset("storage/sahatek.jpg")); ?>') center/cover no-repeat;
}

/* ====== كرت شفاف (Glass Effect) ====== */
.card-login {
    width: 420px;
    background: rgba(255,255,255,0.15);
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    border-radius: 26px;
    padding: 42px 38px;
    position: relative;
    box-shadow: 0 30px 70px rgba(0,0,0,0.45);
    animation: fadeIn .8s ease;
    color: #ffffff; /* كل النص أبيض */
}

/* ====== Watermark ====== */
.card-login::after {
    content: "";
    position: absolute;
    inset: 0;
    background: url('<?php echo e(asset("storage/sahatek.jpg")); ?>') center/240px no-repeat;
    opacity: 0.03;
    pointer-events: none;
}

/* ====== العنوان ====== */
h3 {
    color: #ffffff;
    font-weight: 800;
    margin-bottom: 32px;
    text-align: center;
}

/* ====== الـ labels ====== */
label {
    color: #ffffff;
}

/* ====== الحقول ====== */
.input-group-text {
    background: rgba(255,255,255,0.25);
    border: none;
    color: #ffffff;
    border-radius: 12px 0 0 12px;
}

.form-control {
    border: 1px solid rgba(255,255,255,0.35);
    border-radius: 0 12px 12px 0;
    height: 48px;
    font-size: 15px;
    background: rgba(255,255,255,0.2);
    color: #ffffff;
}

.form-control::placeholder {
    color: rgba(255,255,255,0.7);
}

.form-control:focus {
    border-color: #ffffff;
    box-shadow: 0 0 0 2px rgba(255,255,255,0.25);
    background: rgba(255,255,255,0.25);
    color: #ffffff;
}

/* ====== زر الدخول ====== */
.btn-login {
    width: 100%;
    background: rgba(255,255,255,0.25); /* زر زجاجي */
    color: #ffffff;                     /* النص أبيض */
    border: 1px solid rgba(255,255,255,0.6);
    border-radius: 14px;
    padding: 13px;
    margin-top: 18px;
    font-size: 17px;
    font-weight: 700;
    backdrop-filter: blur(4px);
    box-shadow: 0 8px 18px rgba(0,0,0,0.35);
}

.btn-login:hover {
    background: rgba(255,255,255,0.35);
    color: #ffffff;
    transform: translateY(-1px);
}


/* ====== روابط ====== */
.other-link {
    text-align: center;
    margin-top: 18px;
    font-weight: 500;
    color: #ffffff;
}

.other-link a {
    color: #ffffff;
    text-decoration: underline;
}

/* ====== أيقونات التواصل ====== */
.social-icons {
    text-align: center;
    margin-top: 18px;
}

.social-icons i {
    font-size: 20px;
    margin: 0 8px;
    color: #ffffff;
    cursor: pointer;
    transition: 0.3s;
}

.social-icons i:hover {
    transform: scale(1.12);
}

/* ====== Animation ====== */
@keyframes fadeIn {
    from { opacity:0; transform:translateY(22px); }
    to { opacity:1; transform:translateY(0); }
}
</style>
</head>

<body>

<div class="card-login">

    <h3><i class="fas fa-sign-in-alt"></i> تسجيل الدخول</h3>

    <form action="<?php echo e(route('login.post')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <label class="mb-1">البريد الإلكتروني</label>
        <div class="input-group mb-3">
            <span class="input-group-text"><i class="fas fa-envelope"></i></span>
            <input type="email" name="email" class="form-control" required>
        </div>

        <label class="mb-1">كلمة المرور</label>
        <div class="input-group mb-3">
            <span class="input-group-text"><i class="fas fa-lock"></i></span>
            <input type="password" name="password" class="form-control" required>
        </div>

        <button class="btn-login">تسجيل الدخول</button>

        <div class="other-link">
            ليس لديك حساب؟
            <a href="<?php echo e(route('register')); ?>">إنشاء حساب</a>
        </div>

        <div class="social-icons">
            <i class="fab fa-facebook-f"></i>
            <i class="fab fa-google"></i>
            <i class="fab fa-twitter"></i>
        </div>
    </form>

</div>

</body>
</html>
<?php /**PATH C:\Users\PIXEL-PC\Desktop\sehatimain\sehati-main\resources\views/login.blade.php ENDPATH**/ ?>