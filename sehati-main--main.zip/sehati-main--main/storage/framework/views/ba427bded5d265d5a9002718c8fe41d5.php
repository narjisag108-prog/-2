<?php $__env->startSection('title','قائمة المرضى'); ?>

<?php $__env->startSection('content'); ?>

<h2>👨‍⚕️ المرضى</h2>

<div class="card">
<?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div style="display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px solid #eee">
        <span><?php echo e($p->name); ?></span>
        <a href="<?php echo e(route('doctor.patients.show',$p->id)); ?>">عرض الملف</a>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('doctor.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PIXEL-PC\Desktop\sehatimain\sehati-main\resources\views/doctor/patients/index.blade.php ENDPATH**/ ?>