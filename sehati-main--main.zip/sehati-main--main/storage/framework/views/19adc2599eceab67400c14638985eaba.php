<?php $__env->startSection('title','وصفة طبية جديدة'); ?>

<?php $__env->startSection('content'); ?>

<h2 class="page-title">📝 إنشاء وصفة طبية</h2>

<div class="center-wrapper">
<form method="POST"
      action="<?php echo e(route('doctor.prescriptions.store')); ?>"
      class="form-card">
<?php echo csrf_field(); ?>


<div class="form-group">
    <label>👤 المريض</label>
    <select name="patient_id" required>
        <option value="">— اختر المريض —</option>
        <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>


<div class="form-group">
    <label>📅 الموعد (اختياري)</label>
    <select name="appointment_id">
        <option value="">— بدون ربط —</option>
        <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($a->id); ?>">
                <?php echo e($a->patient->name); ?> — <?php echo e($a->date->format('d/m')); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>


<div class="form-group">
    <label>🩺 التشخيص</label>
    <textarea name="diagnosis"
              placeholder="اكتب تشخيص الحالة"></textarea>
</div>


<div class="form-group">
    <label>💊 الأدوية</label>
    <textarea name="medicines"
              required
              placeholder="مثال:
- Paracetamol 500mg مرتين يومياً
- Amoxicillin بعد الأكل"></textarea>
</div>


<div class="form-group">
    <label>📝 ملاحظات إضافية</label>
    <textarea name="notes"
              placeholder="تعليمات خاصة للمريض (اختياري)"></textarea>
</div>

<button class="btn-primary-full">
    💾 حفظ الوصفة الطبية
</button>

</form>
</div>

<?php $__env->stopSection(); ?>
<style>
:root{
    --green:#2a7f62;
    --bg:#f4f7f6;
}

/* ===== العنوان ===== */
.page-title{
    font-weight:900;
    color:var(--green);
    margin-bottom:30px;
}

/* ===== توسيط ===== */
.center-wrapper{
    display:flex;
    justify-content:center;
}

/* ===== الكارد ===== */
.form-card{
    width:460px;
    background:#fff;
    padding:30px;
    border-radius:22px;
    box-shadow:0 14px 35px rgba(0,0,0,.1);
    animation:fadeUp .45s ease;
}

/* ===== الحقول ===== */
.form-group{
    margin-bottom:20px;
}

.form-group label{
    font-weight:800;
    color:var(--green);
    display:block;
    margin-bottom:8px;
    font-size:14px;
}

.form-group input,
.form-group select,
.form-group textarea{
    width:100%;
    padding:13px 15px;
    border-radius:14px;
    border:1.8px solid #e1ece8;
    font-family:inherit;
    font-size:14px;
    background:#fff;
    transition:.25s;
}

.form-group textarea{
    min-height:95px;
    resize:none;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus{
    outline:none;
    border-color:var(--green);
    box-shadow:0 0 0 4px rgba(42,127,98,.15);
}

/* ===== زر ===== */
.btn-primary-full{
    width:100%;
    background:linear-gradient(135deg,#2a7f62,#4fbf9f);
    color:#fff;
    border:none;
    padding:14px;
    border-radius:16px;
    font-weight:900;
    font-size:15px;
    cursor:pointer;
    transition:.3s;
}

.btn-primary-full:hover{
    transform:translateY(-2px);
    box-shadow:0 12px 25px rgba(42,127,98,.35);
}

/* ===== أنيميشن ===== */
@keyframes fadeUp{
    from{opacity:0;transform:translateY(25px)}
    to{opacity:1;transform:translateY(0)}
}
</style>

<?php echo $__env->make('doctor.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PIXEL-PC\Desktop\sehatimain\sehati-main\resources\views/doctor/prescriptions/create.blade.php ENDPATH**/ ?>