<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="container">
        <div class="diseases-grid">
            <?php $__currentLoopData = $diseases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="disease-card">
                <img src="<?php echo e(asset('storage/'.$d->image)); ?>">
                <div class="disease-content">
                    <h3><?php echo e($d->name); ?></h3>
                    <p><?php echo e(Str::limit(strip_tags($d->content),150)); ?></p>
                    <a href="<?php echo e(route('diseases.show', $d->slug)); ?>" class="btn btn-outline">المزيد من المعلومات</a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PIXEL-PC\Desktop\sehatimain\sehati-main\resources\views/diseases/index.blade.php ENDPATH**/ ?>