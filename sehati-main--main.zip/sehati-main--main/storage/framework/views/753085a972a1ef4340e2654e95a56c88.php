<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title','لوحة الطبيب'); ?> - صحتك أولاً</title>

    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800&display=swap" rel="stylesheet">

    
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/index.global.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.11/index.global.min.js"></script>

    
    <style>
        :root{
            --primary:#2a7f62;
            --primary-light:#3ab795;
            --dark:#343a40;
            --bg:#f4f7f6;
            --text:#333;
            --shadow:0 8px 25px rgba(0,0,0,.08);
            --radius:16px;
        }

        *{box-sizing:border-box;margin:0;padding:0}

        body{
            font-family:'Tajawal',sans-serif;
            background:linear-gradient(135deg,#f5f7fa,#e4e8ee);
            color:var(--text);
            line-height:1.7;
        }

        a{text-decoration:none;color:var(--primary)}
        .container{width:90%;max-width:1400px;margin:auto}

        /* ===== HEADER ===== */
        header{
            background:#fff;
            position:sticky;
            top:0;
            z-index:100;
            box-shadow:0 4px 20px rgba(0,0,0,.08);
        }

        .header-container{
            display:flex;
            justify-content:space-between;
            align-items:center;
            padding:14px 0;
        }

        .logo{
            display:flex;
            align-items:center;
            gap:10px;
        }

        .logo img{height:46px}

        .logo h1{
            font-size:1.6rem;
            font-weight:800;
            background:linear-gradient(135deg,var(--primary),var(--primary-light));
            -webkit-background-clip:text;
            -webkit-text-fill-color:transparent;
        }

        /* ===== NAV ===== */
        nav ul{
            display:flex;
            gap:14px;
            list-style:none;
        }

        nav a{
            padding:8px 14px;
            border-radius:10px;
            font-weight:600;
            transition:.3s;
        }

        nav a:hover{
            background:rgba(42,127,98,.1);
        }

        /* ===== USER MENU ===== */
        .user-menu{
            display:flex;
            align-items:center;
            gap:12px;
        }

        .user-info{
            display:flex;
            align-items:center;
            gap:10px;
            background:rgba(42,127,98,.08);
            padding:6px 14px;
            border-radius:50px;
        }

        .user-avatar{
            width:42px;
            height:42px;
            border-radius:50%;
            background:linear-gradient(135deg,var(--primary),var(--primary-light));
            display:flex;
            align-items:center;
            justify-content:center;
            color:#fff;
            font-weight:800;
        }

        .logout-btn{
            background:transparent;
            border:2px solid #3ce7a0;
            color:#3ce7a0;
            padding:6px 14px;
            border-radius:10px;
            font-weight:700;
            cursor:pointer;
            transition:.3s;
        }

        .logout-btn:hover{
            background:#3ce7a5;
            color:#fff;
        }

        /* ===== MAIN ===== */
        main{
            padding:40px 0;
            min-height:75vh;
        }

        /* ===== FOOTER ===== */
        footer{
            background:var(--dark);
            color:#fff;
            margin-top:60px;
            padding:35px 0;
        }

        footer p{
            text-align:center;
            opacity:.85;
        }
    </style>

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body>


<header>
    <div class="container header-container">

        <div class="logo">
            <img src="<?php echo e(asset('storage/logo.png')); ?>" alt="logo">
            <h1>صحتك أولاً</h1>
        </div>

        <nav>
            <ul>
                <li><a href="<?php echo e(route('doctor.dashboard')); ?>">لوحة التحكم</a></li>
                <li><a href="<?php echo e(route('doctor.appointments.index')); ?>">المواعيد</a></li>
                <li><a href="<?php echo e(route('doctor.consultations.index')); ?>">الاستشارات</a></li>
                <li><a href="<?php echo e(route('doctor.patients.index')); ?>">المرضى</a></li>
            </ul>
        </nav>


<div class="user-menu">

<div class="user-info">
<div class="user-avatar">
<?php echo e(mb_substr(auth()->user()->first_name,0,1)); ?>

</div>
<div>
<strong><?php echo e(auth()->user()->first_name); ?></strong><br>
<small style="color:#666">الدكتور</small>
</div>
</div>


            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <button class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i>
                </button>
            </form>
        </div>

    </div>
</header>


<main>
    <div class="container">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</main>


<footer>
    <p>© <?php echo e(date('Y')); ?> منصة صحتك أولاً</p>
</footer>

<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\PIXEL-PC\Desktop\sehatimain\sehati-main\resources\views/doctor/layout.blade.php ENDPATH**/ ?>