<div id="chatbot" class="chatbot closed">
    <div class="chat-header" onclick="toggleChat()">
        🤖 المساعد الصحي
        <span id="chatToggle">▲</span>
    </div>

    <div class="chat-content">
        <div id="chatBody" class="chat-body"></div>

        <form id="chatForm" class="chat-form">
            <?php echo csrf_field(); ?>
            <input type="text" id="chatInput" placeholder="اسأل عن صحتك..." required>
            <button type="submit">➤</button>
        </form>
    </div>
</div>
<style>
.chatbot{
    position:fixed;
    bottom:20px;
    left:20px;
    width:320px;
    background:#fff;
    border-radius:16px;
    box-shadow:0 12px 35px rgba(0,0,0,.15);
    font-family:'Tajawal';
    z-index:9999;
    overflow:hidden;
    transition:height .3s ease;
}

/* الشريط فقط */
.chatbot.closed{
    height:48px;
}

/* مفتوح */
.chatbot.open{
    height:380px;
}

.chat-header{
    background:#2a7f62;
    color:#fff;
    padding:12px 14px;
    font-weight:800;
    cursor:pointer;
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.chat-content{
    display:flex;
    flex-direction:column;
    height:calc(100% - 48px);
}

.chatbot.closed .chat-content{
    display:none;
}

.chat-body{
    flex:1;
    padding:14px;
    overflow-y:auto;
    background:#f8fbfa;
}

.chat-msg{
    margin-bottom:10px;
    padding:10px 14px;
    border-radius:12px;
    max-width:85%;
    font-size:.9rem;
}

.user-msg{
    background:#2a7f62;
    color:#fff;
    margin-left:auto;
}

.bot-msg{
    background:#e4f3ee;
    color:#2a7f62;
}

.chat-form{
    display:flex;
    border-top:1px solid #eee;
}

.chat-form input{
    flex:1;
    border:none;
    padding:12px;
}

.chat-form button{
    background:#2a7f62;
    color:#fff;
    border:none;
    padding:0 18px;
    font-size:18px;
}
</style>
<script>
const chatForm = document.getElementById('chatForm');
const chatBody = document.getElementById('chatBody');
const chatInput = document.getElementById('chatInput');
const chatbot   = document.getElementById('chatbot');
const chatToggle = document.getElementById('chatToggle');

function toggleChat(){
    chatbot.classList.toggle('open');
    chatbot.classList.toggle('closed');
    chatToggle.textContent = chatbot.classList.contains('open') ? '▼' : '▲';
}

chatForm.addEventListener('submit', async e => {
    e.preventDefault();

    const msg = chatInput.value.trim();
    if (!msg) return;

    chatInput.value = '';
    chatBody.innerHTML += `<div class="chat-msg user-msg">${msg}</div>`;
    chatBody.scrollTop = chatBody.scrollHeight;

    try {
        const res = await fetch("<?php echo e(route('chat.send')); ?>", {
            method:'POST',
            headers:{
                'Content-Type':'application/json',
                'X-CSRF-TOKEN':'<?php echo e(csrf_token()); ?>'
            },
            body:JSON.stringify({ message: msg })
        });

        const data = await res.json();
        chatBody.innerHTML += `<div class="chat-msg bot-msg">${data.reply}</div>`;
    } catch {
        chatBody.innerHTML += `<div class="chat-msg bot-msg">⚠️ فشل الاتصال</div>`;
    }

    chatBody.scrollTop = chatBody.scrollHeight;
});
</script>

<?php /**PATH C:\Users\PIXEL-PC\Desktop\sehatimain\sehati-main\resources\views/components/chatbot.blade.php ENDPATH**/ ?>