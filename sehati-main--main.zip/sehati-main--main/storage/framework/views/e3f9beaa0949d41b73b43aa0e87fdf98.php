<?php $__env->startSection('title', 'إضافة اختبار جديد'); ?>
<?php $__env->startSection('content'); ?>

<div class="admin-form">
    <h2><i class="fas fa-vial"></i> إضافة اختبار جديد</h2>

    <form action="<?php echo e(route('admin.tests.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <label>اسم الاختبار:</label>
        <input type="text" name="title" value="<?php echo e(old('title')); ?>" required>

        <label>الوصف:</label>
        <textarea name="description" rows="4"><?php echo e(old('description')); ?></textarea>

        <label>مرتبط بمرض:</label>
        <select name="disease_id">
            <option value="">— بدون ارتباط —</option>
            <?php $__currentLoopData = $diseases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($d->id); ?>"><?php echo e($d->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <button type="submit" class="btn btn-primary">حفظ</button>
        <a href="<?php echo e(route('admin.tests.index')); ?>" class="btn btn-outline">إلغاء</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PIXEL-PC\Desktop\sehatimain\sehati-main\resources\views/admin/tests/create.blade.php ENDPATH**/ ?>