<?php $__env->startSection('title','إدارة الأمراض'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">

      <!-- التاريخ والوقت (نفس النسخة الأصلية) -->
<div class="date-time-box mb-3">
    <span id="current-day"></span>
    <span id="current-date"></span>
    <span id="current-time"></span>
</div>
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
        <h2>إدارة الأمراض</h2>
        <div>
            <a href="<?php echo e(route('admin.diseases.create')); ?>" class="btn btn-primary"><i class="fas fa-plus"></i> إضافة مرض</a>

        </div>
    </div>

    <div class="card mb-2">
        <form method="GET" action="<?php echo e(route('admin.diseases.index')); ?>" style="display:flex;gap:18px;flex-wrap:wrap">
            <input type="text" name="q" value="<?php echo e(request('q')); ?>" class="form-control" placeholder="ابحث باسم المرض...">
            <select name="status" class="form-control">
                <option value="">الحالة</option>
                <option value="active" <?php if(request('status')=='active'): echo 'selected'; endif; ?>>نشط</option>
                <option value="inactive" <?php if(request('status')=='inactive'): echo 'selected'; endif; ?>>غير نشط</option>
            </select>
            <div>
           <select name="category_id" class="form-control">
    <option value="">كل التصنيفات</option>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($cat->id); ?>" <?php if(request('category_id') == $cat->id): echo 'selected'; endif; ?>>
            <?php echo e($cat->name); ?>

        </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>
            <button class="btn btn-primary">بحث</button>
            <a href="<?php echo e(route('admin.diseases.index')); ?>" class="btn btn-outline">إعادة تعيين</a>
        </form>
    </div>

    <!-- جدول الأمراض -->
    <div class="table-container">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>الاسم</th>
                    <th>التصنيف</th>
                    <th>الوصف</th>
                    <th>عدد المقالات</th>
                    <th>عدد الاختبارات</th>
                    <th>تاريخ الإضافة</th>
                    <th>الحالة</th>
                    <th>الإجراءات</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $diseases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disease): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($disease->id); ?></td>
                        <td><?php echo e($disease->name); ?></td>
                        <td><?php echo e($disease->category->name ?? 'غير مصنف'); ?></td>
                        <td><?php echo e(Str::limit($disease->description, 50)); ?></td>
                        <td><?php echo e($disease->articles()->count()); ?></td>
                        <td><?php echo e($disease->tests()->count()); ?></td>
                        <td><?php echo e($disease->created_at->format('Y-m-d')); ?></td>
                       <td><span class="badge <?php echo e($disease->status); ?>">
                       <?php echo e($disease->status == 'active' ? 'نشط' : 'غير نشط'); ?>

                       </span></td>

                        <td>
                            <a href="<?php echo e(route('admin.diseases.edit', $disease->id)); ?>" class="btn btn-outline">
                                <i class="fas fa-edit"></i>
                            </a>
                             <a href="<?php echo e(route('admin.diseases.show',$disease->id)); ?>" class="btn btn-outline">
                          <i class="fas fa-eye"></i></a>
                            <form action="<?php echo e(route('admin.diseases.destroy', $disease->id)); ?>" method="POST" style="display:inline-block">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger" onclick="return confirm('هل أنت متأكد من الحذف؟')">
                                    <i class="fas fa-trash-alt"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="7" style="text-align:center">لا توجد بيانات أمراض حالياً</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- ترقيم الصفحات -->
    <div class="pagination-container">
        <?php echo e($diseases->links('pagination::bootstrap-5')); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
    function updateDateTime() {
        const now = new Date();

        const days = ["الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت"];

        document.getElementById("current-day").innerText = days[now.getDay()] + " -";
        document.getElementById("current-date").innerText =
            now.getFullYear() + "/" + (now.getMonth() + 1).toString().padStart(2, '0') +
            "/" + now.getDate().toString().padStart(2, '0') + " -";

        document.getElementById("current-time").innerText =
            now.getHours().toString().padStart(2, '0') + ":" +
            now.getMinutes().toString().padStart(2, '0') + ":" +
            now.getSeconds().toString().padStart(2, '0');
    }

    setInterval(updateDateTime, 1000);
    updateDateTime();
</script>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('styles'); ?>
<style>
    .admin-container {
        padding: 30px;
        background: #fff;
        border-radius: 10px;
        box-shadow: 0 5px 15px rgba(0,0,0,.05);
    }

    .page-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 25px;
    }

    .page-header h2 {
        color: #2a7f62;
        font-size: 1.5rem;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .alert {
        padding: 10px 15px;
        border-radius: 6px;
        margin-bottom: 15px;
        font-size: 0.95rem;
    }
    .alert-success { background: #d4edda; color: #155724; }
    .alert-danger { background: #f8d7da; color: #721c24; }

    .table-container {
        overflow-x: auto;
    }

    .admin-table {
        width: 100%;
        border-collapse: collapse;
        min-width: 800px;
    }
    .admin-table th, .admin-table td {
        padding: 12px 15px;
        border-bottom: 1px solid #eee;
        text-align: center;
    }
    .admin-table th {
        background-color: #2a7f62;
        color: #fff;
        font-weight: 600;
    }

    .btn {
        display: inline-block;
        padding: 6px 12px;
        border-radius: 5px;
        font-size: 0.9rem;
        cursor: pointer;
        border: none;
        transition: 0.3s;
        text-decoration: none;
    }

    .btn-primary {
        background: #2a7f62;
        color: #fff;
    }
    .btn-primary:hover {
        background: #1e5f4a;
    }

    .btn-outline {
        background: transparent;
        color: #2a7f62;
        border: 1px solid #2a7f62;
    }
    .btn-outline:hover {
        background: #2a7f62;
        color: #fff;
    }

    .btn-danger {
        background: #dc3545;
        color: #fff;
    }
    .btn-danger:hover {
        background: #b52a35;
    }

    .pagination-container {
        margin-top: 20px;
        text-align: center;
    }

/* التاريخ والوقت */
    .date-time-box {
        background: white;
        padding: 12px 18px;
        border-radius: 8px;
        display: inline-flex;
        gap: 15px;
        color: #2a7f62;
        font-weight: 600;
        font-size: 1rem;
        box-shadow: 0 5px 15px rgba(0, 0, 0, .05);
        border-right: 4px solid #2a7f62;
    }
    .table-container {
    margin-bottom: 40px;
}
.badge {
    padding: 4px 10px;
    border-radius: 4px;
    color: #fff;
}

.badge.active { background: #2a7f62; }
.badge.inactive { background: #dc3545; }

.card form {
    display: flex;
    flex-wrap: wrap;
    gap: 15px; /* مسافة واضحة بين الحقول والأزرار */
    margin-bottom: 15px;
}

.card form input.form-control {
    flex: 1 1 300px; /* يأخذ أكبر مساحة ممكنة ويكون مناسب للشاشات الكبيرة */
    padding: 14px 18px;
    font-size: 1.2rem; /* حجم الخط أكبر */
    border-radius: 8px;
}

.card form .btn {
    padding: 14px 22px;
    font-size: 1.2rem;
    border-radius: 8px;
}
.form-control{

    flex: 1 1 300px; /* يأخذ أكبر مساحة ممكنة ويكون مناسب للشاشات الكبيرة */
    padding: 14px 18px;
    font-size: 1.2rem; /* حجم الخط أكبر */
    border-radius: 8px;

}
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PIXEL-PC\Desktop\sehatimain\sehati-main\resources\views/admin/diseases/index.blade.php ENDPATH**/ ?>