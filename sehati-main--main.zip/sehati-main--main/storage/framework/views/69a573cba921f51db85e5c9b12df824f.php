<?php $__env->startSection('title','الاستشارات الجديدة'); ?>

<?php $__env->startSection('content'); ?>
<h3>🩺 الاستشارات الجديدة</h3>

<?php $__empty_1 = true; $__currentLoopData = $consultations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="card">
        <strong><?php echo e($c->title); ?></strong>
        <p><?php echo e(Str::limit($c->message,80)); ?></p>

        <a href="<?php echo e(route('doctor.consultations.show',$c->id)); ?>">
            الرد
        </a>
        <?php if($c->disease): ?>
    <span>🦠 <?php echo e($c->disease->name); ?></span>
<?php endif; ?>

<?php if($c->appointment): ?>
    <span>📅 <?php echo e($c->appointment->date->format('d/m')); ?></span>
<?php endif; ?>
  <a href="<?php echo e(route('doctor.consultations.show',$c->id)); ?>" class="btn-primary">
            الرد
        </a>
    </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p>لا توجد استشارات</p>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('doctor.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PIXEL-PC\Desktop\sehatimain\sehati-main\resources\views/doctor/consultations/index.blade.php ENDPATH**/ ?>