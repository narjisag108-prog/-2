<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>إنشاء حساب</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php if($errors->any()): ?>
<script>
Swal.fire({icon:'error',title:'خطأ!',text:'<?php echo e($errors->first()); ?>'});
</script>
<?php endif; ?>

<style>
/* ====== الخلفية ====== */
body {
    font-family: "Tajawal", sans-serif;
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    background:
        linear-gradient(rgba(0,0,0,0.55), rgba(0,0,0,0.55)),
        url('<?php echo e(asset("storage/sahatek.jpg")); ?>') center/cover no-repeat;
}

/* ====== كرت شفاف مصغّر ====== */
.card-register {
    width: 380px; /* أصغر */
    background: rgba(255,255,255,0.15);
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    border-radius: 24px;
    padding: 30px 26px;
    box-shadow: 0 25px 60px rgba(0,0,0,0.45);
    color: #ffffff;
    animation: fadeIn .8s ease;
}

/* ====== عنوان ====== */
h3 {
    color: #ffffff;
    font-weight: 800;
    margin-bottom: 22px;
    text-align: center;
    font-size: 22px;
}

/* ====== labels ====== */
label {
    color: #ffffff;
    font-size: 14px;
}

/* ====== الحقول ====== */
.input-group-text {
    background: rgba(255,255,255,0.25);
    border: none;
    color: #ffffff;
    border-radius: 12px 0 0 12px;
}

.form-control {
    border: 1px solid rgba(255,255,255,0.35);
    border-radius: 0 12px 12px 0;
    height: 44px;
    font-size: 14px;
    background: rgba(255,255,255,0.2);
    color: #ffffff;
}

.form-control:focus {
    border-color: #ffffff;
    box-shadow: 0 0 0 2px rgba(255,255,255,0.25);
    background: rgba(255,255,255,0.25);
    color: #ffffff;
}

/* ====== زر ====== */
.btn-register {
    width: 100%;
    background: rgba(255,255,255,0.25); /* زر زجاجي */
    color: #ffffff;                     /* النص أبيض */
    border: 1px solid rgba(255,255,255,0.6);
    border-radius: 14px;
    padding: 12px;
    margin-top: 14px;
    font-size: 16px;
    font-weight: 700;
    backdrop-filter: blur(4px);
}

.btn-register:hover {
    background: rgba(255,255,255,0.35);
    color: #ffffff;
}

/* ====== روابط ====== */
.other-link {
    text-align: center;
    margin-top: 14px;
    font-size: 14px;
}

.other-link a {
    color: #ffffff;
    text-decoration: underline;
}

/* ====== Animation ====== */
@keyframes fadeIn {
    from { opacity:0; transform:translateY(20px); }
    to { opacity:1; transform:translateY(0); }
}
</style>
</head>

<body>

<div class="card-register">

    <h3><i class="fas fa-user-plus"></i> إنشاء حساب</h3>

    <form action="<?php echo e(route('register.post')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <!-- الاسم الأول + الأخير -->
        <div class="row g-2">
            <div class="col-6">
                <label>الاسم الأول</label>
                <div class="input-group mb-2">
                    <span class="input-group-text"><i class="fas fa-user"></i></span>
                    <input type="text" name="first_name" class="form-control" required>
                </div>
            </div>

            <div class="col-6">
                <label>الاسم الأخير</label>
                <div class="input-group mb-2">
                    <span class="input-group-text"><i class="fas fa-user-tag"></i></span>
                    <input type="text" name="last_name" class="form-control" required>
                </div>
            </div>
        </div>

        <!-- الإيميل -->
        <label>البريد الإلكتروني</label>
        <div class="input-group mb-2">
            <span class="input-group-text"><i class="fas fa-envelope"></i></span>
            <input type="email" name="email" class="form-control" required>
        </div>

        <!-- كلمة المرور + تأكيد -->
        <div class="row g-2">
            <div class="col-6">
                <label>كلمة المرور</label>
                <div class="input-group mb-2">
                    <span class="input-group-text"><i class="fas fa-lock"></i></span>
                    <input type="password" name="password" class="form-control" required>
                </div>
            </div>

            <div class="col-6">
                <label>تأكيدها</label>
                <div class="input-group mb-3">
                    <span class="input-group-text"><i class="fas fa-lock"></i></span>
                    <input type="password" name="password_confirmation" class="form-control" required>
                </div>
            </div>
        </div>

        <button class="btn-register">تسجيل</button>

        <div class="other-link">
            لديك حساب؟
            <a href="<?php echo e(route('login')); ?>">تسجيل الدخول</a>
        </div>

    </form>
</div>

</body>
</html>
<?php /**PATH C:\Users\PIXEL-PC\Desktop\sehatimain\sehati-main\resources\views/register.blade.php ENDPATH**/ ?>