<?php $__env->startSection('title','سكر الدم'); ?>

<?php $__env->startPush('styles'); ?>
<style>
/* ===== PAGE ===== */
.page-title{
    font-size:1.9rem;
    font-weight:800;
    color:var(--primary);
    margin-bottom:25px;
    display:flex;
    align-items:center;
    gap:10px;
}

/* ===== LAYOUT ===== */
.readings-container{
    display:grid;
    grid-template-columns:1.4fr .6fr;
    gap:25px;
}
@media(max-width:900px){
    .readings-container{grid-template-columns:1fr;}
}

/* ===== CARD ===== */
.card{
    background:#fff;
    padding:22px;
    border-radius:18px;
    box-shadow:0 10px 30px rgba(0,0,0,.06);
    transition:.3s ease;
}
.card:hover{
    transform:translateY(-4px);
    box-shadow:0 16px 38px rgba(0,0,0,.12);
}

/* ===== READINGS ===== */
.reading-item{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:12px 0;
    border-bottom:1px solid #eef2f1;
}
.reading-item:last-child{border-bottom:none}

.reading-value{
    font-size:1.3rem;
    font-weight:900;
    color:#2a7f62;
}
.date{
    font-size:.85rem;
    color:#8a9a97;
}

/* ===== FORM ===== */
.card h4{
    font-weight:800;
    color:#2a7f62;
    margin-bottom:15px;
}
label{
    font-weight:700;
    color:#2a7f62;
    margin-top:12px;
    display:block;
}
input{
    width:100%;
    padding:12px 14px;
    border-radius:12px;
    border:1.8px solid #e1ece8;
    margin-top:6px;
}
input:focus{
    outline:none;
    border-color:#2a7f62;
    box-shadow:0 0 0 3px rgba(42,127,98,.12);
}

/* ===== BUTTON ===== */
.btn-primary{
    background:#2a7f62;
    border:none;
    padding:12px;
    border-radius:14px;
    font-weight:800;
    width:100%;
}
.btn-primary:hover{
    background:#246b54;
}

/* ===== STATS ===== */
.stats{
    margin-top:25px;
    background:#f8fbfa;
    border-radius:14px;
    padding:16px;
}
.stat-label{
    font-size:.9rem;
    color:#6c8b84;
}
.stat-value{
    font-size:1.8rem;
    font-weight:900;
    color:#2a7f62;
}
</style>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>

<div class="page-title">
    <i class="fas fa-syringe"></i> قياس سكر الدم
</div>

<div class="readings-container">

    
    <div class="card">
        <canvas id="sugarChart" height="140"></canvas>

        <h4 style="margin-top:20px">آخر القراءات</h4>

        <?php $__empty_1 = true; $__currentLoopData = $readings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="reading-item">
                <span class="reading-value"><?php echo e($r->value); ?></span>
                <span class="date"><?php echo e($r->created_at->diffForHumans()); ?></span>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p style="color:#888">لا توجد بيانات بعد</p>
        <?php endif; ?>
    </div>

    
    <div class="card">
        <h4>➕ إضافة قراءة جديدة</h4>

        <form action="<?php echo e(route('readings.sugar.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <label>قيمة السكر</label>
            <input type="number" name="value" placeholder="مثال: 110" required>

            <label>ملاحظة</label>
            <input type="text" name="note" placeholder="بعد الأكل / صائم">

            <button type="submit" class="btn-primary" style="margin-top:18px">
                حفظ القراءة
            </button>
        </form>

        <div class="stats">
            <div class="stat-label">آخر قراءة</div>
            <div class="stat-value"><?php echo e($latest?->value ?? '-'); ?></div>

            <div class="stat-label" style="margin-top:12px">متوسط القراءات</div>
            <div class="stat-value"><?php echo e($sugarAvg?->value ?? '-'); ?></div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
new Chart(document.getElementById('sugarChart'), {
    type:'line',
    data:{
        labels:<?php echo json_encode($chartDates ?? []); ?>,
        datasets:[{
            label:'سكر الدم',
            data:<?php echo json_encode($chartValues ?? []); ?>,
            borderWidth:3,
            tension:.35
        }]
    },
    options:{
        responsive:true,
        plugins:{legend:{position:'bottom'}}
    }
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PIXEL-PC\Desktop\sehatimain\sehati-main\resources\views/readings/sugar.blade.php ENDPATH**/ ?>