<?php $__env->startSection('content'); ?>

<section class="disease-header">
    <h1><?php echo e($disease->name); ?></h1>
</section>

<section class="disease-content">

    
    <div class="container content-container">
        <?php echo $disease->content; ?>

    </div>

    
    <div class="sidebar-widget emergency-box">

        <?php if($disease->symptoms): ?>
            <h2>الأعراض</h2>
            <?php echo $disease->symptoms; ?>

        <?php endif; ?>

        <?php if($disease->causes): ?>
            <h2>الأسباب</h2>
            <?php echo $disease->causes; ?>

        <?php endif; ?>

        <?php if($disease->treatment): ?>
            <h2>العلاج</h2>
            <?php echo $disease->treatment; ?>

        <?php endif; ?>

        <?php if($disease->prevention): ?>
            <h2>الوقاية</h2>
            <?php echo $disease->prevention; ?>

        <?php endif; ?>

        <p><strong>اتصل بالطوارئ فورًا: 911</strong></p>
    </div>

    
    <?php if($disease->slug === 'diabetes'): ?>
        <div class="sidebar-widget">
            <h3>اختبار خطر المرض</h3>
            <a href="<?php echo e(route('assessment.show')); ?>" class="btn btn-primary" style="width:100%">
                ابدأ الاختبار
            </a>
        </div>
    <?php endif; ?>

</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PIXEL-PC\Desktop\sehatimain\sehati-main\resources\views/diseases/show.blade.php ENDPATH**/ ?>