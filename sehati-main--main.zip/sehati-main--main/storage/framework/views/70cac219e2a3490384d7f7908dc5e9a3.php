<?php $__env->startSection('title','لوحة التحكم'); ?>

<?php $__env->startPush('styles'); ?>
<style>
/* ================== GENERAL ================== */
.dashboard{
    display:grid;
    gap:25px;
}

.welcome-card{
    background:#fff;
    border-radius:16px;
    padding:24px 30px;
    box-shadow:0 8px 25px rgba(0,0,0,.06);
}
.welcome-card h2{
    color:#2a7f62;
    font-weight:800;
    margin-bottom:6px;
}
.welcome-card p{
    color:#7a8f8a;
    font-size:14px;
}

/* ================== GRID ================== */
.dashboard-grid{
    display:grid;
    grid-template-columns:repeat(3,1fr);
    gap:25px;
}
@media(max-width:1100px){
    .dashboard-grid{grid-template-columns:1fr}
}

/* ================== CARD ================== */
.card{
    background:#fff;
    border-radius:18px;
    padding:22px;
    box-shadow:0 10px 30px rgba(0,0,0,.06);
    position:relative;
}
.card-title{
    font-weight:800;
    color:#2a7f62;
    margin-bottom:15px;
    display:flex;
    justify-content:space-between;
    align-items:center;
}
.card-icon{
    width:42px;
    height:42px;
    border-radius:12px;
    display:flex;
    align-items:center;
    justify-content:center;
    color:#fff;
    font-size:18px;
}

/* ================== APPOINTMENTS ================== */
.appointment{
    border-bottom:1px solid #eef2f1;
    padding:12px 0;
}
.appointment:last-child{border-bottom:none}
.appointment h5{
    font-size:14px;
    font-weight:700;
}
.appointment small{
    color:#8a9a97;
    font-size:12px;
}

/* ================== MEDICINES ================== */
.medicine{
    display:flex;
    justify-content:space-between;
    align-items:center;
    border-bottom:1px solid #eef2f1;
    padding:12px 0;
}
.medicine:last-child{border-bottom:none}
.badge{
    font-size:11px;
    padding:3px 10px;
    border-radius:20px;
    font-weight:700;
}
.badge.green{background:#dff5ec;color:#2a7f62}
.badge.yellow{background:#fff3cd;color:#856404}
.badge.red{background:#fde2e2;color:#c0392b}

/* ================== METRICS ================== */
.metrics{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:15px;
}
.metric{
    background:#f8fbfa;
    border-radius:14px;
    padding:16px;
    text-align:center;
}
.metric h4{
    font-size:13px;
    color:#6c8b84;
}
.metric span{
    font-size:22px;
    font-weight:900;
    display:block;
    margin-top:6px;
}
.up{color:#2a7f62}
.down{color:#dc3545}

/* ================== BUTTONS ================== */
.card-actions{
    margin-top:15px;
    display:flex;
    gap:10px;
}
.card-actions a{
    flex:1;
    text-align:center;
    padding:8px;
    border-radius:8px;
    font-size:13px;
    font-weight:700;
    border:2px solid #2a7f62;
    color:#2a7f62;
}
.card-actions a.primary{
    background:#2a7f62;
    color:#fff;
}
/* ====== Activities (Latest) ====== */
.activities-box{
    background:#fff;
    border-radius:18px;
    box-shadow:0 10px 30px rgba(0,0,0,.06);
    margin-top:35px;
    overflow:hidden;
}

.activities-header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:18px 22px;
    border-bottom:1px solid #eef2f1;
}

.activities-header h4{
    font-weight:800;
    color:#2a7f62;
    margin:0;
}

.activities-header .icon{
    width:38px;
    height:38px;
    border-radius:12px;
    background:#2a7f62;
    color:#fff;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:16px;
}

.activity-row{
    display:flex;
    align-items:center;
    justify-content:space-between;
    padding:16px 22px;
    border-bottom:1px solid #eef2f1;
}

.activity-row:last-child{
    border-bottom:none;
}

.activity-info{
    display:flex;
    align-items:center;
    gap:14px;
}

.activity-icon{
    width:36px;
    height:36px;
    border-radius:10px;
    background:#e8f6f1;
    color:#2a7f62;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:15px;
}

.activity-title{
    font-weight:700;
    color:#2a7f62;
    font-size:14px;
}

.activity-time{
    font-size:12px;
    color:#8a9a97;
    display:flex;
    align-items:center;
    gap:5px;
}
/* ===== Card Animation ===== */
.card{
    background:#fff;
    border-radius:18px;
    padding:22px;
    box-shadow:0 10px 30px rgba(0,0,0,.06);
    position:relative;

    /* animation */
    transition:
        transform .35s ease,
        box-shadow .35s ease;
}

/* Hover movement */
.card:hover{
    transform: translateY(-10px) scale(1.01);
    box-shadow:0 20px 45px rgba(0,0,0,.15);
}
/* ===== Icon Animation ===== */
.card-icon i{
    transition: transform .25s ease;
}

/* Shake on hover */
.card:hover .card-icon i{
    animation: iconShake .5s ease;
}

@keyframes iconShake{
    0%   { transform: rotate(0deg) scale(1); }
    25%  { transform: rotate(-6deg) scale(1.05); }
    50%  { transform: rotate(6deg) scale(1.05); }
    75%  { transform: rotate(-4deg) scale(1.03); }
    100% { transform: rotate(0deg) scale(1); }
}


/* Fade-in on load */
.card{
    opacity:0;
    animation: cardFadeUp .6s ease forwards;
}

/* Delay for nice stagger effect */
.dashboard-grid .card:nth-child(1){animation-delay:.1s}
.dashboard-grid .card:nth-child(2){animation-delay:.25s}
.dashboard-grid .card:nth-child(3){animation-delay:.4s}

@keyframes cardFadeUp{
    from{
        opacity:0;
        transform:translateY(25px);
    }
    to{
        opacity:1;
        transform:translateY(0);
    }
}

</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

<div class="dashboard">

    
    <div class="welcome-card">
        <h2>مرحباً <?php echo e($user->name); ?> </h2>
        <p>إليك نظرة عامة على حالتك الصحية والأنشطة القادمة. نتمنى لك يوماً صحياً ومليئاً بالنشاط.</p>
    </div>

    
    <div class="dashboard-grid">
<div class="card">
            <div class="card-title">
                المؤشرات الصحية
                <div class="card-icon" style="background:#17a2b8"><i class="fas fa-heartbeat"></i></div>
            </div>

            <div class="metrics">
                <div class="metric">
                    <h4>السكر (صائم)</h4>
                    <span class="down"><?php echo e($latestSugar?->value ?? '-'); ?></span>
                </div>

                <div class="metric">
                    <h4>ضغط الدم</h4>
                    <span class="up">
                        <?php if($latestPressure): ?>
                            <?php echo e($latestPressure->value_upper); ?>/<?php echo e($latestPressure->value_lower); ?>

                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </span>
                </div>

                <div class="metric">
                    <h4>السكر التراكمي</h4>
                    <span class="up">6.2%</span>
                </div>

                <div class="metric">
                    <h4>الوزن</h4>
                    <span class="down">78</span>
                </div>
            </div>

            <div class="card-actions">
                <a href="<?php echo e(route('readings.dashboard')); ?>">عرض التفاصيل</a>
                <a href="<?php echo e(route('readings.sugar.index')); ?>" class="primary">إضافة قراءة</a>
            </div>
        </div>
        
        <div class="card">
            <div class="card-title">
                المواعيد القادمة
                <div class="card-icon" style="background:#2a7f62"><i class="fas fa-calendar"></i></div>
            </div>

            <?php $__empty_1 = true; $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="appointment">
                    <h5><?php echo e($a->title); ?></h5>
                    <small><?php echo e($a->date->format('d/m')); ?></small>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>لا توجد مواعيد</p>
            <?php endif; ?>

            <div class="card-actions">
                <a href="<?php echo e(route('appointments.index')); ?>">كل المواعيد</a>
                <a href="<?php echo e(route('appointments.create')); ?>" class="primary">حجز موعد</a>
            </div>
        </div>

        
        <div class="card">
            <div class="card-title">
                الأدوية
                <div class="card-icon" style="background:#28a745"><i class="fas fa-pills"></i></div>
            </div>

            <?php $__empty_1 = true; $__currentLoopData = $medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="medicine">
                    <div>
                        <strong><?php echo e($m->name); ?></strong><br>
                        <small><?php echo e($m->dose); ?></small>
                    </div>
                    <span class="badge green">منتظم</span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>لا توجد أدوية</p>
            <?php endif; ?>

            <div class="card-actions">
                <a href="<?php echo e(route('medicines.index')); ?>">كل الأدوية</a>
                <a href="<?php echo e(route('medicines.create')); ?>" class="primary">إضافة دواء</a>
            </div>
        </div>




<div class="activities-box">

    <div class="activities-header">
        <h4>🕒 آخر الأنشطة</h4>
        <div class="icon">
            <i class="fas fa-history"></i>
        </div>
    </div>

    <?php $__empty_1 = true; $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="activity-row">
        <div class="activity-info">
            <div class="activity-icon">
                <i class="fas fa-check"></i>
            </div>
            <div class="activity-title">

            </div>
        </div>

        <div class="activity-time">
            <i class="far fa-clock"></i>

        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="activity-row">
        <div class="activity-title">لا توجد أنشطة</div>
    </div>
<?php endif; ?>


    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\PIXEL-PC\Desktop\sehatimain\sehati-main\resources\views/user/dashboard.blade.php ENDPATH**/ ?>