<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?php echo $__env->yieldContent('title','صحتك أولاً'); ?></title>

<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
:root{--primary:#2a7f62;--accent:#ff7e5f;--dark:#343a40;--text:#333}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Tajawal',sans-serif;background:#f5f7f6;color:var(--text);line-height:1.7}
.container{width:90%;max-width:1200px;margin:0 auto}

/* ==== Navbar ==== */
header{
    background:#fff;
    box-shadow:0 2px 10px rgba(0,0,0,.06);
    position:sticky;top:0;z-index:100;
}
.header-container{
    display:flex;justify-content:space-between;align-items:center;
    padding:14px 0;
}
.logo{display:flex;align-items:center;gap:10px}
.logo img{height:48px}
.logo h1{color:var(--primary);font-size:1.5rem;font-weight:800}

nav ul{display:flex;gap:22px;list-style:none}
nav a{color:var(--primary);font-weight:600}

/* User Name */
.user-name{
    background:var(--primary);
    padding:8px 18px;
    border-radius:8px;
    color:#fff;
    font-weight:bold;
}

/* Footer */
footer{background:var(--dark);padding:40px 0;color:#fff;margin-top:40px}
footer a{color:#fff;opacity:.9}
.footer-bottom{text-align:center;margin-top:14px;color:#ccc;font-size:.9rem}
</style>

<?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body>

<header>
    <div class="container header-container">
        <div class="logo">
          <img src="<?php echo e(asset('storage/logo.png')); ?>" alt="logo">

            <h1>صحتك أولاً</h1>
        </div>

        <nav>
            <ul>
                <li><a href="<?php echo e(route('home')); ?>">الرئيسية</a></li>
                <li><a href="#diseases">الأمراض</a></li>
                <li><a href="#features">الخدمات</a></li>
                <li><a href="/articles">المقالات</a></li>
                <li><a href="<?php echo e(route('contact.show')); ?>">اتصل بنا</a></li>

            </ul>
        </nav>
<li>
    <form action="<?php echo e(route('logout')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button style="background:none;border:none;color:red;font-weight:bold;cursor:pointer">
            تسجيل الخروج
        </button>
    </form>
</li>

       <div class="user-name" style="display:flex;align-items:center;gap:10px;">
  <?php if(auth()->check()): ?>
    مرحباً، <?php echo e(auth()->user()->name); ?>

<?php else: ?>
    مرحبا زائر
<?php endif; ?>


    <form action="<?php echo e(route('logout')); ?>" method="POST" style="display:inline;">
        <?php echo csrf_field(); ?>
        <button style="
            background:#c0392b;
            border:none;
            padding:6px 12px;
            border-radius:6px;
            cursor:pointer;
            color:#fff;
            font-size:.85rem;
        ">تسجيل الخروج</button>
    </form>
</div>

    </div>
</header>


<main class="container" style="padding:30px 0;">
    <?php echo $__env->yieldContent('content'); ?>
</main>


<footer>
    <div class="container">

        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:25px">
            <div>
                <h3>صحتك أولاً</h3>
                <p>منصة تثقيفية وذكية لمتابعة صحتك اليومية.</p>
            </div>

            <div>
                <h3>روابط سريعة</h3>
                <ul style="list-style:none;padding:0">
                    <li><a href="<?php echo e(route('readings.dashboard')); ?>">لوحة التحكم</a></li>
                    <li><a href="<?php echo e(route('medicines.index')); ?>">الأدوية</a></li>
                    <li><a href="<?php echo e(route('appointments.index')); ?>">المواعيد</a></li>
                </ul>
            </div>

            <div>
                <h3>الدعم</h3>
                <p><i class="fas fa-envelope"></i> healthfirst@gmail.com</p>
            </div>
        </div>

        <div class="footer-bottom">
            &copy; <?php echo e(date('Y')); ?> صحتك أولاً. جميع الحقوق محفوظة.
        </div>
    </div>
</footer>

<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Users\PIXEL-PC\Desktop\sehatimain\sehati-main\resources\views/layouts/me.blade.php ENDPATH**/ ?>