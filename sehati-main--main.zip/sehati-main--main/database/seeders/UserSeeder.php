<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\User;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        User::create([
            'first_name' => 'Admin',
            'last_name'  => 'User',
            'email'      => 'admin@example.com',
            'phone'      => '0912345678',
            'password'   => bcrypt('password'),
        ]);
        User::create([
            'first_name' => 'Dr.',
            'last_name'  => 'Smith',
            'email'      => 'doctor@example.com',
            'phone'      => '0998765432',
            'password'   => bcrypt('password'),
        ]);
        User::create([
            'first_name' => 'User.',
            'last_name'  => 'User',
            'email'      => 'User@example.com',
            'phone'      => '0998765442',
            'password'   => bcrypt('password'),

        ]);

    }

}
