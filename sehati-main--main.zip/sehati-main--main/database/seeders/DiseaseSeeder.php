<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Disease;

class DiseaseSeeder extends Seeder
{
    public function run(): void
    {
        Disease::updateOrCreate(
    ['slug' => 'diabetes'],
    [
        'name' => 'مرض السكري',
        'slug' => 'diabetes',

        'content' => '
            <h2>ما هو مرض السكري؟</h2>
            <p>مرض السكري هو اضطراب مزمن يؤثر على كيفية استخدام الجسم للجلوكوز...</p>
        ',

        'symptoms' => '
            <ul>
                <li>العطش الشديد</li>
                <li>كثرة التبول</li>
                <li>فقدان الوزن</li>
                <li>التعب المتواصل</li>
            </ul>
        ',

        'causes' => '
            <p>خلل في إنتاج الأنسولين أو استخدامه.</p>
        ',

        'treatment' => '
            <p>تناول الأدوية أو الأنسولين حسب نوع السكري.</p>
        ',

        'prevention' => '
            <p>ممارسة الرياضة والتغذية الصحية.</p>
        ',

        'image' => 'diabetes.png',
        'status' => 'active',
    ]
);

Disease::updateOrCreate(
    ['slug' => 'blood-pressure'],
    [
        'name' => 'ارتفاع ضغط الدم',
        'slug' => 'blood-pressure',

        'content' => '
            <h2>ما هو ارتفاع ضغط الدم؟</h2>
            <p>ارتفاع ضغط الدم هو زيادة مستمرة في قوة دفع الدم على جدران الشرايين...</p>
        ',

        'symptoms' => '
            <ul>
                <li>الصداع</li>
                <li>ضيق التنفس</li>
                <li>دوخة وتشوش الرؤية</li>
            </ul>
        ',

        'causes' => '
            <p>العوامل الوراثية ونمط الحياة غير الصحي.</p>
        ',

        'treatment' => '
            <p>أدوية خفض الضغط واتباع نظام صحي.</p>
        ',

        'prevention' => '
            <p>تقليل الملح، الرياضة، وتجنب التوتر.</p>
        ',

        'image' => 'blood.jpeg',
        'status' => 'active',
    ]
);


        Disease::updateOrCreate(
            ['slug' => 'heart-disease'],
            [
                'name' => 'أمراض القلب',
                'slug' => 'heart-disease',
                'content' => '
                    <h2>ما هي أمراض القلب؟</h2>
                    <p>هي مجموعة من الاضطرابات التي تؤثر على القلب والأوعية الدموية...</p>
',
                 'symptoms' => '
                    <ul>
                        <li>ألم في الصدر</li>
                        <li>سرعة ضربات القلب</li>
                        <li>الإرهاق</li>
                    </ul>
 ',

        'causes' => '
                    <p>تراكم الدهون في الشرايين...</p>

                    ',

        'treatment' => '
                    <p>الأدوية والتدخلات الجراحية...</p>

                 ',

        'prevention' => '
                    <p>نظام غذائي صحي والابتعاد عن التدخين</p>
                ',
                'image' => 'heart.jpeg',
                'status' => 'active',
            ]
        );
    }
}
