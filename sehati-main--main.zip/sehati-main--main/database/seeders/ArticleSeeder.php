<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Str;
use App\Models\Article;

class ArticleSeeder extends Seeder
{
    public function run(): void
    {
        $articles = [
            [
                'title' => 'أهمية شرب الماء يومياً',
                'content' => 'الماء ضروري للحفاظ على صحة الجسم، يساعد في الهضم وتنظيم حرارة الجسم، ويقي من الجفاف.',
                'image' => 'images/water.jpg',
                'disease_id' => null,
                'author_name' => 'د. محمد صالح',
                'status' => 'published',
            ],
            [
                'title' => 'الفوائد الصحية للخضروات',
                'content' => 'الخضروات غنية بالفيتامينات والمعادن، وتساعد في تعزيز المناعة والحفاظ على صحة القلب.',
                'image' => 'images/vegetables.jpg',
                'disease_id' => null,
                'author_name' => 'د. ليلى أحمد',
                'status' => 'published',
            ],
            [
                'title' => 'أهمية النوم الكافي للصحة',
                'content' => 'النوم الكافي يحافظ على نشاط الدماغ ويقوي جهاز المناعة ويقلل من التوتر والضغط النفسي.',
                'image' => 'images/sleep.jpg',
                'disease_id' => null,
                'author_name' => 'د. علي حسين',
                'status' => 'draft',
            ],
        ];

        foreach ($articles as $article) {
            Article::create($article);
        }
    }
}
