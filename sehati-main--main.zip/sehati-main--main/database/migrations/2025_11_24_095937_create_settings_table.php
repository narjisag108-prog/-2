<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;


return new class extends Migration {
    public function up(): void
    {
        Schema::create('settings', function (Blueprint $table) {
            $table->id();

            // Site / system
            $table->string('site_name')->nullable();
            $table->string('site_logo')->nullable(); // path on storage
            $table->boolean('maintenance_mode')->default(false);
            $table->text('analytics_code')->nullable();

            // Admin/profile (single row)
            $table->string('admin_first_name')->nullable();
            $table->string('admin_last_name')->nullable();
            $table->string('admin_email')->nullable();
            $table->string('admin_phone')->nullable();
            $table->text('admin_bio')->nullable();
            $table->string('admin_avatar')->nullable();

            // Notifications toggles
            $table->boolean('notify_email_enabled')->default(true);
            $table->boolean('notify_on_new_user')->default(true);
            $table->boolean('notify_on_new_consultation')->default(true);
            $table->boolean('notify_system_updates')->default(true);

            // Push
            $table->boolean('push_notify_enabled')->default(false);
            $table->boolean('push_notify_sound')->default(false);

            $table->timestamps();
        });

        // Insert single defaults row
        DB::table('settings')->insert([
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }

    public function down(): void
    {
        Schema::dropIfExists('settings');
    }
};
