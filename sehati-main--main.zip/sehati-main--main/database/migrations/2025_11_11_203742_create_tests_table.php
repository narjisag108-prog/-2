<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('tests', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->text('description')->nullable();
            $table->unsignedBigInteger('disease_id');
            $table->enum('status',['active','inactive'])->default('active');
            $table->decimal('rating', 3, 1)->nullable()->default(0);
            $table->timestamps();
        });
    }

    public function down(): void {
        Schema::dropIfExists('tests');
    }
};
