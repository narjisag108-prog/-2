<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('assessments', function (Blueprint $table) {
            $table->unsignedTinyInteger('age')->after('doctor_id');
            $table->string('gender')->after('age');
            $table->unsignedTinyInteger('family_history')->after('gender');
            $table->unsignedTinyInteger('bmi')->after('family_history');
            $table->unsignedTinyInteger('activity')->after('bmi');
            $table->unsignedTinyInteger('blood_pressure')->after('activity');
            $table->unsignedTinyInteger('score')->after('blood_pressure');
            $table->string('risk_level')->after('score');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('assessments', function (Blueprint $table) {
            //
        });
    }
};
