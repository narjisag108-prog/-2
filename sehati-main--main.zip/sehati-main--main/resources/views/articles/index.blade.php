@extends('layouts.me')

@section('title', 'المقالات')

@push('styles')
<style>
.articles-container{
    max-width:1200px;
    margin:70px auto;
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(280px,1fr));
    gap:25px;
}

.article-card{
    background:#fff;
    border-radius:18px;
    box-shadow:0 12px 30px rgba(0,0,0,.08);
    overflow:hidden;
    display:flex;
    flex-direction:column;
    transition:.35s ease;
}

.article-card:hover{
    transform:translateY(-6px);
    box-shadow:0 20px 40px rgba(0,0,0,.14);
}

.article-card img{
    width:100%;
    height:180px;
    object-fit:cover;
}

.article-content{
    padding:22px;
    flex:1;
    display:flex;
    flex-direction:column;
}

.article-content h3{
    font-size:1.25rem;
    margin-bottom:10px;
    color:#2a7f62;
    font-weight:800;
}

.article-meta{
    font-size:.85rem;
    color:#8a9a97;
    margin-bottom:12px;
    display:flex;
    gap:10px;
    flex-wrap:wrap;
}

.article-excerpt{
    flex:1;
    color:#555;
    line-height:1.7;
    margin-bottom:16px;
}

.read-more{
    align-self:flex-start;
    padding:10px 18px;
    background:#2a7f62;
    color:#fff;
    border-radius:12px;
    font-weight:700;
    transition:.3s;
}

.read-more:hover{
    background:#246b54;
}

.pagination-box{
    max-width:1200px;
    margin:30px auto;
}
</style>
@endpush

@section('content')

<div class="articles-container">
@forelse($articles as $article)
    <div class="article-card">
        <img src="{{ $article->image
            ? asset('storage/'.$article->image)
            : 'https://via.placeholder.com/400x180?text=Article' }}">

        <div class="article-content">
            <h3>{{ $article->title }}</h3>

            <div class="article-meta">
                <span>✍️ {{ $article->author_name }}</span>
                @if($article->disease)
                    <span>🩺 {{ $article->disease->name }}</span>
                @endif
                <span>📅 {{ $article->created_at->format('d M Y') }}</span>
            </div>

            <p class="article-excerpt">
                {{ Str::limit(strip_tags($article->content),120) }}
            </p>

            <a href="{{ route('articles.show',$article->id) }}" class="read-more">
                اقرأ المزيد
            </a>
        </div>
    </div>
@empty
    <p>لا توجد مقالات حالياً.</p>
@endforelse
</div>

<div class="pagination-box">
    {{ $articles->links() }}
</div>

@endsection
