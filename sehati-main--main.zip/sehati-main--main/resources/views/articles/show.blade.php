@extends('layouts.me')

@section('title', $article->title)

@push('styles')
<style>
.article-single{
    max-width:850px;
    margin:70px auto;
    background:#fff;
    padding:40px 35px;
    border-radius:20px;
    box-shadow:0 14px 35px rgba(0,0,0,.08);
}

.article-single h1{
    color:#2a7f62;
    margin-bottom:18px;
    font-weight:900;
}

.article-meta{
    font-size:.9rem;
    color:#8a9a97;
    margin-bottom:25px;
    display:flex;
    gap:12px;
    flex-wrap:wrap;
}

.article-body{
    line-height:1.9;
    color:#555;
    font-size:1.05rem;
}

.back-btn{
    margin-top:35px;
    display:inline-block;
    padding:12px 22px;
    background:#2a7f62;
    color:#fff;
    border-radius:14px;
    font-weight:700;
    transition:.3s;
}

.back-btn:hover{
    background:#246b54;
}
</style>
@endpush

@section('content')

<div class="article-single">

    <h1>{{ $article->title }}</h1>

    <div class="article-meta">
        <span>✍️ {{ $article->author_name }}</span>
        @if($article->disease)
            <span>🩺 {{ $article->disease->name }}</span>
        @endif
        <span>📅 {{ $article->created_at->format('d M Y') }}</span>
    </div>

    <div class="article-body">
        {!! nl2br(e($article->content)) !!}
    </div>

    <a href="{{ route('articles.index') }}" class="back-btn">
        ⬅️ العودة للمقالات
    </a>

</div>

@endsection
