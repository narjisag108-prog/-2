@extends('layouts.me')

@section('title', 'اتصل بنا')

@push('styles')
<style>
/* ================== VARIABLES ================== */
:root{
    --primary:#2a7f62;
    --primary-hover:#246b54;
    --text:#333;
    --border:#e2ece8;
    --radius:18px;
    --shadow:0 12px 30px rgba(0,0,0,.08);
}

/* ================== CONTACT CARD ================== */
.contact-section{
    max-width:520px;
    margin:80px auto;
    background:#fff;
    padding:40px 32px;
    border-radius:var(--radius);
    box-shadow:var(--shadow);
    text-align:center;
    animation:fadeUp .4s ease;
}

.contact-section h2{
    font-size:2rem;
    font-weight:900;
    color:var(--primary);
    margin-bottom:30px;
    position:relative;
}

.contact-section h2::after{
    content:'';
    width:60px;
    height:4px;
    background:var(--primary);
    display:block;
    margin:12px auto 0;
    border-radius:10px;
}

/* ================== FORM ================== */
.contact-form{
    display:flex;
    flex-direction:column;
    gap:16px;
}

.contact-form input,
.contact-form textarea{
    width:100%;
    padding:14px 16px;
    border-radius:12px;
    border:1.8px solid var(--border);
    font-size:1rem;
    transition:.3s;
    font-family:'Tajawal',sans-serif;
}

.contact-form input:focus,
.contact-form textarea:focus{
    outline:none;
    border-color:var(--primary);
    box-shadow:0 0 0 4px rgba(42,127,98,.15);
}

.contact-form textarea{
    resize:vertical;
    min-height:120px;
}

/* ================== BUTTON ================== */
.contact-form button{
    background:var(--primary);
    color:#fff;
    font-size:1.05rem;
    font-weight:800;
    padding:14px;
    border:none;
    border-radius:14px;
    cursor:pointer;
    transition:.3s ease;
    margin-top:8px;
}

.contact-form button:hover{
    background:var(--primary-hover);
    transform:translateY(-2px);
    box-shadow:0 6px 18px rgba(42,127,98,.35);
}

/* ================== ALERT ================== */
.alert-success{
    margin-bottom:25px;
    padding:14px;
    border-radius:14px;
    background:#e6f6ef;
    color:#1f6a53;
    font-weight:700;
    border:1px solid #cfeee2;
}

/* ================== ANIMATION ================== */
@keyframes fadeUp{
    from{opacity:0;transform:translateY(20px)}
    to{opacity:1;transform:translateY(0)}
}

/* ================== RESPONSIVE ================== */
@media(max-width:600px){
    .contact-section{
        margin:40px 15px;
        padding:30px 22px;
    }
}
</style>
@endpush


@section('content')
<div class="contact-section">

    <h2>📬 اتصل بنا</h2>

    @if(session('success'))
        <div class="alert-success">
            {{ session('success') }}
        </div>
    @endif

    <form method="POST" action="{{ route('contact.send') }}" class="contact-form">
        @csrf

        <input type="text" name="name"
               placeholder="الاسم الكامل"
               value="{{ old('name') }}" required>

        <input type="email" name="email"
               placeholder="البريد الإلكتروني"
               value="{{ old('email') }}" required>

        <input type="text" name="subject"
               placeholder="الموضوع"
               value="{{ old('subject') }}" required>

        <textarea name="message"
                  placeholder="رسالتك"
                  required>{{ old('message') }}</textarea>

        <button type="submit">إرسال الرسالة</button>
    </form>

</div>
@endsection
