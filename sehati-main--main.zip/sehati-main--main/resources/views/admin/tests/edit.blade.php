@extends('admin.layout')

@section('title', 'تعديل اختبار')

@section('content')
<div class="admin-form">
    <h2><i class="fas fa-edit"></i> تعديل اختبار</h2>

    <form action="{{ route('admin.tests.update', $test) }}" method="POST">
    @csrf
    @method('PUT')


        <label>اسم الاختبار:</label>
        <input type="text" name="title" value="{{ old('title', $test->title) }}" required>

        <label>الوصف:</label>
        <textarea name="description" rows="4">{{ old('description', $test->description) }}</textarea>

        <label>مرتبط بمرض:</label>
        <select name="disease_id">
            <option value="">— بدون ارتباط —</option>
            @foreach($diseases as $d)
                <option value="{{ $d->id }}" @selected($test->disease_id == $d->id)>{{ $d->name }}</option>
            @endforeach
        </select>

        <button type="submit" class="btn btn-primary">تحديث</button>
        <a href="{{ route('admin.tests.index') }}" class="btn btn-outline">رجوع</a>
    </form>
</div>
@endsection
