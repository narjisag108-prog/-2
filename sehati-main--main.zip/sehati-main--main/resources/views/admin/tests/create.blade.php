@extends('admin.layout')
@section('title', 'إضافة اختبار جديد')
@section('content')

<div class="admin-form">
    <h2><i class="fas fa-vial"></i> إضافة اختبار جديد</h2>

    <form action="{{ route('admin.tests.store') }}" method="POST">
        @csrf

        <label>اسم الاختبار:</label>
        <input type="text" name="title" value="{{ old('title') }}" required>

        <label>الوصف:</label>
        <textarea name="description" rows="4">{{ old('description') }}</textarea>

        <label>مرتبط بمرض:</label>
        <select name="disease_id">
            <option value="">— بدون ارتباط —</option>
            @foreach($diseases as $d)
                <option value="{{ $d->id }}">{{ $d->name }}</option>
            @endforeach
        </select>

        <button type="submit" class="btn btn-primary">حفظ</button>
        <a href="{{ route('admin.tests.index') }}" class="btn btn-outline">إلغاء</a>
    </form>
</div>
@endsection
