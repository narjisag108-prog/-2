@extends('admin.layout')

@section('title', 'تفاصيل الاختبار')

@section('content')
<div class="admin-show">
    <h2><i class="fas fa-vial"></i> تفاصيل الاختبار</h2>

    <div class="card">
        <p><strong>اسم الاختبار:</strong> {{ $test->title }}</p>
        <p><strong>المرض المرتبط:</strong> {{ $test->disease->name ?? 'غير محدد' }}</p>
        <p><strong>الوصف:</strong></p>
        <p>{{ $test->description }}</p>
        <p><strong>عدد الأسئلة:</strong> {{ $test->questions->count() }}</p>
        <p><strong>تاريخ الإنشاء:</strong> {{ $test->created_at->format('Y-m-d') }}</p>
    </div>

    <h3 style="margin-top:25px; color:#2a7f62;">قائمة الأسئلة:</h3>
    @forelse($test->questions as $q)
        <div class="question-box">
            <p><strong>س:</strong> {{ $q->question_text }}</p>
            <p><strong>الإجابة:</strong> {{ $q->answer_text ?? 'غير محددة' }}</p>
        </div>
    @empty
        <p>لا توجد أسئلة مضافة لهذا الاختبار.</p>
    @endforelse

    <a href="{{ route('admin.tests.index') }}" class="btn btn-outline">رجوع</a>
</div>
@endsection
