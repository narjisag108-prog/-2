@extends('admin.layout')

@section('content')

<style>
    .form-card {
        background: #fff;
        border-radius: 12px;
        padding: 30px;
        border: 1px solid #e8e8e8;
        margin: 0 auto;
        max-width: 700px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.05);
    }

    .form-title {
        font-size: 24px;
        font-weight: 700;
        color: #2a7f62;
        margin-bottom: 30px;
        text-align: center;
    }

    .input-label {
        font-weight: 600;
        margin-bottom: 8px;
        display: block;
        color: #333;
    }

    .input-field, .form-control, textarea {
        width: 100%;
        padding: 12px 15px;
        border-radius: 8px;
        border: 1px solid #ccc;
        background: #fafafa;
        font-size: 15px;
        margin-bottom: 20px;
        transition: 0.2s;
    }

    .input-field:focus, .form-control:focus, textarea:focus {
        background: #fff;
        border-color: #2a7f62;
        outline: none;
        box-shadow: 0 0 6px rgba(42, 127, 98, 0.15);
    }

    .textarea-field {
        height: 120px;
        resize: none;
    }

    .btn {
        border-radius: 8px;
        padding: 12px 20px;
        font-size: 1rem;
    }

    .btn-group {
        display: flex;
        gap: 15px;
    }

    .alert {
        padding: 12px 15px;
        border-radius: 6px;
        margin-bottom: 20px;
        font-size: 0.95rem;
    }

    .alert-danger { background: #f8d7da; color: #721c24; }
</style>

<div class="content">
    <div class="container-fluid">

        <div class="form-card">

            <h2 class="form-title">إضافة مرض جديد</h2>

            {{-- عرض الأخطاء --}}
            @if ($errors->any())
                <div class="alert alert-danger">
                    <strong>تحقق من الأخطاء التالية:</strong>
                    <ul class="mt-2 mb-0">
                        @foreach ($errors->all() as $error)
                            <li>- {{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <form action="{{ route('admin.diseases.store') }}" method="POST">
                @csrf

                {{-- اسم المرض --}}
                <div>
                    <label class="input-label">اسم المرض</label>
                    <input type="text" name="name" class="input-field" value="{{ old('name') }}" required>
                </div>

                {{-- التصنيف --}}
                <div>
                    <label class="input-label">التصنيف</label>
                    <select name="category_id" class="form-control">
                        <option value="">— بدون تصنيف —</option>
                        @foreach($categories as $cat)
                            <option value="{{ $cat->id }}" @selected(old('category_id') == $cat->id)>
                                {{ $cat->name }}
                            </option>
                        @endforeach
                    </select>
                </div>

                {{-- الأعراض --}}
                <div>
                    <label class="input-label">الأعراض</label>
                    <textarea name="symptoms" class="input-field textarea-field">{{ old('symptoms') }}</textarea>
                </div>

                {{-- الوقاية --}}
                <div>
                    <label class="input-label">الوقاية</label>
                    <textarea name="prevention" class="input-field textarea-field">{{ old('prevention') }}</textarea>
                </div>

                {{-- العلاج --}}
                <div>
                    <label class="input-label">العلاج</label>
                    <textarea name="treatment" class="input-field textarea-field">{{ old('treatment') }}</textarea>
                </div>

                {{-- الوصف --}}
                <div>
                    <label class="input-label">الوصف</label>
                    <textarea name="description" class="input-field textarea-field">{{ old('description') }}</textarea>
                </div>

                {{-- الأزرار --}}
                <div class="btn-group">
                    <button type="submit" class="btn btn-primary">حفظ</button>
                    <a href="{{ route('admin.diseases.index') }}" class="btn btn-secondary">رجوع</a>
                </div>

            </form>

        </div>

    </div>
</div>

@endsection
