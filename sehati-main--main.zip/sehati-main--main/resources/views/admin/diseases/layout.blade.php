<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'لوحة التحكم')</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Tajawal', sans-serif;
            background: #f6f7fb;
            margin: 0;
            color: #333;
        }
        header {
            background: #2a7f62;
            color: #fff;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        header h1 { font-size: 1.4rem; }
        .admin-wrapper { display: flex; min-height: 100vh; }
        aside {
            width: 230px;
            background: #1e5f4a;
            color: #fff;
            padding: 20px;
        }
        aside h3 { color: #ffb347; margin-bottom: 20px; }
        aside ul { list-style: none; padding: 0; }
        aside li { margin-bottom: 10px; }
        aside a { color: #fff; text-decoration: none; display: block; padding: 6px 10px; border-radius: 4px; }
        aside a:hover { background: #2a7f62; }
        main { flex: 1; padding: 30px; }
    </style>

    @stack('styles')
</head>
<body>
    <header>
        <h1>لوحة التحكم - صحتك أولاً</h1>
        <div>
            <a href="{{ url('/') }}" style="color:#fff; text-decoration:none;">العودة للموقع</a>
        </div>
    </header>

    <div class="admin-wrapper">
        <aside>
            <h3>القائمة</h3>
            <ul>
                <li><a href="{{ route('admin.diseases.index') }}"><i class="fas fa-virus"></i> الأمراض</a></li>
                <li><a href="{{ route('admin.articles.index') }}"><i class="fas fa-newspaper"></i> المقالات</a></li>
                <li><a href="{{ route('admin.tests.index') }}"><i class="fas fa-vial"></i> الاختبارات</a></li>
            </ul>
        </aside>

        <main>
            @yield('content')
        </main>
    </div>
</body>
</html>
