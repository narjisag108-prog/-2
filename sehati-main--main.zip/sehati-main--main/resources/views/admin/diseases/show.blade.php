@extends('admin.layout')

@section('title', 'تفاصيل المرض')

@section('content')
<div class="admin-show">
    <h2><i class="fas fa-virus"></i> تفاصيل المرض</h2>

    <div class="card">
        <p><strong>الاسم:</strong> {{ $disease->name }}</p>
        <p><strong>الوصف:</strong></p>
        <p>{{ $disease->description }}</p>
        <p><strong>التصنيف:</strong> {{ $disease->category->name ?? 'غير مصنف' }}</p>
        <p><strong>عدد المقالات:</strong> {{ $disease->articles->count() }}</p>
        <p><strong>عدد الاختبارات:</strong> {{ $disease->tests->count() }}</p>
        <p><strong>تاريخ الإنشاء:</strong> {{ optional($disease->created_at)->format('Y-m-d') ?? 'غير متوفر' }}</p>

    </div>

    <a href="{{ route('admin.diseases.index') }}" class="btn btn-outline">رجوع</a>
</div>
@endsection
