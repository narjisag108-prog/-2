@extends('admin.layout')

@section('title', 'تعديل بيانات المرض')

@section('content')

<style>
    .form-card {
        background: #fff;
        border-radius: 12px;
        padding: 30px;
        border: 1px solid #e8e8e8;
        margin: 0 auto;
        max-width: 900px;
    }

    .form-title {
        font-size: 22px;
        font-weight: 700;
        color: #2a7f62;
        margin-bottom: 25px;
    }

    .input-label {
        font-weight: 600;
        margin-bottom: 6px;
        display: block;
        color: #333;
    }

    .input-field {
        width: 100%;
        padding: 12px 14px;
        border-radius: 8px;
        border: 1px solid #ccc;
        background: #fafafa;
        font-size: 15px;
        transition: 0.2s;
    }

    .input-field:focus {
        background: #fff;
        border-color: #2a7f62;
        outline: none;
        box-shadow: 0 0 6px rgba(42, 127, 98, 0.15);
    }

    .textarea-field {
        height: 130px;
        resize: none;
    }

    .form-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 25px;
    }

    @media(max-width: 768px){
        .form-grid {
            grid-template-columns: 1fr;
        }
    }
</style>

<div class="content">
    <div class="container-fluid">

        <div class="form-card">

            <h2 class="form-title">
                تعديل بيانات المرض
            </h2>

            @if ($errors->any())
                <div class="alert alert-danger">
                    <strong>تحقق من الأخطاء التالية:</strong>
                    <ul class="mt-2 mb-0">
                        @foreach ($errors->all() as $error)
                            <li>- {{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

    <form action="{{ route('admin.diseases.update', $disease) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')



                <div class="form-grid">
                    <div>
                        <label class="input-label">اسم المرض</label>
                        <input type="text" name="name" class="input-field"
                               value="{{ old('name', $disease->name) }}" required>
                    </div>
               <div>
    <label class="input-label">التصنيف</label>
    <select name="category_id" class="form-control">
        <option value="">— بدون تصنيف —</option>
        @foreach($categories as $cat)
            <option value="{{ $cat->id }}" @selected(old('category_id', $disease->category_id) == $cat->id)>
                {{ $cat->name }}
            </option>
        @endforeach
    </select>
</div>


                    <div>
                        <label class="input-label">الأعراض</label>
                        <textarea name="symptoms" class="input-field textarea-field">{{ old('symptoms', $disease->symptoms) }}</textarea>
                    </div>

                    <div>
                        <label class="input-label">الوقاية</label>
                        <textarea name="prevention" class="input-field textarea-field">{{ old('prevention', $disease->prevention) }}</textarea>
                    </div>

                    <div>
                        <label class="input-label">العلاج</label>
                        <textarea name="treatment" class="input-field textarea-field">{{ old('treatment', $disease->treatment) }}</textarea>
                    </div>
                </div>

                <div class="mt-3">
                    <label class="input-label">الوصف</label>
                    <textarea name="description" class="input-field textarea-field">{{ old('description', $disease->description) }}</textarea>
                </div>

        <button class="btn btn-primary mt-3">حفظ التعديلات</button>
        <a href="{{ route('admin.diseases.index') }}" class="btn btn-outline">رجوع</a>
    </form>


        </div>

    </div>
</div>

@endsection
