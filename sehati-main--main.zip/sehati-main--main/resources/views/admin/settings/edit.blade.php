@extends('admin.layout')
@section('title','إعدادات النظام')

@section('content')
<div class="card">
  <div class="card-body">

    {{-- Tabs header --}}
    <ul class="nav nav-tabs" id="settingsTabs" role="tablist" style="border-bottom:1px solid #e6ece6">
      <li class="nav-item"><a class="nav-link active" id="profile-tab" data-bs-toggle="tab" href="#profile" role="tab">الملف الشخصي</a></li>
      <li class="nav-item"><a class="nav-link" id="security-tab" data-bs-toggle="tab" href="#security" role="tab">الأمان</a></li>
      <li class="nav-item"><a class="nav-link" id="notifications-tab" data-bs-toggle="tab" href="#notifications" role="tab">الإشعارات</a></li>
      <li class="nav-item"><a class="nav-link" id="system-tab" data-bs-toggle="tab" href="#system" role="tab">إعدادات النظام</a></li>
    </ul>

    <div class="tab-content mt-4">

      {{-- Profile --}}
      <div class="tab-pane fade show active" id="profile" role="tabpanel">
      <form action="{{ route('admin.settings.update') }}" method="POST" enctype="multipart/form-data">
    @csrf
    @method('PUT')


          <input type="hidden" name="tab" value="profile">
          <div style="display:flex;gap:20px;align-items:flex-start">
            <div style="flex:0 0 160px;text-align:center">
              <img src="{{ $settings->admin_avatar ? asset('storage/'.$settings->admin_avatar) : asset('images/default-avatar.png') }}" style="width:100px;height:100px;border-radius:8px;object-fit:cover" alt="avatar">
              <div style="margin-top:8px">
                <input type="file" name="admin_avatar" class="form-control" />
                <small class="text-muted">يجب أن تكون الصورة بحجم 100x100 بكسل</small>
              </div>
            </div>

            <div style="flex:1">
              <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
                <div>
                  <label>الاسم الأول</label>
                  <input type="text" name="admin_first_name" class="form-control" value="{{ old('admin_first_name', $settings->admin_first_name) }}">
                </div>
                <div>
                  <label>اسم العائلة</label>
                  <input type="text" name="admin_last_name" class="form-control" value="{{ old('admin_last_name', $settings->admin_last_name) }}">
                </div>
              </div>

              <div style="margin-top:12px">
                <label>البريد الإلكتروني</label>
                <input type="email" name="admin_email" class="form-control" value="{{ old('admin_email', $settings->admin_email) }}">
              </div>

              <div style="margin-top:12px;display:grid;grid-template-columns:1fr 1fr;gap:12px">
                <div>
                  <label>رقم الهاتف</label>
                  <input type="text" name="admin_phone" class="form-control" value="{{ old('admin_phone', $settings->admin_phone) }}">
                </div>
                <div>
                  <label>&nbsp;</label>
                  <div style="height:1px"></div>
                </div>
              </div>

              <div style="margin-top:12px">
                <label>نبذة عنك</label>
                <textarea name="admin_bio" class="form-control" rows="4">{{ old('admin_bio', $settings->admin_bio) }}</textarea>
              </div>

              <div style="margin-top:12px;display:flex;gap:10px;justify-content:flex-end">
                <a href="{{ route('admin.settings.index') }}" class="btn btn-outline">إلغاء</a>
                <button class="btn btn-primary" type="submit">حفظ التغييرات</button>
              </div>
            </div>
          </div>
        </form>
      </div>

      {{-- Security --}}
      <div class="tab-pane fade" id="security" role="tabpanel">
        <div class="card p-3">
          <h5>تغيير كلمة المرور</h5>
          <form action="{{ route('admin.settings.update') }}" method="POST">
            @csrf
            <input type="hidden" name="tab" value="security">
            <div class="mb-2">
              <label>كلمة المرور الحالية</label>
              <input type="password" name="current_password" class="form-control">
            </div>
            <div class="mb-2">
              <label>كلمة المرور الجديدة</label>
              <input type="password" name="new_password" class="form-control">
              <small class="text-muted">يجب أن تحتوي كلمة المرور على الأقل على 8 أحرف، حرف كبير، حرف صغير، رقم ورموز خاصة</small>
            </div>
            <div class="mb-2">
              <label>تأكيد كلمة المرور الجديدة</label>
              <input type="password" name="new_password_confirmation" class="form-control">
            </div>
            <div class="d-flex justify-content-end gap-2">
              <a href="{{ route('admin.settings.index') }}" class="btn btn-outline">إلغاء</a>
              <button class="btn btn-primary">تغيير كلمة المرور</button>
            </div>
          </form>

          <hr />

          <h5>جلسات تسجيل الدخول</h5>
          <table class="table">
            <thead><tr><th>الجهاز</th><th>الموقع</th><th>آخر نشاط</th><th>الإجراء</th></tr></thead>
            <tbody>
              <tr><td>Chrome على Windows</td><td>الرياض، السعودية</td><td>منذ 5 دقائق</td><td><button class="btn btn-outline">تسجيل خروج</button></td></tr>
              <tr><td>Safari على iPhone</td><td>جدة، السعودية</td><td>منذ 3 أيام</td><td><button class="btn btn-outline">تسجيل خروج</button></td></tr>
            </tbody>
          </table>
        </div>
      </div>

      {{-- Notifications --}}
      <div class="tab-pane fade" id="notifications" role="tabpanel">
        <form action="{{ route('admin.settings.index') }}" method="POST">
          @csrf
          <input type="hidden" name="tab" value="notifications">
          <div class="card p-3">
            <h5>إشعارات البريد الإلكتروني</h5>
            <div class="form-check">
              <input type="checkbox" id="notify_email_enabled" name="notify_email_enabled" value="1" @if($settings->notify_email_enabled) checked @endif>
              <label for="notify_email_enabled">تفعيل إشعارات البريد الإلكتروني</label>
            </div>
            <div class="form-check">
              <input type="checkbox" id="notify_on_new_user" name="notify_on_new_user" value="1" @if($settings->notify_on_new_user) checked @endif>
              <label for="notify_on_new_user">إشعار عند تسجيل مستخدم جديد</label>
            </div>
            <div class="form-check">
              <input type="checkbox" id="notify_on_new_consultation" name="notify_on_new_consultation" value="1" @if($settings->notify_on_new_consultation) checked @endif>
              <label for="notify_on_new_consultation">إشعار عند طلب استشارة جديدة</label>
            </div>
            <div class="form-check">
              <input type="checkbox" id="notify_system_updates" name="notify_system_updates" value="1" @if($settings->notify_system_updates) checked @endif>
              <label for="notify_system_updates">إشعارات تحديثات النظام</label>
            </div>

            <h5 class="mt-3">إشعارات التطبيق</h5>
            <div class="form-check">
              <input type="checkbox" id="push_notify_enabled" name="push_notify_enabled" value="1" @if($settings->push_notify_enabled) checked @endif>
              <label for="push_notify_enabled">تفعيل إشعارات التطبيق</label>
            </div>
            <div class="form-check">
              <input type="checkbox" id="push_notify_sound" name="push_notify_sound" value="1" @if($settings->push_notify_sound) checked @endif>
              <label for="push_notify_sound">تشغيل الصوت للإشعارات</label>
            </div>

            <div class="d-flex justify-content-end gap-2 mt-3">
              <a href="{{ route('admin.settings.index') }}" class="btn btn-outline">إلغاء</a>
              <button class="btn btn-primary">حفظ التغييرات</button>
            </div>
          </div>
        </form>
      </div>

      {{-- System --}}
      <div class="tab-pane fade" id="system" role="tabpanel">
        <form action="{{ route('admin.settings.index') }}" method="POST" enctype="multipart/form-data">
          @csrf
          <input type="hidden" name="tab" value="system">
          <div class="card p-3">
            <div class="mb-2">
              <label>اسم الموقع</label>
              <input type="text" name="site_name" class="form-control" value="{{ old('site_name', $settings->site_name) }}">
            </div>

            <div class="mb-2">
              <label>لوجو الموقع</label>
              <input type="file" name="site_logo" class="form-control">
              <small class="text-muted">يجب أن تكون الصورة بحجم 200x50 بكسل</small>
            </div>

            <div class="mb-2">
              <label>وضع الصيانة</label>
              <select name="maintenance_mode" class="form-control">
                <option value="0" @if(!$settings->maintenance_mode) selected @endif>معطل</option>
                <option value="1" @if($settings->maintenance_mode) selected @endif>مفعل</option>
              </select>
            </div>

            <div class="mb-2">
              <label>كود التحليلات</label>
              <textarea name="analytics_code" class="form-control" rows="4">{{ old('analytics_code', $settings->analytics_code) }}</textarea>
            </div>

            <div class="d-flex justify-content-end gap-2 mt-3">
              <a href="{{ route('admin.settings.index') }}" class="btn btn-outline">إلغاء</a>
              <button class="btn btn-primary">حفظ التغييرات</button>
            </div>
          </div>
        </form>
      </div>

    </div>
  </div>
</div>

@push('scripts')
<script>
    // If you have bootstrap JS included, tabs will work automatically.
    // Fallback: simple JS to show/hide tabs when bootstrap is not present.
    document.addEventListener('DOMContentLoaded', function(){
        var tabs = document.querySelectorAll('#settingsTabs a');
        tabs.forEach(function(a){
            a.addEventListener('click', function(e){
                e.preventDefault();
                // hide all panes
                document.querySelectorAll('.tab-pane').forEach(p=>p.classList.remove('show','active'));
                tabs.forEach(t=>t.classList.remove('active'));
                // show clicked
                var target = document.querySelector(a.getAttribute('href'));
                if(target){ target.classList.add('show','active'); }
                a.classList.add('active');
            });
        });
    });
</script>
@endpush
@endsection
