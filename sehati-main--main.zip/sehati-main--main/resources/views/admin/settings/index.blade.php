@extends('admin.layout')
@section('title','إعدادات النظام')

@section('content')

<!-- التاريخ والوقت -->
<div class="date-time-box mb-3">
    <span id="current-day"></span>
    <span id="current-date"></span>
    <span id="current-time"></span>
</div>

<style>
:root {
    --primary: #2a7f62;
    --primary-light: #3ab795;
    --text-dark: #333;
    --text-light: #6c757d;
    --bg-light: #f8f9fa;
    --border-color: #ddd;
}

.settings-wrapper { margin-top: 20px; padding-bottom: 30px; }

/* Tabs */
.settings-tabs {
    display: flex;
    gap: 10px;
    margin-bottom: 30px;
}
.settings-tab {
    padding: 10px 20px;
    background: #fff;
    border-radius: 8px;
    cursor: pointer;
    box-shadow: 0 2px 6px rgba(0,0,0,0.05);
    transition: all 0.2s ease;
    font-weight: 600;
    color: var(--text-light);
}
.settings-tab:hover {
    color: var(--primary);
    transform: translateY(-2px);
}
.settings-tab.active {
    border-bottom: 3px solid var(--primary);
    color: var(--primary);
}

/* Cards */
.settings-card {
    background: #fff;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.06);
    margin-bottom: 30px;
    transition: 0.2s;
}
.settings-card:hover { box-shadow: 0 6px 25px rgba(0,0,0,0.08); }
.settings-card h4 {
    font-size: 22px;
    margin-bottom: 25px;
    color: var(--primary);
    font-weight: 700;
}

/* Profile */
.profile-box {
    display: flex;
    align-items: center;
    gap: 25px;
    margin-bottom: 20px;
}
.profile-box img {
    width: 120px;
    height: 120px;
    border-radius: 12px;
    object-fit: cover;
    border: 2px solid var(--border-color);
}

/* Forms */
.form-label {
    font-weight: 600;
    color: var(--text-dark);
    margin-bottom: 6px;
}
.form-control, .form-select, textarea {
    border-radius: 10px;
    padding: 12px 15px;
    border: 1px solid var(--border-color);
    transition: all 0.2s;
    font-size: 15px;
    width: 100%;
    background: #fff;
}
.form-control:focus, .form-select:focus, textarea:focus {
    border-color: var(--primary);
    box-shadow: 0 0 6px rgba(42,127,98,0.2);
    outline: none;
}
textarea.form-control { resize: vertical; }

/* Checkboxes */
.form-check {
    display: flex;
    align-items: center;
    gap: 8px;
}
.form-check input[type="checkbox"],
.form-check input[type="radio"] {
    width: 18px;
    height: 18px;
    accent-color: var(--primary);
}

/* Buttons */
.btn-primary {
    background-color: var(--primary);
    border-color: var(--primary);
    border-radius: 10px;
    padding: 10px 20px;
    font-weight: 600;
    transition: 0.2s;
}
.btn-primary:hover {
    background-color: var(--primary-light);
    border-color: var(--primary-light);
    transform: translateY(-1px);
}
.btn-outline {
    border-radius: 10px;
    padding: 8px 18px;
    background: #fff;
    border: 1px solid var(--primary);
    color: var(--primary);
    transition: 0.2s;
}
.btn-outline:hover {
    background: var(--primary);
    color: #fff;
    transform: translateY(-1px);
}

/* Tabs content */
.settings-content { display: none; }
.settings-content.active { display: block; }

/* Table (sessions) */
.settings-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 14px;
}
.settings-table th, .settings-table td {
    padding: 12px 15px;
    border-bottom: 1px solid #eee;
}
.settings-table th {
    color: var(--text-dark);
    font-weight: 600;
    background: #f5f5f5;
}

/* التاريخ */
.date-time-box {
    background: white;
    padding: 12px 18px;
    border-radius: 8px;
    display: inline-flex;
    gap: 15px;
    color: #2a7f62;
    font-weight: 600;
    font-size: 1rem;
    box-shadow: 0 5px 15px rgba(0, 0, 0, .05);
    border-right: 4px solid #2a7f62;
}
</style>

<div class="settings-wrapper">

    <!-- Tabs -->
    <div class="settings-tabs">
        <div class="settings-tab active" data-tab="profile">الملف الشخصي</div>
        <div class="settings-tab" data-tab="security">الأمان</div>
        <div class="settings-tab" data-tab="notifications">الإشعارات</div>
        <div class="settings-tab" data-tab="system">إعدادات النظام</div>
    </div>

    {{-- PROFILE --}}
    <div class="settings-content active" id="profile-settings">
        <div class="settings-card">
            <h4><i class="fas fa-user"></i> المعلومات الشخصية</h4>

            <form action="{{ route('admin.settings.update') }}" method="POST" enctype="multipart/form-data">
                @csrf
                @method('PUT')
                <input type="hidden" name="tab" value="profile">

                <div class="profile-box mb-4">
                    <img src="{{ $settings->admin_avatar ? asset('storage/'.$settings->admin_avatar) : asset('images/default-avatar.png') }}">
                    <div>
                        <label class="form-label">تغيير الصورة</label>
                        <input type="file" name="admin_avatar" class="form-control">
                        <small class="text-muted">الحجم المناسب 100x100</small>
                    </div>
                </div>

                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">الاسم الأول</label>
                        <input type="text" name="admin_first_name" class="form-control" value="{{ $settings->admin_first_name }}">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">اسم العائلة</label>
                        <input type="text" name="admin_last_name" class="form-control" value="{{ $settings->admin_last_name }}">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">البريد الإلكتروني</label>
                        <input type="email" name="admin_email" class="form-control" value="{{ $settings->admin_email }}">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">رقم الهاتف</label>
                        <input type="text" name="admin_phone" class="form-control" value="{{ $settings->admin_phone }}">
                    </div>
                    <div class="col-12">
                        <label class="form-label">نبذة عنك</label>
                        <textarea class="form-control" rows="4" name="admin_bio">{{ $settings->admin_bio }}</textarea>
                    </div>
                </div>

                <div class="text-end mt-3">
                    <button class="btn btn-primary">حفظ البيانات</button>
                </div>
            </form>
        </div>
    </div>

    {{-- SECURITY --}}
    <div class="settings-content" id="security-settings">
        <div class="settings-card">
            <h4><i class="fas fa-lock"></i> الأمان</h4>

            <form action="{{ route('admin.settings.update') }}" method="POST">
                @csrf
                @method('PUT')
                <input type="hidden" name="tab" value="security">

                <div class="mb-3">
                    <label class="form-label">كلمة المرور الحالية</label>
                    <input type="password" name="current_password" class="form-control">
                </div>
                <div class="mb-3">
                    <label class="form-label">كلمة المرور الجديدة</label>
                    <input type="password" name="new_password" class="form-control">
                </div>
                <div class="mb-3">
                    <label class="form-label">تأكيد كلمة المرور</label>
                    <input type="password" name="new_password_confirmation" class="form-control">
                </div>

                <div class="text-end">
                    <button class="btn btn-primary">تغيير كلمة المرور</button>
                </div>
            </form>
        </div>

        <div class="settings-card">
            <h4><i class="fas fa-shield-alt"></i> الجلسات النشطة</h4>
            <table class="settings-table">
                <tr>
                    <th>الجهاز</th>
                    <th>الموقع</th>
                    <th>آخر نشاط</th>
                    <th></th>
                </tr>
                <tr>
                    <td>Chrome / Windows</td>
                    <td>الرياض</td>
                    <td>قبل 5 دقائق</td>
                    <td><button class="btn btn-outline btn-sm">تسجيل خروج</button></td>
                </tr>
            </table>
        </div>
    </div>

    {{-- NOTIFICATIONS --}}
    <div class="settings-content" id="notifications-settings">
        <div class="settings-card">
            <h4><i class="fas fa-bell"></i> الإشعارات</h4>

            <form action="{{ route('admin.settings.update') }}" method="POST">
                @csrf
                @method('PUT')
                <input type="hidden" name="tab" value="notifications">

                <h5>إشعارات البريد الإلكتروني</h5>

                <div class="form-check mb-2">
                    <input type="checkbox" name="notify_email_enabled" @checked($settings->notify_email_enabled)>
                    <label class="form-check-label">تفعيل إشعارات البريد</label>
                </div>

                <div class="form-check mb-2">
                    <input type="checkbox" name="notify_on_new_user" @checked($settings->notify_on_new_user)>
                    <label class="form-check-label">عند تسجيل مستخدم جديد</label>
                </div>

                <div class="form-check mb-3">
                    <input type="checkbox" name="notify_on_new_consultation" @checked($settings->notify_on_new_consultation)>
                    <label class="form-check-label">عند إضافة استشارة جديدة</label>
                </div>

                <hr>

                <h5>إشعارات التطبيق</h5>

                <div class="form-check mb-2">
                    <input type="checkbox" name="push_notify_enabled" @checked($settings->push_notify_enabled)>
                    <label class="form-check-label">تفعيل إشعارات التطبيق</label>
                </div>

                <div class="form-check">
                    <input type="checkbox" name="push_notify_sound" @checked($settings->push_notify_sound)>
                    <label class="form-check-label">تشغيل صوت الإشعارات</label>
                </div>

                <div class="text-end mt-3">
                    <button class="btn btn-primary">حفظ التغييرات</button>
                </div>
            </form>
        </div>
    </div>

    {{-- SYSTEM --}}
    <div class="settings-content" id="system-settings">
        <div class="settings-card">
            <h4><i class="fas fa-tools"></i> إعدادات النظام</h4>

            <form action="{{ route('admin.settings.update') }}" method="POST" enctype="multipart/form-data">
                @csrf
                @method('PUT')
                <input type="hidden" name="tab" value="system">

                <div class="mb-3">
                    <label class="form-label">اسم الموقع</label>
                    <input type="text" class="form-control" name="site_name" value="{{ $settings->site_name }}">
                </div>

                <div class="mb-3">
                    <label class="form-label">لوجو الموقع</label>
                    <input type="file" class="form-control" name="site_logo">
                </div>

                <div class="mb-3">
                    <label class="form-label">وضع الصيانة</label>
                    <select class="form-select" name="maintenance_mode">
                        <option value="0" @selected(!$settings->maintenance_mode)>معطّل</option>
                        <option value="1" @selected($settings->maintenance_mode)>مفعّل</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">كود التحليلات</label>
                    <textarea class="form-control" rows="4" name="analytics_code">{{ $settings->analytics_code }}</textarea>
                </div>

                <div class="text-end">
                    <button class="btn btn-primary">حفظ التغييرات</button>
                </div>
            </form>
        </div>
    </div>

</div>

@push('scripts')
<script>
    // التاريخ
    function updateDateTime() {
        const now = new Date();
        const days = ["الأحد","الإثنين","الثلاثاء","الأربعاء","الخميس","الجمعة","السبت"];
        document.getElementById("current-day").innerText = days[now.getDay()] + " -";
        document.getElementById("current-date").innerText =
            now.getFullYear() + "/" + (now.getMonth() + 1).toString().padStart(2, '0') +
            "/" + now.getDate().toString().padStart(2, '0') + " -";
        document.getElementById("current-time").innerText =
            now.getHours().toString().padStart(2, '0') + ":" +
            now.getMinutes().toString().padStart(2, '0') + ":" +
            now.getSeconds().toString().padStart(2, '0');
    }
    setInterval(updateDateTime, 1000);
    updateDateTime();

    // Tabs switching
    document.querySelectorAll('.settings-tab').forEach(tab => {
        tab.addEventListener('click', () => {
            document.querySelectorAll('.settings-tab').forEach(t => t.classList.remove('active'));
            document.querySelectorAll('.settings-content').forEach(c => c.classList.remove('active'));

            tab.classList.add('active');
            document.getElementById(tab.dataset.tab + "-settings").classList.add('active');
        });
    });
</script>
@endpush

@endsection
