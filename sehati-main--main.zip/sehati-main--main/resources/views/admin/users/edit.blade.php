@extends('admin.layout')
@section('title', 'تعديل المستخدم')

@section('content')

<div class="admin-form">
    <h2><i class="fas fa-edit"></i> تعديل المستخدم</h2>

    <form action="{{ route('admin.users.update', $user) }}" method="POST" enctype="multipart/form-data">
        @csrf @method('PUT')

        <label>الاسم الكامل:</label>
        <input type="text" name="name" class="form-control" value="{{ $user->name }}" required>

        <label>البريد الإلكتروني:</label>
        <input type="email" name="email" class="form-control" value="{{ $user->email }}" required>

        <label>كلمة المرور (اتركه فارغ):</label>
        <input type="password" name="password" class="form-control">

        <label>الدور:</label>
        <select name="role" class="form-control">
            <option value="user" @selected($user->role=='user')>مستخدم</option>
            <option value="doctor" @selected($user->role=='doctor')>طبيب</option>
            <option value="admin" @selected($user->role=='admin')>مسؤول</option>
        </select>

        <label>الحالة:</label>
        <select name="status" class="form-control">
            <option value="active" @selected($user->status=='active')>نشط</option>
            <option value="inactive" @selected($user->status=='inactive')>غير نشط</option>
            <option value="banned" @selected($user->status=='banned')>محظور</option>
        </select>

        <label>الصورة الحالية:</label><br>
        <img src="{{ asset('storage/'.$user->avatar) }}" class="avatar-img">

        <label class="mt-2">تغيير الصورة:</label>
        <input type="file" name="avatar" class="form-control">

        <button class="btn btn-primary mt-3">حفظ التعديلات</button>
        <a href="{{ route('admin.users.index') }}" class="btn btn-outline">رجوع</a>
    </form>

</div>

@endsection
