@extends('admin.layout')
@section('title', 'إضافة مستخدم جديد')
@section('content')

<div class="admin-form">
    <h2><i class="fas fa-vial"></i> إضافة مستخدم جديد</h2>

    <form action="{{ route('admin.users.store') }}" method="POST" enctype="multipart/form-data">
        @csrf

        <label>الاسم الكامل:</label>
        <input type="text" name="name" class="form-control" required>

        <label>البريد الإلكتروني:</label>
        <input type="email" name="email" class="form-control" required>

        <label>كلمة المرور:</label>
        <input type="password" name="password" class="form-control" required>

        <label>الدور:</label>
        <select name="role" class="form-control">
            <option value="user">مستخدم</option>
            <option value="doctor">طبيب</option>
            <option value="admin">مسؤول</option>
        </select>

        <label>الحالة:</label>
        <select name="status" class="form-control">
            <option value="active">نشط</option>
            <option value="inactive">غير نشط</option>
            <option value="banned">محظور</option>
        </select>

        <label>الصورة الشخصية:</label>
        <input type="file" name="avatar" class="form-control">

        <button class="btn btn-primary mt-3">إضافة</button>
        <a href="{{ route('admin.users.index') }}" class="btn btn-outline">رجوع</a>
    </form>

</div>

@endsection
