@extends('admin.layout')
@section('title', 'تفاصيل المستخدم')

@section('content')

<div class="admin-show">
    <h2><i class="fas fa-user"></i> تفاصيل المستخدم</h2>
    <div class="card">
    <div class="user-box">
        <img src="{{ asset('storage/'.$user->avatar) }}" class="avatar-big">

        <h3>{{ $user->name }}</h3>
        <p><b>البريد:</b> {{ $user->email }}</p>
        <p><b>الدور:</b> {{ $user->role }}</p>
        <p><b>الحالة:</b> {{ $user->status }}</p>
        <p><b>مسجل منذ:</b> {{ $user->created_at->diffForHumans() }}</p>

        <a href="{{ route('admin.users.index') }}" class="btn btn-outline mt-3">رجوع</a>
    </div>

</div>
</div>

@endsection
