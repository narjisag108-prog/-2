@extends('admin.layout')

@section('title', 'إضافة مقال جديد')

@section('content')
<div class="admin-form">
    <h2><i class="fas fa-plus-circle"></i> إضافة مقال جديد</h2>

    <form action="{{ route('admin.articles.store') }}" method="POST">
        @csrf
    
        <label>عنوان المقال:</label>
        <input type="text" name="title" value="{{ old('title') }}" required>
    
        <label>محتوى المقال:</label>
        <textarea name="content" rows="8" required>{{ old('content') }}</textarea>
    
        <label>اسم الكاتب:</label>
        <input type="text" name="author_name" value="{{ old('author_name') }}" required>
    
        <label>مرتبط بمرض:</label>
        <select name="disease_id">
            <option value="">— بدون ارتباط —</option>
            @foreach($diseases as $d)
                <option value="{{ $d->id }}" @selected(old('disease_id') == $d->id)>{{ $d->name }}</option>
            @endforeach
        </select>
    
        <label>حالة المقال:</label>
        <select name="status" required>
            <option value="published" @selected(old('status') == 'published')>منشور</option>
            <option value="draft" @selected(old('status') == 'draft')>مسودة</option>
        </select>
    
        <button type="submit" class="btn btn-primary">حفظ المقال</button>
        <a href="{{ route('admin.articles.index') }}" class="btn btn-outline">إلغاء</a>
    </form>
    
</div>
@endsection
