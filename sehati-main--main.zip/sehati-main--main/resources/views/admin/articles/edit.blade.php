@extends('admin.layout')

@section('title', 'تعديل مقال')

@section('content')
<div class="admin-container">
    <!-- العنوان -->
    <div class="page-header">
        <h2><i class="fas fa-edit"></i> تعديل مقال</h2>
        <a href="{{ route('admin.articles.index') }}" class="btn btn-outline">
            <i class="fas fa-arrow-left"></i> رجوع
        </a>
    </div>

    <!-- التنبيهات -->
    @if ($errors->any())
        <div class="alert alert-danger">
            <ul style="margin:0; padding-left: 20px;">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
    @if (session('success'))
        <div class="alert alert-success">
            <i class="fas fa-check-circle"></i> {{ session('success') }}
        </div>
    @endif

    <!-- نموذج التعديل -->
    <div class="admin-form">
        <form action="{{ route('admin.articles.update', $article) }}" method="POST">
            @csrf
            @method('PUT')

            <label>عنوان المقال:</label>
            <input type="text" name="title" value="{{ old('title', $article->title) }}" required>

            <label>محتوى المقال:</label>
            <textarea name="content" rows="8">{{ old('content', $article->content) }}</textarea>

            <label>اسم الكاتب:</label>
            <input type="text" name="author_name" value="{{ old('author_name', $article->author_name) }}">

            <label>مرتبط بمرض:</label>
            <select name="disease_id">
                <option value="">— بدون ارتباط —</option>
                @foreach($diseases as $d)
                    <option value="{{ $d->id }}" @selected(old('disease_id', $article->disease_id) == $d->id)>{{ $d->name }}</option>
                @endforeach
            </select>
            <label>حالة المقال:</label>
<select name="published">
    <option value="1" @selected(old('published', $article->published ?? 0) == 1)>منشور</option>
    <option value="0" @selected(old('published', $article->published ?? 0) == 0)>مسودة</option>
</select>


            <div style="margin-top: 15px;">
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> تحديث المقال</button>
                <a href="{{ route('admin.articles.index') }}" class="btn btn-outline"><i class="fas fa-arrow-left"></i> رجوع</a>
            </div>
        </form>
    </div>
</div>
@endsection

@push('styles')
<style>
.admin-container {
    padding: 30px;
    background: #fff;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0,0,0,.05);
}
.page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 25px;
}
.page-header h2 {
    color: #2a7f62;
    font-size: 1.5rem;
    display: flex;
    align-items: center;
    gap: 10px;
}
.admin-form {
    display: flex;
    flex-direction: column;
    gap: 15px;
}
.admin-form label {
    font-weight: 600;
}
.admin-form input, .admin-form textarea, .admin-form select {
    width: 100%;
    padding: 10px 12px;
    border-radius: 5px;
    border: 1px solid #ccc;
    font-size: 0.95rem;
}
.admin-form button {
    display: inline-flex;
    align-items: center;
    gap: 5px;
}
.alert {
    padding: 10px 15px;
    border-radius: 6px;
    margin-bottom: 15px;
    font-size: 0.95rem;
}
.alert-success { background: #d4edda; color: #155724; }
.alert-danger { background: #f8d7da; color: #721c24; }
</style>
@endpush
