@extends('admin.layout')
@section('title', 'إدارة المقالات')

@section('content')

<!-- التاريخ والوقت -->
<div class="date-time-box mb-3">
    <span id="current-day"></span>
    <span id="current-date"></span>
    <span id="current-time"></span>
</div>

<!-- العنوان + زر إضافة مقال -->
<div class="page-header">
    <h2>المقالات</h2>

    <div style="display:flex; gap:10px;">
        <!-- البحث -->
        <form method="GET" action="{{ route('admin.articles.index') }}" class="search-box">
            <input type="text" name="q" value="{{ request('q') }}" placeholder="ابحث عن مقال..." />
            <button><i class="fas fa-search"></i></button>
        </form>

        <!-- زر إضافة مقال -->
        <a href="{{ route('admin.articles.create') }}" class="btn btn-primary">
            <i class="fas fa-plus"></i> إضافة مقال
        </a>
    </div>
</div>

<!-- كروت الإحصائيات -->
<div class="stats-cards">

    <div class="stat-card primary">
        <h3>{{ $newArticles }}</h3>
        <p>المقالات الجديدة</p>
        <small>خلال آخر 7 أيام</small>
    </div>

    <div class="stat-card secondary">
        <h3>{{ $totalArticles }}</h3>
        <p>إجمالي المقالات</p>
    </div>

    <div class="stat-card accent">
        <h3>{{ $activeArticles }}</h3>
        <p>المقالات المنشورة</p>
    </div>

    <div class="stat-card dark">
        <h3>{{ $writersCount }}</h3>
        <p>عدد الكُتاب</p>
    </div>

</div>


<!-- أحدث المقالات -->
<div class="section-box">
    <div class="section-header">
        <h4><i class="fas fa-newspaper"></i> أحدث المقالات</h4>
        <a href="{{ route('admin.articles.index') }}" class="btn btn-outline">عرض الكل</a>
    </div>

    <div class="table-container">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>العنوان</th>
                    <th>المرض المرتبط</th>
                    <th>المؤلف</th>
                    <th>الحالة</th>
                    <th>التاريخ</th>
                    <th>إجراءات</th>
                </tr>
            </thead>
            <tbody>
                @forelse($latestArticles as $article)
                <tr>
                    <td>{{ $article->title }}</td>
                    <td>{{ $article->author_name }}</td>
                    <td>{{ $article->disease->name ?? 'غير مرتبط' }}</td>
                    <td>{{ $article->status == 'published' ? 'منشور' : 'مسودة' }}</td>
                    <td>{{ $article->created_at->format('Y-m-d') }}</td>
                    <td>
                        <a href="{{ route('admin.articles.show', $article) }}" class="btn btn-outline">
                            <i class="fas fa-eye"></i>
                        </a>
                        <a href="{{ route('admin.articles.edit', $article) }}" class="btn btn-outline">
                            <i class="fas fa-edit"></i>
                        </a>
                    </td>
                </tr>
                @empty
                    <tr><td colspan="6" class="text-center">لا توجد مقالات</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

@endsection


@push('styles')
<style>
    .admin-container {
        padding: 30px;
        background: #fff;
        border-radius: 15px;
        box-shadow: 0 8px 25px rgba(0,0,0,.08);
    }

    .page-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 30px;
    }

    .page-header h2 {
        color: #2a7f62;
        font-size: 1.7rem;
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .stats-cards {
        display: flex;
        gap: 20px;
        flex-wrap: wrap;
        margin-bottom: 30px;
    }

    .stat-card {
        flex: 1 1 200px;
        padding: 25px 20px;
        border-radius: 15px;
        color: #fff;
        box-shadow: 0 4px 20px rgba(0,0,0,.05);
        display: flex;
        flex-direction: column;
        justify-content: center;
        text-align: center;
        transition: transform 0.3s, box-shadow 0.3s;
    }

    .stat-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 25px rgba(0,0,0,.12);
    }

    .stat-card h3 {
        font-size: 2rem;
        margin-bottom: 5px;
    }

    .stat-card p {
        font-size: 1.1rem;
        margin-bottom: 5px;
        font-weight: 500;
    }

    .stat-card small {
        font-size: 0.85rem;
        opacity: 0.8;
    }

    .stat-card.primary { background: #2a7f62; }
    .stat-card.secondary { background: #28a745; }
    .stat-card.accent { background: #ffc107; color: #333; }
    .stat-card.dark { background: #343a40; }

    .section-box {
        background: #fff;
        padding: 20px;
        border-radius: 15px;
        box-shadow: 0 5px 15px rgba(0,0,0,.05);
        margin-bottom: 25px;
    }

    .section-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 15px;
    }

    .section-header h4 {
        font-size: 1.2rem;
        color: #2a7f62;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .activity-list li {
        display: flex;
        justify-content: space-between;
        padding: 8px 10px;
        border-bottom: 1px solid #eee;
    }

    .activity-list li div {
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .activity-list .empty-text {
        text-align: center;
        padding: 15px 0;
        color: #888;
    }

    .table-container { overflow-x: auto; }

    .admin-table {
        width: 100%;
        border-collapse: collapse;
        min-width: 800px;
        border-radius: 10px;
        overflow: hidden;
    }

    .admin-table th, .admin-table td {
        padding: 14px 18px;
        border-bottom: 1px solid #eee;
        text-align: center;
    }

    .admin-table th {
        background-color: #2a7f62;
        color: #fff;
        font-weight: 600;
    }

    .btn {
        display: inline-block;
        padding: 8px 14px;
        border-radius: 7px;
        font-size: 0.95rem;
        cursor: pointer;
        transition: 0.3s;
        text-decoration: none;
    }

    .btn-primary {
        background: #2a7f62;
        color: #fff;
        border: none;
    }

    .btn-primary:hover { background: #1e5f4a; }

    .btn-outline {
        background: transparent;
        color: #2a7f62;
        border: 1px solid #2a7f62;
    }

    .btn-outline:hover {
        background: #2a7f62;
        color: #fff;
    }

    .btn-danger {
        background: #dc3545;
        color: #fff;
        border: none;
    }

    .btn-danger:hover { background: #b52a35; }

    .pagination-container { margin-top: 20px; text-align: center; }

    .search-box {
        display: flex;
        background: #fff;
        border-radius: 8px;
        overflow: hidden;
        border: 1px solid #ccc;
    }

    .search-box input {
        border: none;
        padding: 8px 12px;
        width: 220px;
        outline: none;
    }

    .search-box button {
        background: #2a7f62;
        border: none;
        color: white;
        padding: 0 14px;
        cursor: pointer;
    }
</style>
@endpush

