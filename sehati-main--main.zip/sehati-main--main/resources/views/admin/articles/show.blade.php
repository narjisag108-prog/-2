@extends('admin.layout')

@section('title', 'عرض المقال')

@section('content')
<div class="admin-show">
    <h2><i class="fas fa-newspaper"></i> تفاصيل المقال</h2>

    <div class="card">
        <p><strong>العنوان:</strong> {{ $article->title }}</p>
        <p><strong>الكاتب:</strong> {{ $article->author_name ?? 'غير محدد' }}</p>
        <p><strong>المرض المرتبط:</strong> {{ $article->disease->name ?? 'غير مرتبط' }}</p>
        <p><strong>تاريخ النشر:</strong> {{ $article->created_at->format('Y-m-d') }}</p>
        <hr>
        <p><strong>محتوى المقال:</strong></p>
        <div class="article-content">
            {!! nl2br(e($article->content)) !!}
        </div>
    </div>

    <a href="{{ route('admin.articles.index') }}" class="btn btn-outline">رجوع</a>
</div>
@endsection
