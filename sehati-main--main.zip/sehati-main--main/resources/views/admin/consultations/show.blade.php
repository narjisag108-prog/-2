@extends('admin.layout')
@section('title', 'عرض الاستشارة')

@section('content')

<!-- التاريخ والوقت -->
<div class="date-time-box mb-3">
    <span id="current-day"></span>
    <span id="current-date"></span>
    <span id="current-time"></span>
</div>

<div class="page-header">
    <h2>
        <i class="fas fa-comment-medical"></i>
        تفاصيل الاستشارة #{{ $consultation->id }}
    </h2>

    <a href="{{ route('admin.consultations.index') }}" class="btn btn-outline">
        <i class="fas fa-arrow-left"></i> رجوع
    </a>
</div>

{{-- ================= بيانات الاستشارة ================= --}}
<div class="card mb-4">
    <h3 class="section-title">📋 بيانات الاستشارة</h3>

    <div class="details-grid">
        <div><strong>المريض:</strong> {{ $consultation->user->name ?? '-' }}</div>
        <div><strong>البريد:</strong> {{ $consultation->user->email ?? '-' }}</div>
        <div><strong>الهاتف:</strong> {{ $consultation->user->phone ?? '-' }}</div>
        <div><strong>المرض:</strong> {{ $consultation->disease->name ?? '-' }}</div>
        <div><strong>الطبيب:</strong> {{ $consultation->doctor->name ?? 'غير معيّن' }}</div>

        <div>
            <strong>الحالة:</strong>
            <span class="badge badge-{{ $consultation->status }}">
                {{ __('statuses.' . $consultation->status) }}
            </span>
        </div>

        <div>
            <strong>تاريخ الطلب:</strong>
            {{ $consultation->created_at->format('Y-m-d h:i A') }}
        </div>
    </div>
</div>

{{-- ================= الموضوع والوصف ================= --}}
<div class="card mb-4">
    <h3 class="section-title">📝 موضوع الاستشارة</h3>
    <p class="text-block">{{ $consultation->subject }}</p>

    <h3 class="section-title">📄 تفاصيل المشكلة</h3>
    <p class="text-block">
        {{ $consultation->description }}
    </p>
</div>

{{-- ================= ردود الطبيب ================= --}}
<div class="card mb-4">
    <h3 class="section-title">
        <i class="fas fa-user-md"></i>
        ردود الطبيب
    </h3>

    @forelse($consultation->replies as $reply)
        <div class="reply-item">
            <div class="reply-header">
                <strong>د. {{ $reply->doctor->name }}</strong>
                <span class="reply-date">
                    {{ $reply->created_at->diffForHumans() }}
                </span>
            </div>

            <p>{{ $reply->reply }}</p>
        </div>
        <hr>
    @empty
        <p class="text-muted text-center">
            ⏳ لم يتم الرد من الطبيب بعد
        </p>
    @endforelse
</div>

@endsection
