@extends('admin.layout')
@section('title','تعديل الاستشارة')

@section('content')

<div class="admin-form">
    <h2><i class="fas fa-edit"></i> تعديل الاستشارة</h2>

    <form action="{{ route('admin.consultations.update',$consultation) }}" method="POST">
@csrf @method('PUT')

<label>تعيين الطبيب</label>
<select name="doctor_id" class="form-control">
    <option value="">— بدون —</option>
    @foreach($doctors as $d)
        <option value="{{ $d->id }}"
            @selected($consultation->doctor_id == $d->id)>
            {{ $d->name }}
        </option>
    @endforeach
</select>

<label>الحالة</label>
<select name="status" class="form-control">
    <option value="pending"  @selected($consultation->status=='pending')>قيد الانتظار</option>
    <option value="answered" @selected($consultation->status=='answered')>تم الرد</option>
    <option value="closed"   @selected($consultation->status=='closed')>مغلقة</option>
</select>

<button class="btn btn-primary">حفظ</button>
</form>

</div>

@endsection
