@extends('admin.layout')
@section('title','إدارة الاستشارات')

@section('content')

<div class="card">

    <!-- التاريخ والوقت -->
    <div class="date-time-box mb-3">
        <span id="current-day"></span>
        <span id="current-date"></span>
        <span id="current-time"></span>
    </div>

    <!-- عنوان الصفحة -->
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px">
        <h2><i class="fas fa-comments"></i> إدارة الاستشارات</h2>
    <div>
                
    </div>
    </div>
    <!-- كروت الإحصائيات -->
    <div class="stats-cards mb-4">
        <div class="stat-card primary">
             <h3>{{ $newCount ?? 0 }}</h3>
            <p>استشارات جديدة</p>
        <small>+{{ $newWeekCount ?? 0 }} هذا الأسبوع</small>
        </div>

        <div class="stat-card secondary">
             <h3>{{ $reviewCount ?? 0 }}</h3>
            <p>قيد المراجعة</p>
        </div>

        <div class="stat-card accent">
       <h3>{{ $completedCount ?? 0 }}</h3>
            <p>مكتملة</p>
        </div>

        <div class="stat-card dark">
          <h3>{{ $canceledCount ?? 0 }}</h3>
            <p>ملغاة</p>
        </div>
    </div>
<!-- البحث -->
<div class="card mb-3">
    <form method="GET" action="{{ route('admin.consultations.index') }}">
        <div class="form-row" style="display:flex;flex-wrap:wrap;gap:15px;margin-bottom:10px">

            <div class="form-col" style="flex:1;min-width:240px">
                <label class="form-label">بحث</label>
                <input type="text" name="q" class="form-control"
                       placeholder="ابحث باسم المريض أو الموضوع..."
                       value="{{ request('q') }}">
            </div>

            <div class="form-col" style="flex:1;min-width:200px">
                <label class="form-label">المرض</label>
                <select name="disease_id" class="form-control">
                    <option value="">الكل</option>
                    @foreach($diseases as $d)
                        <option value="{{ $d->id }}" @selected(request('disease_id')==$d->id)>
                            {{ $d->name }}
                        </option>
                    @endforeach
                </select>
            </div>

            {{-- <div class="form-col" style="flex:1;min-width:200px">
                <label class="form-label">الطبيب</label>
                <select name="doctor_id" class="form-control">
                    <option value="">الكل</option>
                    @foreach($doctors as $doc)
                        <option value="{{ $doc->id }}" @selected(request('doctor_id')==$doc->id)>
                            {{ $doc->name }}
                        </option>
                    @endforeach
                </select>
            </div> --}}
        </div>

        <!-- أزرار -->
        <div style="display:flex;gap:10px;justify-content:flex-end;">
            <button class="btn btn-primary" style="display:flex;align-items:center;gap:5px">
                <i class="fas fa-filter"></i> تصفية
            </button>

            <a href="{{ route('admin.consultations.index') }}"
               class="btn btn-outline"
               style="display:flex;align-items:center;gap:5px">
                <i class="fas fa-redo"></i> إعادة تعيين
            </a>
        </div>
    </form>
</div>

    <!-- Tabs -->
    <div class="consultation-tabs mb-3">
        <a class="consultation-tab {{ request('status')=='new' ? 'active' : '' }}"
           href="{{ route('admin.consultations.index',['status'=>'new']) }}">
           <span class="badge badge-primary">{{ $newCount }}</span> جديدة
        </a>

        <a class="consultation-tab {{ request('status')=='review' ? 'active' : '' }}"
           href="{{ route('admin.consultations.index',['status'=>'review']) }}">
           <span class="badge badge-secondary">{{ $reviewCount }}</span> قيد المراجعة
        </a>

        <a class="consultation-tab {{ request('status')=='completed' ? 'active' : '' }}"
           href="{{ route('admin.consultations.index',['status'=>'completed']) }}">
           <span class="badge badge-success">{{ $completedCount }}</span> مكتملة
        </a>

        <a class="consultation-tab {{ request('status')=='canceled' ? 'active' : '' }}"
           href="{{ route('admin.consultations.index',['status'=>'canceled']) }}">
           <span class="badge badge-danger">{{ $canceledCount }}</span> ملغاة
        </a>
    </div>

    <!-- جدول الاستشارات -->
    <div class="table-container">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>المريض</th>
                    <th>الموضوع</th>
                    <th>المرض</th>
                    <th>الطبيب</th>
                    <th>التاريخ</th>
                    <th>الحالة</th>
                    <th>الإجراءات</th>
                </tr>
            </thead>
            <tbody>
                @forelse($consultations as $c)
                <tr>
                    <td>{{ $c->id }}</td>
                    <td>{{ $c->user->name ?? 'غير محدد' }}</td>
                    <td>{{ Str::limit($c->subject, 35) }}</td>
                    <td>{{ $c->disease->name ?? '-' }}</td>
                    <td>{{ $c->doctor->name ?? '-' }}</td>
                    <td>{{ $c->created_at->format('Y-m-d') }}</td>

                    <td><span class="badge badge-{{ $c->status }}">{{ __('statuses.'.$c->status) }}</span></td>

                    <td>
                        <a href="{{ route('admin.consultations.show',$c) }}" class="btn btn-outline">
                            <i class="fas fa-eye"></i>
                        </a>

                        <form action="{{ route('admin.consultations.destroy',$c) }}" method="POST"
                              style="display:inline-block"
                              onsubmit="return confirm('هل أنت متأكد من الحذف؟')">
                            @csrf @method('DELETE')
                            <button class="btn btn-danger"><i class="fas fa-trash"></i></button>
                        </form>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="8" class="text-center">لا توجد استشارات حالياً</td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <div class="pagination-container">
        {{ $consultations->links('pagination::bootstrap-5') }}
    </div>

</div>


@endsection

@push('styles')
<style>
    :root{
        --primary-color:#2a7f62;
        --secondary-color:#3ab795;
        --accent-color:#ff7e5f;
        --dark-color:#343a40;
        --text-light:#6c757d;
    }

    .dashboard-header {
        display:flex;
        justify-content:space-between;
        align-items:center;
        margin-bottom:25px;
    }

    .dashboard-header h2{
        color:var(--primary-color);
        display:flex;
        align-items:center;
        gap:8px;
    }

    /* كروت الإحصائيات */
    .stats-cards {
        display:grid;
        grid-template-columns:repeat(auto-fit,minmax(200px,1fr));
        gap:20px;
        margin-bottom:25px;
    }
    .form-label{
    font-weight:600;
    margin-bottom:6px;
    display:block;
    color:#2a7f62;
}

    .stat-card {
        background:#fff;
        padding:20px;
        border-radius:8px;
        box-shadow:0 5px 15px rgba(0,0,0,0.05);
        text-align:center;
    }
    .stat-card h3{
        font-size:1.5rem;
        color:var(--primary-color);
        margin-bottom:8px;
    }
    .stat-card p{
        color:var(--text-light);
        margin-bottom:4px;
    }
    .stat-card small{
        color:var(--text-light);
        font-size:.8rem;
    }
    .stat-card.primary{border-top:4px solid var(--primary-color);}
    .stat-card.secondary{border-top:4px solid var(--secondary-color);}
    .stat-card.accent{border-top:4px solid var(--accent-color);}
    .stat-card.dark{border-top:4px solid var(--dark-color);}

    /* Tabs الاستشارات */
    .consultation-tabs{
        display:flex;
        border-bottom:1px solid #ddd;
        margin-bottom:20px;
        gap:10px;
        flex-wrap:wrap;
    }
    .consultation-tab{
        padding:8px 16px;
        cursor:pointer;
        border-bottom:2px solid transparent;
        border-radius:4px 4px 0 0;
        background:#fff;
        display:flex;
        align-items:center;
        gap:6px;
        font-size:.95rem;
    }
    .consultation-tab.active{
        border-bottom-color:var(--primary-color);
        color:var(--primary-color);
        font-weight:500;
    }

    /* بحث وفلترة */
    .search-filter{
        background:#fff;
        padding:20px;
        border-radius:8px;
        box-shadow:0 5px 15px rgba(0,0,0,0.05);
        margin-bottom:20px;
    }
    .form-row{
        display:flex;
        flex-wrap:wrap;
        margin:0 -8px 10px;
    }
    .form-col{
        flex:1;
        padding:0 8px;
        min-width:220px;
    }
    .form-group label{
        display:block;
        font-weight:500;
        margin-bottom:4px;
    }
    .form-control{
        width:100%;
        padding:8px 10px;
        border:1px solid #ddd;
        border-radius:4px;
        font-family:'Tajawal',sans-serif;
    }

    .btn-primary {
        background: #2a7f62;
        color: #fff;
    }
    .btn-primary:hover {
        background: #1e5f4a;
    }

    .btn-outline {
        background: transparent;
        color: #2a7f62;
        border: 1px solid #2a7f62;
    }
    .btn-outline:hover {
        background: #2a7f62;
        color: #fff;
    }

    /* صندوق المحتوى */
    .content-management{
        background:#fff;
        padding:20px;
        border-radius:8px;
        box-shadow:0 5px 15px rgba(0,0,0,0.05);
        margin-bottom:30px;
    }
    .section-title{
        display:flex;
        justify-content:space-between;
        align-items:center;
        margin-bottom:15px;
        padding-bottom:8px;
        border-bottom:1px solid #eee;
    }
    .section-title h3{
        color:var(--primary-color);
        display:flex;
        align-items:center;
        gap:6px;
    }

    table{
        width:100%;
        border-collapse:collapse;
    }
    table th, table td{
        padding:10px 12px;
        text-align:right;
        border-bottom:1px solid #eee;
    }
    table th{
        background:#f8f9fa;
        color:var(--primary-color);
        font-weight:500;
    }
    table tr:hover{
        background:#f8f9fa;
    }

    .badge{
        display:inline-block;
        padding:3px 8px;
        border-radius:4px;
        font-size:.8rem;
        font-weight:500;
    }
    .badge-primary{background:rgba(42,127,98,.1);color:var(--primary-color);}
    .badge-secondary{background:rgba(58,183,149,.1);color:var(--secondary-color);}
    .badge-success{background:rgba(40,167,69,.1);color:#28a745;}
    .badge-danger{background:rgba(220,53,69,.1);color:#dc3545;}

    .action-buttons .btn{
        margin-left:4px;
    }

    .pagination{
        display:flex;
        justify-content:center;
        margin-top:18px;
    }

    @media(max-width: 768px){
        .form-col{min-width:100%;}
        table{display:block;overflow-x:auto;}
    }
</style>

<style>
/* ========== التاريخ والوقت ========== */
.date-time-box {
    background: #fff;
    padding: 12px 18px;
    border-radius: 8px;
    color: #2a7f62;
    font-weight: 600;
    display: inline-flex;
    gap: 15px;
    border-right: 4px solid #2a7f62;
    box-shadow: 0 5px 15px rgba(0,0,0,.05);
    font-size: 1rem;
}

/* ========== صفحة الإدارة ========== */
.dashboard-header h2 {
    color: #2a7f62;
    display: flex;
    align-items: center;
    gap: 10px;
}

.pagination-container {
    margin-top: 20px;
    text-align: center;
}

</style>
@endpush

@push('scripts')
<script>
function updateDateTime(){
    const now = new Date();
    const days = ["الأحد","الإثنين","الثلاثاء","الأربعاء","الخميس","الجمعة","السبت"];
    document.getElementById("current-day").innerText = days[now.getDay()] + " -";
    document.getElementById("current-date").innerText = now.getFullYear()+"/"+(now.getMonth()+1)+"/"+now.getDate()+" -";
    document.getElementById("current-time").innerText =
        now.getHours().toString().padStart(2,'0') + ":" +
        now.getMinutes().toString().padStart(2,'0') + ":" +
        now.getSeconds().toString().padStart(2,'0');
}
setInterval(updateDateTime, 1000);
updateDateTime();
</script>
@endpush
