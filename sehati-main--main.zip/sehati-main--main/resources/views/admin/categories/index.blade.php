@extends('admin.layout')
@section('title','إدارة التصنيفات')

@section('content')

<!-- التاريخ والوقت -->
<div class="date-time-box mb-3">
    <span id="current-day"></span>
    <span id="current-date"></span>
    <span id="current-time"></span>
</div>

<div class="page-header">
    <h2><i class="fas fa-tags"></i> إدارة التصنيفات</h2>
    <a href="{{ route('admin.categories.create') }}" class="btn btn-primary">
        <i class="fas fa-plus"></i> إضافة تصنيف
    </a>
</div>

<!-- مربع البحث -->
<div class="card mb-3">
    <form method="GET" action="{{ route('admin.categories.index') }}" style="display:flex;gap:15px;flex-wrap:wrap">
        <input type="text" name="q" value="{{ request('q') }}" class="form-control" placeholder="ابحث باسم التصنيف...">
        <button class="btn btn-primary">بحث</button>
        <a href="{{ route('admin.categories.index') }}" class="btn btn-outline">إعادة تعيين</a>
    </form>
</div>

<!-- جدول -->
<div class="table-container">
    <table class="admin-table">
        <thead>
            <tr>
                <th>#</th>
                <th>اسم التصنيف</th>
                <th>عدد الأمراض</th>
                <th>تاريخ الإضافة</th>
                <th>إجراءات</th>
            </tr>
        </thead>
        <tbody>
            @forelse($categories as $cat)
                <tr>
                    <td>{{ $cat->id }}</td>
                    <td>{{ $cat->name }}</td>
                    <td>{{ $cat->diseases()->count() }}</td>
                    <td>{{ $cat->created_at->format('Y-m-d') }}</td>
                    <td>
                  <a href="{{ route('admin.categories.edit', $cat) }}" class="btn btn-outline">
                            <i class="fas fa-edit"></i>
                        </a>

                      <form action="{{ route('admin.categories.destroy', $cat) }}" method="POST">
                            @csrf @method('DELETE')
                            <button class="btn btn-danger" onclick="return confirm('هل تريد الحذف؟')">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr><td colspan="5" class="text-center">لا توجد تصنيفات حالياً</td></tr>
            @endforelse
        </tbody>
    </table>
</div>

<!-- ترقيم الصفحات -->
<div class="pagination-container">
    {{ $categories->links('pagination::bootstrap-5') }}
</div>

@endsection
@push('styles')
<style>
    .admin-container {
        padding: 30px;
        background: #fff;
        border-radius: 10px;
        box-shadow: 0 5px 15px rgba(0,0,0,.05);
    }

    .page-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 25px;
    }

    .page-header h2 {
        color: #2a7f62;
        font-size: 1.5rem;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .alert {
        padding: 10px 15px;
        border-radius: 6px;
        margin-bottom: 15px;
        font-size: 0.95rem;
    }
    .alert-success { background: #d4edda; color: #155724; }
    .alert-danger { background: #f8d7da; color: #721c24; }

    .table-container { overflow-x: auto; }

    .admin-table {
        width: 100%;
        border-collapse: collapse;
        min-width: 800px;
    }

    .admin-table th, .admin-table td {
        padding: 12px 15px;
        border-bottom: 1px solid #eee;
        text-align: center;
    }

    .admin-table th {
        background-color: #2a7f62;
        color: #fff;
        font-weight: 600;
    }

    .btn {
        display: inline-block;
        padding: 10px 20px;
        border-radius: 5px;
        font-size: 0.9rem;
        cursor: pointer;
        transition: 0.3s;
        text-decoration: none;
    }

    .btn-primary {
        background: #2a7f62;
        color: #fff;
        border: none;
    }

    .btn-primary:hover { background: #1e5f4a; }

    .btn-outline {
        background: transparent;
        color: #2a7f62;
        border: 1px solid #2a7f62;
    }

    .btn-outline:hover {
        background: #2a7f62;
        color: #fff;
    }

    .btn-danger {
        background: #dc3545;
        color: #fff;
        border: none;
    }

    .btn-danger:hover { background: #b52a35; }

    .pagination-container {
    margin-top: 25px !important;
    padding-top: 10px !important;
    padding-bottom: 20px !important;
    display: flex;
    justify-content: center;
}


    /* === Stats Cards نفس تصميم الملف الأصلي === */

.stats-cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.stat-card {
    background-color: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
    text-align: center;
}

.stat-card h3 {
    font-size: 1.5rem;
    color: #2a7f62; /* primary color */
    margin-bottom: 10px;
}

.stat-card p {
    color: #6c757d; /* text-light */
}

/* Border top colors ⬇ */
.stat-card.primary {
    border-top: 4px solid #2a7f62;
}

.stat-card.secondary {
    border-top: 4px solid #3ab795;
}

.stat-card.accent {
    border-top: 4px solid #ff7e5f;
}

.stat-card.dark {
    border-top: 4px solid #343a40;
}
/* التاريخ والوقت */
    .date-time-box {
        background: white;
        padding: 12px 18px;
        border-radius: 8px;
        display: inline-flex;
        gap: 15px;
        color: #2a7f62;
        font-weight: 600;
        font-size: 1rem;
        box-shadow: 0 5px 15px rgba(0, 0, 0, .05);
        border-right: 4px solid #2a7f62;
    }
    .table-container {
    margin-bottom: 40px;
}
.badge {
    padding: 4px 10px;
    border-radius: 4px;
    color: #fff;
}

.badge.active { background: #2a7f62; }
.badge.inactive { background: #dc3545; }

.card form {
    display: flex;
    flex-wrap: wrap;
    gap: 15px; /* مسافة واضحة بين الحقول والأزرار */
    margin-bottom: 15px;
}

.card form input.form-control {
    flex: 1 1 300px; /* يأخذ أكبر مساحة ممكنة ويكون مناسب للشاشات الكبيرة */
    padding: 14px 18px;
    font-size: 1.2rem; /* حجم الخط أكبر */
    border-radius: 8px;
}

.card form .btn {
    padding: 14px 22px;
    font-size: 1.2rem;
    border-radius: 8px;
}
.form-control{

    flex: 1 1 300px; /* يأخذ أكبر مساحة ممكنة ويكون مناسب للشاشات الكبيرة */
    padding: 14px 18px;
    font-size: 1.2rem; /* حجم الخط أكبر */
    border-radius: 8px;

}

</style>
@endpush
