@extends('admin.layout')
@section('title','إضافة تصنيف')

@section('content')

<div class="admin-form">
    <h2><i class="fas fa-plus-circle"></i> إضافة تصنيف جديد</h2>

    <form action="{{ route('admin.categories.store') }}" method="POST">
        @csrf

        <label>اسم التصنيف:</label>
        <input type="text" name="name" value="{{ old('name') }}" required>

        <button class="btn btn-primary" type="submit">حفظ</button>
        <a href="{{ route('admin.categories.index') }}" class="btn btn-outline">رجوع</a>
    </form>
</div>

@endsection
