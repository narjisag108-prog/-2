@extends('admin.layout')
@section('title','تعديل تصنيف')

@section('content')

<div class="admin-form">
    <h2><i class="fas fa-edit"></i> تعديل تصنيف</h2>

   <form action="{{ route('admin.categories.update', $category) }}" method="POST">
    @csrf
    @method('PUT')
    <label>اسم التصنيف:</label>
    <input type="text" name="name" value="{{ old('name', $category->name) }}" required>

    <button class="btn btn-primary">تحديث</button>
    <a href="{{ route('admin.categories.index') }}" class="btn btn-outline">رجوع</a>
</form>

</div>

@endsection
