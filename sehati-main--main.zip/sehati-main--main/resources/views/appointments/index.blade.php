@extends('layouts.user')
@section('title','مواعيدي')

@section('content')

<h2 class="page-title">📅 مواعيدي</h2>

<a href="{{ route('appointments.create') }}" class="btn-add">
    ➕ إضافة موعد
</a>

<div class="appointments-card">
@forelse($appointments as $a)
    <div class="appointment-row">
        <div>
            <strong>{{ $a->title }}</strong>
            <div class="meta">
                {{ $a->date->format('Y-m-d') }} — {{ $a->time }}
            </div>
        </div>
        <div>
        <strong>{{ $a->title }}</strong><br>
           <div class="meta">
<span>👨‍⚕️ {{ $a->doctor_name }}</span><br>
<small>{{ $a->date->format('d/m') }} - {{ $a->time }}</small>
    </div>

        <div class="actions">
            <a href="{{ route('appointments.edit',$a) }}" class="btn-edit">تعديل</a>

            <form action="{{ route('appointments.destroy',$a) }}" method="POST">
                @csrf
                @method('DELETE')
                <button class="btn-delete">حذف</button>
            </form>
        </div>
    </div>
@empty
    <p>لا توجد مواعيد</p>
@endforelse
</div>

<style>
.page-title{
    font-weight:800;
    color:#2a7f62;
    margin-bottom:15px;
}

.btn-add{
    display:inline-block;
    margin-bottom:18px;
    background:#2a7f62;
    color:#fff;
    padding:10px 18px;
    border-radius:10px;
    font-weight:700;
}

.appointments-card{
    background:#fff;
    border-radius:18px;
    box-shadow:0 12px 30px rgba(0,0,0,.08);
}

.appointment-row{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:16px 20px;
    border-bottom:1px solid #eef2f1;
}

.appointment-row:last-child{
    border-bottom:none;
}

.meta{
    font-size:13px;
    color:#7a8f8a;
}

.actions{
    display:flex;
    gap:8px;
}

.btn-edit{
    background:#e8f6f1;
    color:#2a7f62;
    padding:6px 14px;
    border-radius:8px;
    font-weight:700;
}

.btn-delete{
    background:#fde2e2;
    color:#c0392b;
    border:none;
    padding:6px 14px;
    border-radius:8px;
    font-weight:700;
    cursor:pointer;
}
</style>

@endsection
