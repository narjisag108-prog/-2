@extends('layouts.user')
@section('title','إضافة موعد')

@section('content')

<h2 class="page-title">➕ إضافة موعد طبي</h2>

<div class="center-wrapper">
    <form action="{{ route('appointments.store') }}" method="POST" class="form-card">
        @csrf

        {{-- عنوان الموعد --}}
        <div class="form-group">
            <label>عنوان الموعد</label>
            <input type="text" name="title" placeholder="مثال: مراجعة طبيب" required>
        </div>

        {{-- الطبيب --}}

        <div class="form-group">
  <label>اختر الطبيب</label>
<select name="doctor_name" required>
    <option value="">-- اختر الطبيب --</option>
    <option value="د. أحمد سالم">د. أحمد سالم – باطنية</option>
    <option value="د. محمد علي">د. محمد علي – قلب</option>
    <option value="د. سارة حسن">د. سارة حسن – غدد وسكر</option>
    <option value="د. خالد عمر">د. خالد عمر – ضغط</option>
</select>
        </div>

        {{-- التاريخ --}}
        <div class="form-group">
            <label>تاريخ الموعد</label>
            <input type="date" name="date" required>
        </div>

        {{-- الوقت --}}
        <div class="form-group">
            <label>وقت الموعد</label>
            <input type="time" name="time" required>
        </div>

        <button class="btn-primary-full">حفظ الموعد</button>
    </form>
</div>

<style>
.page-title{
    font-weight:800;
    color:#2a7f62;
    margin-bottom:25px;
}

/* توسيط الفورم */
.center-wrapper{
    display:flex;
    justify-content:center;
}

/* الكارد */
.form-card{
    width:420px;
    background:#fff;
    padding:26px;
    border-radius:18px;
    box-shadow:0 12px 30px rgba(0,0,0,.08);
    animation:fadeUp .4s ease;
}

/* الحقول */
.form-group{
    margin-bottom:18px;
}

.form-group label{
    font-weight:700;
    color:#2a7f62;
    margin-bottom:6px;
    display:block;
}

/* input + select نفس الشكل */
.form-group input,
.form-group select{
    width:100%;
    padding:12px 14px;
    border-radius:10px;
    border:1.8px solid #e1ece8;
    font-family:inherit;
    background:#fff;
}

.form-group input:focus,
.form-group select:focus{
    outline:none;
    border-color:#2a7f62;
    box-shadow:0 0 0 3px rgba(42,127,98,.12);
}

/* زر الحفظ */
.btn-primary-full{
    width:100%;
    background:#2a7f62;
    color:#fff;
    border:none;
    padding:12px;
    border-radius:12px;
    font-weight:800;
    cursor:pointer;
    transition:.3s;
}

.btn-primary-full:hover{
    background:#246b54;
}

/* أنيميشن */
@keyframes fadeUp{
    from{opacity:0;transform:translateY(20px)}
    to{opacity:1;transform:translateY(0)}
}
</style>

@endsection
