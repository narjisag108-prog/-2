@extends('layouts.user')
@section('title','تعديل موعد')

@section('content')

<h2 class="page-title">✏️ تعديل موعد طبي</h2>

<div class="center-wrapper">
    <form action="{{ route('appointments.update', $appointment->id) }}" method="POST" class="form-card">
        @csrf
        @method('PUT')

        <div class="form-group">
            <label>عنوان الموعد</label>
            <input
                type="text"
                name="title"
                value="{{ old('title', $appointment->title) }}"
                required
            >
        </div>

     <label>اختر الطبيب</label>
<select name="doctor_name" required>
    <option value="">-- اختر الطبيب --</option>
    <option value="د. أحمد سالم">د. أحمد سالم – باطنية</option>
    <option value="د. محمد علي">د. محمد علي – قلب</option>
    <option value="د. سارة حسن">د. سارة حسن – غدد وسكر</option>
    <option value="د. خالد عمر">د. خالد عمر – ضغط</option>
</select>


        <div class="form-group">
            <label>تاريخ الموعد</label>
            <input
                type="date"
                name="date"
                value="{{ old('date', $appointment->date) }}"
                required
            >
        </div>

        <div class="form-group">
            <label>وقت الموعد</label>
            <input
                type="time"
                name="time"
                value="{{ old('time', $appointment->time) }}"
                required
            >
        </div>

        <button class="btn-primary-full">💾 تحديث الموعد</button>
    </form>
</div>

{{-- نفس CSS بالضبط --}}
<style>
.page-title{
    font-weight:800;
    color:#2a7f62;
    margin-bottom:25px;
}

.center-wrapper{
    display:flex;
    justify-content:center;
}

.form-card{
    width:420px;
    background:#fff;
    padding:26px;
    border-radius:18px;
    box-shadow:0 12px 30px rgba(0,0,0,.08);
    animation:fadeUp .4s ease;
}

.form-group{
    margin-bottom:18px;
}

.form-group label{
    font-weight:700;
    color:#2a7f62;
    margin-bottom:6px;
    display:block;
}

.form-group input,
.form-group select{
    width:100%;
    padding:12px 14px;
    border-radius:10px;
    border:1.8px solid #e1ece8;
}

.form-group input:focus,
.form-group select:focus{
    outline:none;
    border-color:#2a7f62;
    box-shadow:0 0 0 3px rgba(42,127,98,.12);
}

.btn-primary-full{
    width:100%;
    background:#2a7f62;
    color:#fff;
    border:none;
    padding:12px;
    border-radius:12px;
    font-weight:800;
    cursor:pointer;
}

.btn-primary-full:hover{
    background:#246b54;
}

@keyframes fadeUp{
    from{opacity:0;transform:translateY(20px)}
    to{opacity:1;transform:translateY(0)}
}
</style>

@endsection
