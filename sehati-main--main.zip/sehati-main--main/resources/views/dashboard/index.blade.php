@extends('layouts.app')
@section('title','لوحة التحكم')

@push('styles')
<style>
    .dashboard-header {
        margin-bottom: 30px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .stats-cards {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 20px;
        margin-top: 25px;
    }

    .stat-card {
        background: #fff;
        padding: 22px;
        border-radius: 10px;
        box-shadow: 0 4px 16px rgba(0,0,0,.05);
        text-align: center;
        transition: .3s;
        border-top: 4px solid var(--primary-color);
    }

    .stat-card:hover {
        transform: translateY(-4px);
    }

    .stat-title {
        font-size: 1.2rem;
        font-weight: 600;
        color: var(--primary-color);
        margin-bottom: 10px;
    }

    .stat-value {
        font-size: 1.8rem;
        font-weight: 700;
        color: #333;
    }

    .stat-date {
        margin-top: 10px;
        font-size: .9rem;
        color: #6c757d;
    }

    .btn-details {
        margin-top: 12px;
        padding: 8px 20px;
        background: var(--primary-color);
        color:#fff;
        border-radius: 6px;
        display: inline-block;
    }
</style>
@endpush

@section('content')

<div class="dashboard-header">
    <h2 style="color:var(--primary-color)">مرحباً، {{ $user->name }}</h2>
    <div class="date-time-box">
        <span id="current-day"></span>
        <span id="current-date"></span>
        <span id="current-time"></span>
    </div>
</div>


<div class="stats-cards">

    {{-- ضغط الدم --}}
    <div class="stat-card">
        <div class="stat-title">📌 ضغط الدم</div>
        <div class="stat-value">
            {{ $bp ? $bp->value_upper.'/'.$bp->value_lower : 'لا توجد بيانات' }}
        </div>
        @if($bp)
            <div class="stat-date">آخر تحديث: {{ $bp->created_at->diffForHumans() }}</div>
        @endif
        <a href="{{ route('readings.blood_pressure') }}" class="btn-details">التفاصيل</a>
    </div>

    {{-- السكر --}}
    <div class="stat-card">
        <div class="stat-title">🩸 مستوى السكر</div>
        <div class="stat-value">
            {{ $sugar ? $sugar->value : 'لا توجد بيانات' }}
        </div>
        @if($sugar)
            <div class="stat-date">آخر تحديث: {{ $sugar->created_at->diffForHumans() }}</div>
        @endif
        <a href="{{ route('readings.sugar') }}" class="btn-details">التفاصيل</a>
    </div>

    {{-- الوزن --}}
    <div class="stat-card">
        <div class="stat-title">⚖️ الوزن</div>
        <div class="stat-value">
            {{ $weight ? $weight->value.' كغ' : 'لا توجد بيانات' }}
        </div>
        @if($weight)
            <div class="stat-date">آخر تحديث: {{ $weight->created_at->diffForHumans() }}</div>
        @endif
        <a href="{{ route('readings.weight') }}" class="btn-details">التفاصيل</a>
    </div>
<a href="{{ route('readings.dashboard') }}" class="btn btn-primary">
    📊 تتبع المؤشرات الصحية
</a>

</div>

@endsection

