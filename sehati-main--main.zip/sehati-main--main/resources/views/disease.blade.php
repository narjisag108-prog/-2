<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>{{ $title ?? 'صحتك أولاً' }}</title>

    <!-- Google Fonts & Icons -->
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        :root {
            --primary-color: #2a7f62;
            --accent-color: #ff7e5f;
            --light-color: #f8f9fa;
            --dark-color: #343a40;
            --text-color: #333;
            --text-light: #6c757d;
        }

        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            font-family: 'Tajawal', sans-serif;
            color: var(--text-color);
            background: #f5f5f5;
            line-height: 1.7;
        }

        a { color: var(--primary-color); text-decoration: none; transition: color .2s; }
        a:hover { color: var(--accent-color); }

        .container { width: 90%; max-width: 1200px; margin: 0 auto; }

        /* Header */
        header {
            background: #fff;
            box-shadow: 0 2px 10px rgba(0,0,0,.08);
            position: sticky; top: 0; z-index: 1000;
        }

        .header-container {
            display: flex; justify-content: space-between; align-items: center;
            padding: 15px 0;
        }

        .logo { display: flex; align-items: center; }
        .logo img { height: 50px; margin-left: 10px; }
        .logo h1 { color: var(--primary-color); font-size: 1.5rem; font-weight: 700; }

        nav ul { display: flex; list-style: none; }
        nav ul li { margin-right: 20px; }
        nav ul li a { font-weight: 500; }

        .btn {
            display: inline-block;
            padding: 8px 20px;
            border-radius: 4px;
            font-weight: 500;
            cursor: pointer;
            transition: all .2s;
        }
        .btn-primary {
            background: var(--primary-color);
            color: #fff;
            border: 2px solid var(--primary-color);
        }
        .btn-primary:hover {
            background: transparent;
            color: var(--primary-color);
        }
        .btn-outline {
            background: transparent;
            color: var(--primary-color);
            border: 2px solid var(--primary-color);
        }
        .btn-outline:hover {
            background: var(--primary-color);
            color: #fff;
        }

        /* Hero Section */
        .hero {
            background: linear-gradient(135deg, rgba(42,127,98,0.9), rgba(58,183,149,0.9)),
                        url('{{ asset("images/medical-bg.jpg") }}') center/cover no-repeat;
            color: #fff;
            padding: 100px 0;
            text-align: center;
        }
        .hero h2 { font-size: 2.5rem; margin-bottom: 15px; }
        .hero p { font-size: 1.1rem; }

        /* Main Section */
        .diseases { padding: 60px 0; background: #fff; }
        .content-wrap { display: flex; gap: 30px; }
        .main-content {
            flex: 1;
            background: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 5px 15px rgba(0,0,0,.03);
        }

        .main-content h2, .main-content h3 {
            color: var(--primary-color);
            margin-bottom: 10px;
        }

        .main-content p {
            color: var(--text-light);
            margin-bottom: 15px;
            font-size: 1rem;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }

        .stat-item {
            background: var(--light-color);
            padding: 15px;
            border-radius: 8px;
            text-align: center;
        }
        .stat-item .number {
            font-size: 1.6rem;
            color: var(--primary-color);
            font-weight: 700;
        }

        /* Sidebar */
        .sidebar { width: 320px; }
        .sidebar .sidebar-widget {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            box-shadow: 0 5px 15px rgba(0,0,0,.03);
        }
        .sidebar h3 { color: var(--primary-color); margin-bottom: 10px; }
        .sidebar ul { list-style: none; }
        .sidebar ul li { margin-bottom: 8px; }

        /* Newsletter */
        .newsletter {
            padding: 60px 0;
            background: linear-gradient(135deg, rgba(42,127,98,0.9), rgba(58,183,149,0.9));
            color: #fff;
            text-align: center;
        }
        .newsletter h2 { margin-bottom: 10px; }
        .newsletter-form {
            display: flex;
            max-width: 500px;
            margin: 20px auto;
        }
        .newsletter-form input {
            flex: 1;
            padding: 12px 15px;
            border: none;
            border-radius: 4px 0 0 4px;
        }
        .newsletter-form button {
            background: var(--accent-color);
            color: #fff;
            border: none;
            padding: 0 20px;
            border-radius: 0 4px 4px 0;
            cursor: pointer;
            transition: opacity .3s;
        }
        .newsletter-form button:hover { opacity: .8; }

        /* Footer */
        footer {
            background: var(--dark-color);
            color: #fff;
            padding: 60px 0 20px;
        }
        .footer-container {
            display: grid;
            grid-template-columns: repeat(auto-fit,minmax(220px,1fr));
            gap: 30px;
            margin-bottom: 40px;
        }
        .footer-links ul { list-style: none; }
        .footer-links li { margin-bottom: 8px; }

        .footer-bottom {
            text-align: center;
            color: #adb5bd;
            padding-top: 10px;
            font-size: 0.9rem;
        }

        @media (max-width: 992px) {
            .content-wrap { flex-direction: column; }
            .sidebar { width: 100%; }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <div class="container header-container">
            <div class="logo">
<img src="{{ asset('storage/logo.png') }}" alt="logo">

                <h1>صحتك أولاً</h1>
            </div>

            <nav>
                <ul>
                    <li><a href="{{ url('/home') }}">الرئيسية</a></li>
                    <li><a href="#diseases">الأمراض</a></li>
                    <li><a href="#features">الخدمات</a></li>
                    <li><a href="#articles">المقالات</a></li>
                    <li><a href="#contact">اتصل بنا</a></li>
                </ul>
            </nav>

            <div class="auth-buttons">
                <a href="{{ route('login') }}" class="btn btn-outline">تسجيل الدخول</a>
                <a href="{{ route('register') }}" class="btn btn-primary">إنشاء حساب</a>
            </div>
        </div>
    </header>

    <!-- Hero -->
    <section class="hero">
        <div class="container">
            <h2>{{ $title ?? 'مرض السكري' }}</h2>
            <p>{{ $subtitle ?? 'دليل شامل لفهم مرض السكري وأنواعه وأعراضه وطرق الوقاية والعلاج' }}</p>
        </div>
    </section>

    <!-- Main Content -->
    <section class="diseases" id="diseases">
        <div class="container">
            <div class="content-wrap">
                <div class="main-content">
                    {!! $contentHtml ?? '
                        <h2>ما هو مرض السكري؟</h2>
                        <p>مرض السكري هو حالة مزمنة تؤثر على طريقة تعامل الجسم مع الجلوكوز...</p>
                    ' !!}

                    <div class="stats-grid">
                        @foreach($stats as $stat)
                            <div class="stat-item">
                                <div class="number">{{ $stat['number'] }}</div>
                                <div class="label">{{ $stat['label'] }}</div>
                            </div>
                        @endforeach
                    </div>
                </div>

                <aside class="sidebar">
                    <div class="sidebar-widget">
                        <h3>روابط سريعة</h3>
                        <ul>
                            @foreach($quickLinks as $link)
                                <li><a href="{{ $link['href'] }}">{{ $link['text'] }}</a></li>
                            @endforeach
                        </ul>
                    </div>

                    <div class="sidebar-widget">
                        <h3>حالات طارئة</h3>
                        <p>إذا كنت تعاني من:</p>
                        <ul>
                            <li>ارتفاع أو انخفاض شديد في السكر</li>
                            <li>قيء مستمر</li>
                            <li>صعوبة في التنفس</li>
                            <li>فقدان الوعي</li>
                        </ul>
                        <p>اتصل بالطوارئ فورًا: <strong>911</strong></p>
                    </div>

                    <div class="sidebar-widget">
                        <h3>اختبار خطر السكري</h3>
                        <p>قم بإجراء اختبار سريع لمعرفة مستوى خطر إصابتك بمرض السكري.</p>
                        <a href="{{ url('/diabetes-test') }}" class="btn btn-primary" style="width:100%;text-align:center;">ابدأ الاختبار</a>
                    </div>

                    <div class="sidebar-widget">
                        <h3>مواد تعليمية</h3>
                        <ul>
                            <li><a href="#"><i class="fas fa-file-pdf"></i> دليل السكري للمرضى</a></li>
                            <li><a href="#"><i class="fas fa-utensils"></i> دليل التغذية</a></li>
                            <li><a href="#"><i class="fas fa-running"></i> دليل التمارين</a></li>
                        </ul>
                    </div>
                </aside>
            </div>
        </div>
    </section>

    <!-- Newsletter -->
    <section class="newsletter" id="newsletter">
        <div class="container">
            <h2>اشترك في النشرة البريدية</h2>
            <p>احصل على أحدث المقالات والنصائح الصحية مباشرة إلى بريدك الإلكتروني.</p>

            @if(session('success'))
                <div style="background:#fff;color:#000;padding:10px;border-radius:6px;display:inline-block;margin-bottom:10px">
                    {{ session('success') }}
                </div>
            @endif

            <form class="newsletter-form" action="{{ route('disease.subscribe') }}" method="POST">
                @csrf
                <input type="email" name="email" placeholder="أدخل بريدك الإلكتروني" required>
                <button type="submit">اشترك</button>
            </form>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="footer-container">
                <div>
                    <h2>صحتك أولاً</h2>
                    <p>منصة تثقيفية تهدف إلى توعية المجتمع بالأمراض المزمنة وطرق الوقاية والعلاج.</p>
                </div>

                <div class="footer-links">
                    <h3>روابط سريعة</h3>
                    <ul>
                        <li><a href="{{ url('/home') }}">الرئيسية</a></li>
                        <li><a href="#diseases">الأمراض المزمنة</a></li>
                        <li><a href="#features">خدماتنا</a></li>
                    </ul>
                </div>

                <div class="footer-links">
                    <h3>الأمراض</h3>
                    <ul>
                        <li><a href="{{ url('/disease/diabetes') }}">مرض السكري</a></li>
                        <li><a href="{{ url('/disease/heart') }}">أمراض القلب</a></li>
                        <li><a href="{{ url('/disease/pressure') }}">ضغط الدم</a></li>
                    </ul>
                </div>

                <div>
                    <h3>اتصل بنا</h3>
                    <p><i class="fas fa-map-marker-alt"></i> بنغازي ليبيا</p>
                    <p><i class="fas fa-phone"></i> +218 91 234 5678</p>
                    <p><i class="fas fa-envelope"></i> healthfirst@gmail.com</p>
                </div>
            </div>

            <div class="footer-bottom">
                &copy; {{ date('Y') }} صحتك أولاً. جميع الحقوق محفوظة.
            </div>
        </div>
    </footer>
</body>
</html>

