<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>نتيجة التقييم الصحي لمرض السكري</title>
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700&display=swap"
          rel="stylesheet">

    {{-- خذي نفس الستايلات من assessment.html لقسم .results و .recommendations إلخ --}}
    <style>
        body{
            font-family:'Tajawal',sans-serif;
            background:#f5f5f5;
            margin:0;
        }
        .container{max-width:900px;margin:40px auto;padding:0 15px;}
        .card{
            background:#fff;
            padding:30px;
            border-radius:10px;
            box-shadow:0 5px 15px rgba(0,0,0,.06);
            text-align:center;
        }
        .results-icon{
            font-size:4rem;
            color:#2a7f62;
            margin-bottom:15px;
        }
        .risk-level{
            display:inline-block;
            padding:8px 25px;
            border-radius:20px;
            margin-bottom:15px;
            font-weight:600;
        }
        .risk-low{background:rgba(42,127,98,.1);color:#2a7f62;}
        .risk-medium{background:rgba(255,193,7,.1);color:#ffc107;}
        .risk-high{background:rgba(220,53,69,.1);color:#dc3545;}
        .results-title{font-size:1.6rem;color:#2a7f62;margin-bottom:10px;}
        .results-description{
            color:#6c757d;
            line-height:1.8;
            max-width:700px;
            margin:0 auto 25px;
        }
        .recommendations{
            text-align:right;
            background:#f8f9fa;
            border-radius:8px;
            padding:20px;
            margin-top:15px;
        }
        .recommendations h3{color:#2a7f62;margin-bottom:10px;}
        .recommendations ul{padding-right:20px;}
        .recommendations li{margin-bottom:8px;color:#555;}
        .btn{
            display:inline-block;
            padding:10px 22px;
            border-radius:8px;
            border:1px solid #2a7f62;
            color:#fff;
            background:#2a7f62;
            text-decoration:none;
            font-weight:500;
            margin-top:20px;
        }
        .btn:hover{background:#1e5f4a;}
    </style>
</head>
<body>
<div class="container">
    <div class="card">

        <div class="results-icon">
            <i class="fas fa-clipboard-check"></i>
        </div>

        {{-- مستوى الخطر --}}
        <span class="risk-level
            {{ $assessment->risk_level === 'low' ? 'risk-low' :
               ($assessment->risk_level === 'medium' ? 'risk-medium' : 'risk-high') }}">
            {{ $riskTitle }}
        </span>

        <h3 class="results-title">نتيجة التقييم الصحي لمرض السكري</h3>

        <p class="results-description">
            {{ $riskDescription }}
        </p>

        <div class="recommendations">
            <h3>نصائح للوقاية من مرض السكري:</h3>
            <ul>
                <li>حافظ على وزن صحي وتجنب السمنة.</li>
                <li>مارس النشاط البدني بانتظام (30 دقيقة يومياً على الأقل).</li>
                <li>تناول غذاءً صحياً غنياً بالخضروات والفواكه والحبوب الكاملة.</li>
                <li>قلّل من السكريات والدهون المشبّعة.</li>
                <li>توقف عن التدخين وتجنّب المشروبات الغازية المحلاة.</li>
                <li>افحص مستوى السكر في الدم بشكل دوري إذا كنت من الفئات الأكثر عرضة.</li>
                <li>اهتم بالنوم الجيد وتقليل التوتر والضغط النفسي.</li>
            </ul>
        </div>

        <a href="{{ route('assessment.diabetes.form') }}" class="btn">
            إعادة التقييم
        </a>
    </div>
</div>
</body>
</html>
