@extends('layouts.user')
@section('title', 'نتيجة التقييم')

@push('styles')
<style>
.result-box{
    background:#fff;
    padding:30px;
    border-radius:16px;
    width:90%;
    max-width:700px;
    margin:40px auto;
    box-shadow:0 8px 25px rgba(0,0,0,.08);
    text-align:center;
}
.score{
    font-size:3rem;
    font-weight:800;
    margin:10px 0;
}
.score.green{ color:#28a745; }
.score.orange{ color:#e67e22; }
.score.red{ color:#e63946; }
.advice{
    font-size:1.1rem;
    margin:15px 0;
    color:#555;
}
.btn-container{
    margin-top:25px;
    display:flex;
    justify-content:center;
    gap:12px;
}
.btn-outline{
    background:#fff;
    border:2px solid var(--primary-color);
    padding:10px 18px;
    border-radius:8px;
}
.btn-outline:hover{
    background:var(--primary-color);
    color:#fff;
}
</style>
@endpush

@section('content')

<div class="result-box">
    <h2>💡 نتيجة التقييم الصحي</h2>

    <div class="score {{ $color }}">
        {{ $score }}
    </div>
    
    <h3>مستوى الخطورة: <strong>{{ $level }}</strong></h3>
    
    <p class="advice">{{ $advice }}</p>

    <div class="btn-container">
        <a href="{{ route('readings.dashboard') }}" class="btn-outline">
            متابعة حالتي الصحية 📊
        </a>
        <a href="{{ route('diseases.index') }}" class="btn-outline">
            تعرف على الأمراض المزمنة 🩺
        </a>
    </div>
</div>

@endsection
