@extends('layouts.user')
@section('title', 'التقييم الصحي')

@push('styles')
<style>
.form-section{
    background:#fff;
    padding:25px;
    border-radius:14px;
    box-shadow:0 6px 18px rgba(0,0,0,.06);
    width:90%;
    max-width:750px;
    margin:auto;
}
.form-section h2{
    text-align:center;
    color:var(--primary-color);
    margin-bottom:22px;
    font-size:1.8rem;
    font-weight:700;
}
.question-box{
    margin-bottom:20px;
}
.question-title{
    font-weight:700;
    margin-bottom:8px;
}
label{
    margin-right:8px;
    cursor:pointer;
}
input[type="radio"]{
    margin-left:6px;
}
.submit-btn{
    background:var(--primary-color);
    color:#fff;
    font-weight:600;
    border-radius:8px;
    padding:12px 18px;
    width:100%;
    border:none;
    cursor:pointer;
    margin-top:10px;
}
.submit-btn:hover{
    background:#238b61;
}
</style>
@endpush

@section('content')

<form class="form-section" method="POST" action="{{ route('assessment.store') }}">
    @csrf

    <h2>🩺 التقييم الصحي</h2>

    {{-- العمر --}}
    <div class="question-box">
        <p class="question-title">1️⃣ العمر</p>
        <label><input type="radio" name="age" value="0" required> أقل من 45</label>
        <label><input type="radio" name="age" value="2"> بين 45 - 54</label>
        <label><input type="radio" name="age" value="3"> بين 55 - 64</label>
        <label><input type="radio" name="age" value="4"> أكثر من 65</label>
    </div>

    {{-- الجنس --}}
    <div class="question-box">
        <p class="question-title">2️⃣ الجنس</p>
        <label><input type="radio" name="gender" value="male" required> ذكر</label>
        <label><input type="radio" name="gender" value="female"> أنثى</label>
    </div>

    {{-- التاريخ العائلي --}}
    <div class="question-box">
        <p class="question-title">3️⃣ هل لديك تاريخ عائلي مع أمراض مزمنة؟</p>
        <label><input type="radio" name="family_history" value="0" required> لا</label>
        <label><input type="radio" name="family_history" value="3"> نعم، أحد من العائلة</label>
        <label><input type="radio" name="family_history" value="5"> نعم، أكثر من شخص</label>
    </div>

    {{-- كتلة الجسم BMI --}}
    <div class="question-box">
        <p class="question-title">4️⃣ مؤشر كتلة الجسم BMI</p>
        <label><input type="radio" name="bmi" value="0" required> طبيعي</label>
        <label><input type="radio" name="bmi" value="2"> وزن زائد</label>
        <label><input type="radio" name="bmi" value="3"> سمنة</label>
        <label><input type="radio" name="bmi" value="5"> سمنة مفرطة</label>
    </div>

    {{-- النشاط البدني --}}
    <div class="question-box">
        <p class="question-title">5️⃣ مدى نشاطك البدني</p>
        <label><input type="radio" name="activity" value="0" required> نشيط جداً</label>
        <label><input type="radio" name="activity" value="2"> متوسط النشاط</label>
        <label><input type="radio" name="activity" value="4"> قليل النشاط</label>
        <label><input type="radio" name="activity" value="6"> خامل</label>
    </div>

    {{-- ضغط الدم --}}
    <div class="question-box">
        <p class="question-title">6️⃣ هل تعاني من ارتفاع ضغط الدم؟</p>
        <label><input type="radio" name="blood_pressure" value="0" required> لا</label>
        <label><input type="radio" name="blood_pressure" value="4"> نعم، بسيط</label>
        <label><input type="radio" name="blood_pressure" value="7"> نعم، متوسط</label>
        <label><input type="radio" name="blood_pressure" value="9"> نعم، شديد</label>
    </div>

    <button class="submit-btn">عرض النتيجة</button>

</form>

@endsection
