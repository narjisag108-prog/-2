@extends('layouts.app')

@section('content')
<section class="section">
    <div class="container">
        <div class="diseases-grid">
            @foreach($diseases as $d)
            <div class="disease-card">
                <img src="{{ asset('storage/'.$d->image) }}">
                <div class="disease-content">
                    <h3>{{ $d->name }}</h3>
                    <p>{{ Str::limit(strip_tags($d->content),150) }}</p>
                    <a href="{{ route('diseases.show', $d->slug) }}" class="btn btn-outline">المزيد من المعلومات</a>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</section>
@endsection
