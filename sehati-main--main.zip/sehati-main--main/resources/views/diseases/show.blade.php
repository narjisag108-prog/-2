@extends('layouts.app')

@section('content')

<section class="disease-header">
    <h1>{{ $disease->name }}</h1>
</section>

<section class="disease-content">

    {{-- المحتوى الرئيسي --}}
    <div class="container content-container">
        {!! $disease->content !!}
    </div>

    {{-- السايدبار --}}
    <div class="sidebar-widget emergency-box">

        @if($disease->symptoms)
            <h2>الأعراض</h2>
            {!! $disease->symptoms !!}
        @endif

        @if($disease->causes)
            <h2>الأسباب</h2>
            {!! $disease->causes !!}
        @endif

        @if($disease->treatment)
            <h2>العلاج</h2>
            {!! $disease->treatment !!}
        @endif

        @if($disease->prevention)
            <h2>الوقاية</h2>
            {!! $disease->prevention !!}
        @endif

        <p><strong>اتصل بالطوارئ فورًا: 911</strong></p>
    </div>

    {{-- اختبار يظهر للسكري فقط --}}
    @if($disease->slug === 'diabetes')
        <div class="sidebar-widget">
            <h3>اختبار خطر المرض</h3>
            <a href="{{ route('assessment.show') }}" class="btn btn-primary" style="width:100%">
                ابدأ الاختبار
            </a>
        </div>
    @endif

</section>

@endsection
