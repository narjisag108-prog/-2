<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\DiseaseController;
use App\Http\Controllers\ReviewController;
use App\Http\Controllers\AssessmentController;
use App\Http\Controllers\MedicineController;
use App\Http\Controllers\AppointmentController;
use App\Http\Controllers\UserDashboardControlle;
use App\Http\Controllers\BloodPressureReadingController;
use App\Http\Controllers\SugarController;
use App\Http\Controllers\PatientController;
use App\Http\Controllers\HeartController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\ArticleController;
use App\Http\Controllers\ChatController;
use App\Http\Controllers\DashboardController as dd;
use App\Http\Controllers\Doctor\DoctorAppointmentController;
use App\Http\Controllers\UserConsultationController;


/*
|--------------------------------------------------------------------------
| Auth (Login / Register)
|--------------------------------------------------------------------------
*/
Route::get('/articles', [ArticleController::class, 'index'])->name('articles.index');
Route::get('/articles/{id}', [ArticleController::class, 'show'])->name('articles.show');
Route::get('/login', [AuthController::class, 'loginView'])->name('login');
Route::post('/login', [AuthController::class, 'login'])->name('login.post');
Route::get('/dashboard', [UserDashboardControlle::class, 'index'])
->name('user.dashboard');


Route::prefix('user/consultations')
    ->middleware('auth')
    ->name('user.consultations.')
    ->group(function () {

        Route::get('/', [UserConsultationController::class, 'index'])
            ->name('index');

        Route::get('/create', [UserConsultationController::class, 'create'])
            ->name('create');

        Route::post('/', [UserConsultationController::class, 'store'])
            ->name('store');

        Route::get('/{consultation}', [UserConsultationController::class, 'show'])
            ->name('show');
    });



    Route::get('/doctor/dashboard', [\App\Http\Controllers\Doctor\DashboardController::class, 'index'])
        ->name('doctor.dashboard');
    Route::get('/contact', [ContactController::class, 'show'])->name('contact.show');
    Route::post('/contact', [ContactController::class, 'send'])->name('contact.send');
    Route::get('/register', [AuthController::class, 'registerView'])->name('register');
    Route::post('/register', [AuthController::class, 'register'])->name('register.post');

    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
    Route::prefix('assessment')->group(function () {
    Route::get('/form', [AssessmentController::class, 'show'])->name('assessment.show');
    Route::post('/store', [AssessmentController::class, 'store'])->name('assessment.store');
    Route::get('/result', [AssessmentController::class, 'result'])->name('assessment.result');
});

/*
|--------------------------------------------------------------------------
| Public Pages
|--------------------------------------------------------------------------
*/
Route::get('/home', [HomeController::class, 'index'])->name('home');

Route::get('/diseases', [DiseaseController::class, 'index'])->name('diseases.index');
Route::get('/diseases/{disease:slug}', [DiseaseController::class, 'show'])->name('diseases.show');

Route::post('/newsletter/subscribe', [HomeController::class,'subscribe'])->name('newsletter.subscribe');


/*
|--------------------------------------------------------------------------
| Protected User Routes
|--------------------------------------------------------------------------
*/




    // ⭐ Health Dashboard
    Route::get('/health', function(){
        return view('readings.dashboard');
    })->name('readings.dashboard');


    // ⭐ Blood Pressure
    Route::get('/health/blood-pressure', [BloodPressureReadingController::class,'index'])
        ->name('readings.blood-pressure.index');
    Route::post('/health/blood-pressure', [BloodPressureReadingController::class,'store'])
        ->name('readings.blood-pressure.store');

    // ⭐ Sugar
    Route::get('/health/sugar', [SugarController::class,'index'])
        ->name('readings.sugar.index');
    Route::post('/health/sugar', [SugarController::class,'store'])
        ->name('readings.sugar.store');

    // ⭐ Heart Rate
    Route::get('/health/heart', [HeartController::class,'index'])
        ->name('readings.heart.index');
    Route::post('/health/heart', [HeartController::class,'store'])
        ->name('readings.heart.store');

    // ⭐ Medicines
    Route::resource('medicines', MedicineController::class)
        ->only(['index','create','store']);

    // ⭐ Appointments
    Route::resource('appointments', AppointmentController::class)
        ->only(['index','create','store','edit','update','destroy']);

    // ⭐ Reviews for diseases
    Route::post('/diseases/{disease}/review', [ReviewController::class,'store'])
        ->name('reviews.store');



/*
|--------------------------------------------------------------------------
| Admin Panel
|--------------------------------------------------------------------------
*/
     Route::prefix('admin')
    ->name('admin.')
    ->middleware('auth')
    ->group(function () {

        Route::get('/dashboard', [\App\Http\Controllers\Admin\DashboardController::class, 'index'])
            ->name('dashboard');

        Route::resource('users', \App\Http\Controllers\Admin\UserAdminController::class);
        Route::resource('diseases', \App\Http\Controllers\Admin\DiseaseAdminController::class);
        Route::resource('articles', \App\Http\Controllers\Admin\ArticleAdminController::class);
        Route::resource('tests', \App\Http\Controllers\Admin\TestAdminController::class);
        Route::resource('categories', \App\Http\Controllers\Admin\DiseaseCategoryAdminController::class);

        Route::resource('consultations', \App\Http\Controllers\Admin\ConsultationAdminController::class)
            ->except(['update']);

        Route::get('/settings', [\App\Http\Controllers\Admin\SettingsController::class,'index'])
            ->name('settings.index');
            Route::put('/settings', [\App\Http\Controllers\Admin\SettingsController::class, 'update'])->name('settings.update');

             Route::post(
            'users/{user}/toggle-status',
            [\App\Http\Controllers\Admin\UserAdminController::class, 'toggleStatus']
        )->name('users.toggleStatus');
    });

use App\Http\Controllers\HealthDashboardController;

Route::get('/health', [HealthDashboardController::class, 'index'])
    ->name('readings.dashboard');
// routes/web.php
Route::post('/chat', [ChatController::class, 'send'])
    ->middleware('auth')
    ->name('chat.send');

// Route::post('/chat/send', [ChatController::class, 'send'])->name('chat.send');
Route::get('/doctor/calendar/events', [\App\Http\Controllers\Doctor\CalendarController::class, 'events'])
    ->name('doctor.calendar.events');


Route::prefix('doctor')
    ->middleware(['auth'])
    ->name('doctor.')
    ->group(function () {

        Route::get('appointments', [DoctorAppointmentController::class, 'index'])
            ->name('appointments.index');

        Route::get('appointments/create', [DoctorAppointmentController::class, 'create'])
            ->name('appointments.create');

        Route::post('appointments', [DoctorAppointmentController::class, 'store'])
            ->name('appointments.store');

        Route::get('appointments/{appointment}/edit', [DoctorAppointmentController::class, 'edit'])
            ->name('appointments.edit');

        Route::put('appointments/{appointment}', [DoctorAppointmentController::class, 'update'])
            ->name('appointments.update');

        Route::delete('appointments/{appointment}', [DoctorAppointmentController::class, 'destroy'])
            ->name('appointments.destroy');
 Route::get('/patients', [PatientController::class, 'index'])
        ->name('patients.index');

    Route::get('/patients/create', [PatientController::class, 'create'])
        ->name('patients.create');

    Route::post('/patients', [PatientController::class, 'store'])
        ->name('patients.store');

    Route::get('/patients/{patient}', [PatientController::class, 'show'])
        ->name('patients.show');

        Route::get('/consultations',
            [App\Http\Controllers\Doctor\ConsultationController::class, 'index']
        )->name('consultations.index');

        Route::get('/consultations/{id}',
            [App\Http\Controllers\Doctor\ConsultationController::class, 'show']
        )->name('consultations.show');

        Route::post('/consultations/{id}/reply',
            [App\Http\Controllers\Doctor\ConsultationController::class, 'reply']
        )->name('consultations.reply');
         Route::resource('prescriptions', \App\Http\Controllers\Doctor\PrescriptionController::class)
        ->only(['index','create','store']);


           Route::resource('reports', \App\Http\Controllers\Doctor\MedicalReportController::class)
        ->only(['index','create','store']);
    });
